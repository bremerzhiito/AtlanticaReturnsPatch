#line 2 "C:\ATLANTICA\Carpeta vacia\AO RETURNS V3-OFICIAL\Shaders\Generated\NDefaultMaterial\02000200-00000008-45000000-00000000-V.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

float4x4 g_World;
float4x4 g_ViewProj;
float4x4 UVSet1_TexTransform;
float4 g_MaterialEmissive;
float4x4 g_WorldView;
float4 g_FogNearFar;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

    AtSplitColorAndOpacity
    
*/

void AtSplitColorAndOpacity(float4 iColor,
    out float3 oColor,
    out float oOpacity)
{

    oColor.rgb = iColor.rgb;
    oOpacity = iColor.a;
    
}
//---------------------------------------------------------------------------
/*

	AtTransformPosition
	
*/

void AtTransformPosition(float4 iPos,
    float4x4 iMatrix,
    out float4 oPos)
{

	oPos = mul( iPos, iMatrix );
	
}
//---------------------------------------------------------------------------
/*

    This fragment is responsible for applying a transform to the input set
    of texture coordinates.
    
*/

void TexTransformApply(float2 TexCoord,
    float4x4 TexTransform,
    out float2 TexCoordOut)
{

    
    TexCoordOut = mul(float4(TexCoord.x, TexCoord.y, 0.0, 1.0), TexTransform);
    
}
//---------------------------------------------------------------------------
/*

	AtCalculateFog
	
*/

void AtCalculateFog(float4 iPos,
    float4x4 iWorldView,
    float2 iFogNearFar,
    out float oResult)
{

	float4 lTransformed = mul( iPos, iWorldView );
	oResult = saturate( ( lTransformed.z - iFogNearFar.x ) / ( iFogNearFar.y - iFogNearFar.x ) );	
	
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat
    
*/

void AtMultplyFloat(float iV1,
    float iV2,
    out float oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat3
    
*/

void AtMultplyFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtXYZToFloat3
    
*/

void AtXYZToFloat3(float iX,
    float iY,
    float iZ,
    out float3 oOutput)
{

	oOutput = float3( iX, iY, iZ );
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float3 Normal : NORMAL0;
    float2 UVSet0 : TEXCOORD0;
    float4 VertexColors : COLOR0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float2 UVSet1 : TEXCOORD1;
    float3 OpacityFogDot : TEXCOORD2;
    float3 DiffAccum : TEXCOORD3;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float3 oColor_CallOut0;
    float oOpacity_CallOut0;
    AtSplitColorAndOpacity(In.VertexColors, oColor_CallOut0, oOpacity_CallOut0);

	// Function call #1
    float4 oPos_CallOut1;
    AtTransformPosition(In.Position, g_World, oPos_CallOut1);

	// Function call #2
    TexTransformApply(In.UVSet0, UVSet1_TexTransform, Out.UVSet1);

	// Function call #3
    float oResult_CallOut3;
    AtCalculateFog(In.Position, g_WorldView, g_FogNearFar, oResult_CallOut3);

	// Function call #4
    AtTransformPosition(oPos_CallOut1, g_ViewProj, Out.Position);

	// Function call #5
    float3 oColor_CallOut5;
    float oOpacity_CallOut5;
    AtSplitColorAndOpacity(g_MaterialEmissive, oColor_CallOut5, 
        oOpacity_CallOut5);

	// Function call #6
    float oV_CallOut6;
    AtMultplyFloat(oOpacity_CallOut5, oOpacity_CallOut0, oV_CallOut6);

	// Function call #7
    AtMultplyFloat3(oColor_CallOut5, oColor_CallOut0, Out.DiffAccum);

	// Function call #8
    AtXYZToFloat3(oV_CallOut6, oResult_CallOut3, float(1.0), Out.OpacityFogDot);

    Out.UVSet0 = In.UVSet0;
    return Out;
}

