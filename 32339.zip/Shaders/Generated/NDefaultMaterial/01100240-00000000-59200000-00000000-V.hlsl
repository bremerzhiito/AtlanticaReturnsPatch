#line 2 "C:\ATLANTICA\Carpeta vacia\AO RETURNS V3-OFICIAL\Shaders\Generated\NDefaultMaterial\01100240-00000000-59200000-00000000-V.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

float4x4 g_World;
float4x4 g_ViewProj;
float4 g_MaterialEmissive;
float4 g_DirDiffuse0;
float4 g_DirWorldDirection0;
float4 g_DirDiffuse;
float4 g_DirWorldDirection;
float4x4 g_WorldView;
float4 g_FogNearFar;
float4x4 CamViewToLightProj_1;
float4x4 CamViewToLightProj_2;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

	AtTransformPosition
	
*/

void AtTransformPosition(float4 iPos,
    float4x4 iMatrix,
    out float4 oPos)
{

	oPos = mul( iPos, iMatrix );
	
}
//---------------------------------------------------------------------------
/*

    AtSplitColorAndOpacity
    
*/

void AtSplitColorAndOpacity(float4 iColor,
    out float3 oColor,
    out float oOpacity)
{

    oColor.rgb = iColor.rgb;
    oOpacity = iColor.a;
    
}
//---------------------------------------------------------------------------
/*

	AtCalculateLightDiffuse
	
*/

void AtCalculateLightDiffuse(float3 iLightDiffuse,
    float3 iLightDirection,
    float3 iSurfaceNormal,
    out float3 oResult)
{

	oResult = iLightDiffuse * max( 0.0f, dot( -iLightDirection, iSurfaceNormal ) );
	
}
//---------------------------------------------------------------------------
/*

	AtCalculateFogAndWorldViewPos
	
*/

void AtCalculateFogAndWorldViewPos(float4 iPos,
    float4x4 iWorldView,
    float2 iFogNearFar,
    out float oResult,
    out float4 oWorldViewPos)
{

	oWorldViewPos = mul( iPos, iWorldView );
	oResult = saturate( ( oWorldViewPos.z - iFogNearFar.x ) / ( iFogNearFar.y - iFogNearFar.x ) );	
	
}
//---------------------------------------------------------------------------
/*

    AtCalculateDSShadowUV
    
*/

void AtCalculateDSShadowUV(float4 iInput,
    out float4 oOutput)
{

	oOutput = iInput;
    oOutput.x = iInput.x * 0.5 + (0.5 + 0.5/1024.0) * iInput.w;
    oOutput.y = iInput.y * -0.5 + (0.5 + 0.5/1024.0) * iInput.w;	
    
}
//---------------------------------------------------------------------------
/*

	AtCalculateLightDiffuseOutDot
	
*/

void AtCalculateLightDiffuseOutDot(float3 iLightDiffuse,
    float3 iLightDirection,
    float3 iSurfaceNormal,
    out float3 oResult,
    out float oDot)
{

	oDot = max( 0.0f, dot( -iLightDirection, iSurfaceNormal ) );
	oResult = iLightDiffuse * oDot;
	
}
//---------------------------------------------------------------------------
/*

    AtXYZToFloat3
    
*/

void AtXYZToFloat3(float iX,
    float iY,
    float iZ,
    out float3 oOutput)
{

	oOutput = float3( iX, iY, iZ );
    
}
//---------------------------------------------------------------------------
/*

    AtAddFloat3
    
*/

void AtAddFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 + iV2;
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float3 Normal : NORMAL0;
    float2 UVSet0 : TEXCOORD0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float3 OpacityFogDot : TEXCOORD1;
    float3 DiffAccum : TEXCOORD2;
    float4 ShadowUV1 : TEXCOORD3;
    float4 ShadowUV2 : TEXCOORD4;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float4 oPos_CallOut0;
    AtTransformPosition(In.Position, g_World, oPos_CallOut0);

	// Function call #1
    float3 oColor_CallOut1;
    float oOpacity_CallOut1;
    AtSplitColorAndOpacity(g_MaterialEmissive, oColor_CallOut1, 
        oOpacity_CallOut1);

	// Function call #2
    float3 oResult_CallOut2;
    AtCalculateLightDiffuse(g_DirDiffuse, g_DirWorldDirection, In.Normal, 
        oResult_CallOut2);

	// Function call #3
    float oResult_CallOut3;
    float4 oWorldViewPos_CallOut3;
    AtCalculateFogAndWorldViewPos(In.Position, g_WorldView, g_FogNearFar, 
        oResult_CallOut3, oWorldViewPos_CallOut3);

	// Function call #4
    float4 oPos_CallOut4;
    AtTransformPosition(oWorldViewPos_CallOut3, CamViewToLightProj_1, 
        oPos_CallOut4);

	// Function call #5
    float4 oPos_CallOut5;
    AtTransformPosition(oWorldViewPos_CallOut3, CamViewToLightProj_2, 
        oPos_CallOut5);

	// Function call #6
    AtTransformPosition(oPos_CallOut0, g_ViewProj, Out.Position);

	// Function call #7
    AtCalculateDSShadowUV(oPos_CallOut4, Out.ShadowUV1);

	// Function call #8
    float3 oResult_CallOut8;
    float oDot_CallOut8;
    AtCalculateLightDiffuseOutDot(g_DirDiffuse0, g_DirWorldDirection0, 
        In.Normal, oResult_CallOut8, oDot_CallOut8);

	// Function call #9
    AtXYZToFloat3(oOpacity_CallOut1, oResult_CallOut3, oDot_CallOut8, 
        Out.OpacityFogDot);

	// Function call #10
    float3 oV_CallOut10;
    AtAddFloat3(oResult_CallOut8, oResult_CallOut2, oV_CallOut10);

	// Function call #11
    AtCalculateDSShadowUV(oPos_CallOut5, Out.ShadowUV2);

	// Function call #12
    AtAddFloat3(oColor_CallOut1, oV_CallOut10, Out.DiffAccum);

    Out.UVSet0 = In.UVSet0;
    return Out;
}

