#line 2 "C:\ATLANTICA\Carpeta vacia\AO RETURNS V3-OFICIAL\Shaders\Generated\NDefaultMaterial\008E0501-00010800-00000000-00A80020-P.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

sampler2D Dark;
sampler2D Base;
float4 g_FogColor;
float FinalColorBright;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

    AtXFromFloat3
    
*/

void AtXFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.x;
    
}
//---------------------------------------------------------------------------
/*

    AtTextureRGBSample
    
*/

void AtTextureRGBSample(float2 iTexCoord,
    sampler2D iSampler,
    out float3 oColor)
{

    oColor.rgb = tex2D( iSampler, iTexCoord ).rgb;
    
}
//---------------------------------------------------------------------------
/*

    AtYFromFloat3
    
*/

void AtYFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.y;
    
}
//---------------------------------------------------------------------------
/*

    AtTextureRGBASample
    
*/

void AtTextureRGBASample(float2 iTexCoord,
    sampler2D iSampler,
    out float3 oColor,
    out float oOpacity)
{

    float4 lSampled = tex2D( iSampler, iTexCoord );
    oColor.rgb = lSampled.rgb;
    oOpacity = lSampled.a;
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat
    
*/

void AtMultplyFloat(float iV1,
    float iV2,
    out float oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat3
    
*/

void AtMultplyFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtLerpFloat3
    
*/

void AtLerpFloat3(float3 iV1,
    float3 iV2,
    float iInterp,
    out float3 oV)
{

	oV = lerp( iV1, iV2, iInterp );
	//oV = float3(1.0f, 1.0f, 1.0f);
    
}
//---------------------------------------------------------------------------
/*

    FinalBright
    
*/

void FinalBright(float3 iColor,
    float iValue,
    out float3 oColor)
{

	oColor = iColor * iValue;
    
}
//---------------------------------------------------------------------------
/*

    AtCompositeColorAndOpacity
    
*/

void AtCompositeColorAndOpacity(float3 iColor,
    float iOpacity,
    out float4 oColor)
{

    oColor.rgb = iColor.rgb;
    oColor.a = iOpacity;
	//oColor.rgb = float3(1.0f, 1.0f, 1.0f);
	//oColor.a = 1.0f;
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float2 UVSet1 : TEXCOORD1;
    float3 OpacityFogDot : TEXCOORD2;
    float3 DiffAccum : TEXCOORD3;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Color : COLOR0;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float oOutput_CallOut0;
    AtXFromFloat3(In.OpacityFogDot, oOutput_CallOut0);

	// Function call #1
    float3 oColor_CallOut1;
    AtTextureRGBSample(In.UVSet1, Dark, oColor_CallOut1);

	// Function call #2
    float oOutput_CallOut2;
    AtYFromFloat3(In.OpacityFogDot, oOutput_CallOut2);

	// Function call #3
    float3 oColor_CallOut3;
    float oOpacity_CallOut3;
    AtTextureRGBASample(In.UVSet0, Base, oColor_CallOut3, oOpacity_CallOut3);

	// Function call #4
    float oV_CallOut4;
    AtMultplyFloat(oOutput_CallOut0, oOpacity_CallOut3, oV_CallOut4);

	// Function call #5
    float3 oV_CallOut5;
    AtMultplyFloat3(oColor_CallOut1, oColor_CallOut3, oV_CallOut5);

	// Function call #6
    float3 oV_CallOut6;
    AtMultplyFloat3(oV_CallOut5, In.DiffAccum, oV_CallOut6);

	// Function call #7
    float3 oV_CallOut7;
    AtLerpFloat3(oV_CallOut6, g_FogColor, oOutput_CallOut2, oV_CallOut7);

	// Function call #8
    float3 oColor_CallOut8;
    FinalBright(oV_CallOut7, FinalColorBright, oColor_CallOut8);

	// Function call #9
    AtCompositeColorAndOpacity(oColor_CallOut8, oV_CallOut4, Out.Color);

    return Out;
}

