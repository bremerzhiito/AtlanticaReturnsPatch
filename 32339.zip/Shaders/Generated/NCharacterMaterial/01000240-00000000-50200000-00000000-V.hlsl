#line 2 "C:\ATLANTICA\Carpeta vacia\AO RETURNS V3-OFICIAL\Shaders\Generated\NCharacterMaterial\01000240-00000000-50200000-00000000-V.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

float4x4 g_World;
float4x4 g_ViewProj;
float4 g_MaterialEmissive;
float4 g_DirDiffuse0;
float4 g_DirWorldDirection0;
float4 g_DirAmbient0;
float4 g_DirDiffuse;
float4 g_DirWorldDirection;
float4 g_DirAmbient;
float4x4 g_WorldView;
float4 g_FogNearFar;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

	AtTransformPosition
	
*/

void AtTransformPosition(float4 iPos,
    float4x4 iMatrix,
    out float4 oPos)
{

	oPos = mul( iPos, iMatrix );
	
}
//---------------------------------------------------------------------------
/*

    AtSplitColorAndOpacity
    
*/

void AtSplitColorAndOpacity(float4 iColor,
    out float3 oColor,
    out float oOpacity)
{

    oColor.rgb = iColor.rgb;
    oOpacity = iColor.a;
    
}
//---------------------------------------------------------------------------
/*

	AtCalculateLightDiffuse
	
*/

void AtCalculateLightDiffuse(float3 iLightDiffuse,
    float3 iLightDirection,
    float3 iSurfaceNormal,
    out float3 oResult)
{

	oResult = iLightDiffuse * max( 0.0f, dot( -iLightDirection, iSurfaceNormal ) );
	
}
//---------------------------------------------------------------------------
/*

	AtCalculateFog
	
*/

void AtCalculateFog(float4 iPos,
    float4x4 iWorldView,
    float2 iFogNearFar,
    out float oResult)
{

	float4 lTransformed = mul( iPos, iWorldView );
	oResult = saturate( ( lTransformed.z - iFogNearFar.x ) / ( iFogNearFar.y - iFogNearFar.x ) );	
	
}
//---------------------------------------------------------------------------
/*

    AtXYZToFloat3
    
*/

void AtXYZToFloat3(float iX,
    float iY,
    float iZ,
    out float3 oOutput)
{

	oOutput = float3( iX, iY, iZ );
    
}
//---------------------------------------------------------------------------
/*

    AtAddFloat3
    
*/

void AtAddFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 + iV2;
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float3 Normal : NORMAL0;
    float2 UVSet0 : TEXCOORD0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float3 OpacityFogDot : TEXCOORD1;
    float3 DiffAccum : TEXCOORD2;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float4 oPos_CallOut0;
    AtTransformPosition(In.Position, g_World, oPos_CallOut0);

	// Function call #1
    float3 oColor_CallOut1;
    float oOpacity_CallOut1;
    AtSplitColorAndOpacity(g_MaterialEmissive, oColor_CallOut1, 
        oOpacity_CallOut1);

	// Function call #2
    float3 oResult_CallOut2;
    AtCalculateLightDiffuse(g_DirDiffuse, g_DirWorldDirection, In.Normal, 
        oResult_CallOut2);

	// Function call #3
    float oResult_CallOut3;
    AtCalculateFog(In.Position, g_WorldView, g_FogNearFar, oResult_CallOut3);

	// Function call #4
    AtTransformPosition(oPos_CallOut0, g_ViewProj, Out.Position);

	// Function call #5
    AtXYZToFloat3(oOpacity_CallOut1, oResult_CallOut3, float(1.0), 
        Out.OpacityFogDot);

	// Function call #6
    float3 oResult_CallOut6;
    AtCalculateLightDiffuse(g_DirDiffuse0, g_DirWorldDirection0, In.Normal, 
        oResult_CallOut6);

	// Function call #7
    float3 oV_CallOut7;
    AtAddFloat3(g_DirAmbient0, oResult_CallOut6, oV_CallOut7);

	// Function call #8
    float3 oV_CallOut8;
    AtAddFloat3(oV_CallOut7, oResult_CallOut2, oV_CallOut8);

	// Function call #9
    float3 oV_CallOut9;
    AtAddFloat3(g_DirAmbient, oV_CallOut8, oV_CallOut9);

	// Function call #10
    AtAddFloat3(oColor_CallOut1, oV_CallOut9, Out.DiffAccum);

    Out.UVSet0 = In.UVSet0;
    return Out;
}

