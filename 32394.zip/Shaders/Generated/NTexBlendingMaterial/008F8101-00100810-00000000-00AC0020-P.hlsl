#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NTexBlendingMaterial\008F8101-00100810-00000000-00AC0020-P.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

sampler2D Shader;
sampler2D Shader1;
sampler2D Shader2;
sampler2D Shader3;
sampler2D Shader4;
float4 g_DirAmbient0;
float4 g_FogColor;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

    AtXFromFloat3
    
*/

void AtXFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.x;
    
}
//---------------------------------------------------------------------------
/*

    AtZFromFloat3
    
*/

void AtZFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.z;
    
}
//---------------------------------------------------------------------------
/*

    AtTextureRGBSample
    
*/

void AtTextureRGBSample(float2 iTexCoord,
    sampler2D iSampler,
    out float3 oColor)
{

    oColor.rgb = tex2D( iSampler, iTexCoord ).rgb;
    
}
//---------------------------------------------------------------------------
/*

    AtCalculateDSShadowIntensity_2
    
*/

void AtCalculateDSShadowIntensity_2(float iLightingDot,
    float4 iUV1,
    sampler2D iSampler1,
    float4 iUV2,
    sampler2D iSampler2,
    sampler2D iMaskSampler,
    out float3 oOutput)
{

	float Intensity1 = 0.0f;	
	float Intensity2 = 0.0f;	
    if( iLightingDot > 0.0f )
    {
		Intensity1 = tex2Dproj( iSampler1, iUV1 ).r;
		Intensity2 = tex2Dproj( iSampler2, iUV2 ).r;
		Intensity2 = lerp( Intensity2, 1.0f, tex2D( iMaskSampler, iUV2.xy ).r );   
    }
    oOutput = min( Intensity1, Intensity2 );
	//oOutput = float3(1.0f, 0.0f, 0.0f);
    
}
//---------------------------------------------------------------------------
/*

    AtYFromFloat3
    
*/

void AtYFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.y;
    
}
//---------------------------------------------------------------------------
/*

    AtSplitColorAndOpacity
    
*/

void AtSplitColorAndOpacity(float4 iColor,
    out float3 oColor,
    out float oOpacity)
{

    oColor.rgb = iColor.rgb;
    oOpacity = iColor.a;
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat3
    
*/

void AtMultplyFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtAddFloat3
    
*/

void AtAddFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 + iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtLerpFloat3
    
*/

void AtLerpFloat3(float3 iV1,
    float3 iV2,
    float iInterp,
    out float3 oV)
{

	oV = lerp( iV1, iV2, iInterp );
	//oV = float3(1.0f, 1.0f, 1.0f);
    
}
//---------------------------------------------------------------------------
/*

    AtCompositeColorAndOpacity
    
*/

void AtCompositeColorAndOpacity(float3 iColor,
    float iOpacity,
    out float4 oColor)
{

    oColor.rgb = iColor.rgb;
    oColor.a = iOpacity;
	//oColor.rgb = float3(1.0f, 1.0f, 1.0f);
	//oColor.a = 1.0f;
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float2 UVSet1 : TEXCOORD1;
    float3 OpacityFogDot : TEXCOORD2;
    float3 DiffAccum : TEXCOORD3;
    float4 ShadowUV1 : TEXCOORD4;
    float4 ShadowUV2 : TEXCOORD5;
    float4 VertexColors : COLOR0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Color : COLOR0;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float oOutput_CallOut0;
    AtXFromFloat3(In.OpacityFogDot, oOutput_CallOut0);

	// Function call #1
    float oOutput_CallOut1;
    AtZFromFloat3(In.OpacityFogDot, oOutput_CallOut1);

	// Function call #2
    float3 oColor_CallOut2;
    AtTextureRGBSample(In.UVSet1, Shader1, oColor_CallOut2);

	// Function call #3
    float3 oOutput_CallOut3;
    AtCalculateDSShadowIntensity_2(oOutput_CallOut1, In.ShadowUV1, Shader3, 
        In.ShadowUV2, Shader4, Shader2, oOutput_CallOut3);

	// Function call #4
    float oOutput_CallOut4;
    AtYFromFloat3(In.OpacityFogDot, oOutput_CallOut4);

	// Function call #5
    float3 oColor_CallOut5;
    float oOpacity_CallOut5;
    AtSplitColorAndOpacity(In.VertexColors, oColor_CallOut5, oOpacity_CallOut5);

	// Function call #6
    float3 oV_CallOut6;
    AtMultplyFloat3(In.DiffAccum, oOutput_CallOut3, oV_CallOut6);

	// Function call #7
    float3 oColor_CallOut7;
    AtTextureRGBSample(In.UVSet0, Shader, oColor_CallOut7);

	// Function call #8
    float3 oV_CallOut8;
    AtAddFloat3(oV_CallOut6, g_DirAmbient0, oV_CallOut8);

	// Function call #9
    float3 oV_CallOut9;
    AtLerpFloat3(oColor_CallOut2, oColor_CallOut7, oOpacity_CallOut5, 
        oV_CallOut9);

	// Function call #10
    float3 oV_CallOut10;
    AtMultplyFloat3(oV_CallOut9, oV_CallOut8, oV_CallOut10);

	// Function call #11
    float3 oV_CallOut11;
    AtLerpFloat3(oV_CallOut10, g_FogColor, oOutput_CallOut4, oV_CallOut11);

	// Function call #12
    AtCompositeColorAndOpacity(oV_CallOut11, oOutput_CallOut0, Out.Color);

    return Out;
}

