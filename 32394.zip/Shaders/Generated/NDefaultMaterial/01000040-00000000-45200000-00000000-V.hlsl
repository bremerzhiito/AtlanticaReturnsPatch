#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NDefaultMaterial\01000040-00000000-45200000-00000000-V.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

float4x4 g_World;
float4x4 g_ViewProj;
float4 g_MaterialEmissive;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

    AtSplitColorAndOpacity
    
*/

void AtSplitColorAndOpacity(float4 iColor,
    out float3 oColor,
    out float oOpacity)
{

    oColor.rgb = iColor.rgb;
    oOpacity = iColor.a;
    
}
//---------------------------------------------------------------------------
/*

	AtTransformPosition
	
*/

void AtTransformPosition(float4 iPos,
    float4x4 iMatrix,
    out float4 oPos)
{

	oPos = mul( iPos, iMatrix );
	
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat
    
*/

void AtMultplyFloat(float iV1,
    float iV2,
    out float oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtXYZToFloat3
    
*/

void AtXYZToFloat3(float iX,
    float iY,
    float iZ,
    out float3 oOutput)
{

	oOutput = float3( iX, iY, iZ );
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat3
    
*/

void AtMultplyFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float3 Normal : NORMAL0;
    float2 UVSet0 : TEXCOORD0;
    float4 VertexColors : COLOR0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float3 OpacityFogDot : TEXCOORD1;
    float3 DiffAccum : TEXCOORD2;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float3 oColor_CallOut0;
    float oOpacity_CallOut0;
    AtSplitColorAndOpacity(In.VertexColors, oColor_CallOut0, oOpacity_CallOut0);

	// Function call #1
    float4 oPos_CallOut1;
    AtTransformPosition(In.Position, g_World, oPos_CallOut1);

	// Function call #2
    float3 oColor_CallOut2;
    float oOpacity_CallOut2;
    AtSplitColorAndOpacity(g_MaterialEmissive, oColor_CallOut2, 
        oOpacity_CallOut2);

	// Function call #3
    float oV_CallOut3;
    AtMultplyFloat(oOpacity_CallOut2, oOpacity_CallOut0, oV_CallOut3);

	// Function call #4
    AtTransformPosition(oPos_CallOut1, g_ViewProj, Out.Position);

	// Function call #5
    AtXYZToFloat3(oV_CallOut3, float(0.0), float(1.0), Out.OpacityFogDot);

	// Function call #6
    AtMultplyFloat3(oColor_CallOut2, oColor_CallOut0, Out.DiffAccum);

    Out.UVSet0 = In.UVSet0;
    return Out;
}

