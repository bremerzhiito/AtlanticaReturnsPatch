#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NDefaultMaterial\01000200-00000000-40000000-00000000-V.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

float4x4 g_World;
float4x4 g_ViewProj;
float4 g_MaterialEmissive;
float4x4 g_WorldView;
float4 g_FogNearFar;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

	AtTransformPosition
	
*/

void AtTransformPosition(float4 iPos,
    float4x4 iMatrix,
    out float4 oPos)
{

	oPos = mul( iPos, iMatrix );
	
}
//---------------------------------------------------------------------------
/*

    AtSplitColorAndOpacity
    
*/

void AtSplitColorAndOpacity(float4 iColor,
    out float3 oColor,
    out float oOpacity)
{

    oColor.rgb = iColor.rgb;
    oOpacity = iColor.a;
    
}
//---------------------------------------------------------------------------
/*

	AtCalculateFog
	
*/

void AtCalculateFog(float4 iPos,
    float4x4 iWorldView,
    float2 iFogNearFar,
    out float oResult)
{

	float4 lTransformed = mul( iPos, iWorldView );
	oResult = saturate( ( lTransformed.z - iFogNearFar.x ) / ( iFogNearFar.y - iFogNearFar.x ) );	
	
}
//---------------------------------------------------------------------------
/*

    AtXYZToFloat3
    
*/

void AtXYZToFloat3(float iX,
    float iY,
    float iZ,
    out float3 oOutput)
{

	oOutput = float3( iX, iY, iZ );
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float3 Normal : NORMAL0;
    float2 UVSet0 : TEXCOORD0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float3 OpacityFogDot : TEXCOORD1;
    float3 DiffAccum : TEXCOORD2;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float4 oPos_CallOut0;
    AtTransformPosition(In.Position, g_World, oPos_CallOut0);

	// Function call #1
    float oOpacity_CallOut1;
    AtSplitColorAndOpacity(g_MaterialEmissive, Out.DiffAccum, oOpacity_CallOut1);

	// Function call #2
    AtTransformPosition(oPos_CallOut0, g_ViewProj, Out.Position);

	// Function call #3
    float oResult_CallOut3;
    AtCalculateFog(In.Position, g_WorldView, g_FogNearFar, oResult_CallOut3);

	// Function call #4
    AtXYZToFloat3(oOpacity_CallOut1, oResult_CallOut3, float(1.0), 
        Out.OpacityFogDot);

    Out.UVSet0 = In.UVSet0;
    return Out;
}

