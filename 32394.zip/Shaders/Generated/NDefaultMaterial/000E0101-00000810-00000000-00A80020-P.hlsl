#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NDefaultMaterial\000E0101-00000810-00000000-00A80020-P.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

sampler2D Base;
sampler2D Shader2;
sampler2D Shader3;
sampler2D Shader4;
float4 g_DirAmbient0;
float FinalColorBright;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

    AtXFromFloat3
    
*/

void AtXFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.x;
    
}
//---------------------------------------------------------------------------
/*

    AtTextureRGBASample
    
*/

void AtTextureRGBASample(float2 iTexCoord,
    sampler2D iSampler,
    out float3 oColor,
    out float oOpacity)
{

    float4 lSampled = tex2D( iSampler, iTexCoord );
    oColor.rgb = lSampled.rgb;
    oOpacity = lSampled.a;
    
}
//---------------------------------------------------------------------------
/*

    AtZFromFloat3
    
*/

void AtZFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.z;
    
}
//---------------------------------------------------------------------------
/*

    AtCalculateDSShadowIntensity_2
    
*/

void AtCalculateDSShadowIntensity_2(float iLightingDot,
    float4 iUV1,
    sampler2D iSampler1,
    float4 iUV2,
    sampler2D iSampler2,
    sampler2D iMaskSampler,
    out float3 oOutput)
{

	float Intensity1 = 0.0f;	
	float Intensity2 = 0.0f;	
    if( iLightingDot > 0.0f )
    {
		Intensity1 = tex2Dproj( iSampler1, iUV1 ).r;
		Intensity2 = tex2Dproj( iSampler2, iUV2 ).r;
		Intensity2 = lerp( Intensity2, 1.0f, tex2D( iMaskSampler, iUV2.xy ).r );   
    }
    oOutput = min( Intensity1, Intensity2 );
	//oOutput = float3(1.0f, 0.0f, 0.0f);
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat
    
*/

void AtMultplyFloat(float iV1,
    float iV2,
    out float oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat3
    
*/

void AtMultplyFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtAddFloat3
    
*/

void AtAddFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 + iV2;
    
}
//---------------------------------------------------------------------------
/*

    FinalBright
    
*/

void FinalBright(float3 iColor,
    float iValue,
    out float3 oColor)
{

	oColor = iColor * iValue;
    
}
//---------------------------------------------------------------------------
/*

    AtCompositeColorAndOpacity
    
*/

void AtCompositeColorAndOpacity(float3 iColor,
    float iOpacity,
    out float4 oColor)
{

    oColor.rgb = iColor.rgb;
    oColor.a = iOpacity;
	//oColor.rgb = float3(1.0f, 1.0f, 1.0f);
	//oColor.a = 1.0f;
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float3 OpacityFogDot : TEXCOORD1;
    float3 DiffAccum : TEXCOORD2;
    float4 ShadowUV1 : TEXCOORD3;
    float4 ShadowUV2 : TEXCOORD4;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Color : COLOR0;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float oOutput_CallOut0;
    AtXFromFloat3(In.OpacityFogDot, oOutput_CallOut0);

	// Function call #1
    float3 oColor_CallOut1;
    float oOpacity_CallOut1;
    AtTextureRGBASample(In.UVSet0, Base, oColor_CallOut1, oOpacity_CallOut1);

	// Function call #2
    float oOutput_CallOut2;
    AtZFromFloat3(In.OpacityFogDot, oOutput_CallOut2);

	// Function call #3
    float3 oOutput_CallOut3;
    AtCalculateDSShadowIntensity_2(oOutput_CallOut2, In.ShadowUV1, Shader3, 
        In.ShadowUV2, Shader4, Shader2, oOutput_CallOut3);

	// Function call #4
    float oV_CallOut4;
    AtMultplyFloat(oOutput_CallOut0, oOpacity_CallOut1, oV_CallOut4);

	// Function call #5
    float3 oV_CallOut5;
    AtMultplyFloat3(In.DiffAccum, oOutput_CallOut3, oV_CallOut5);

	// Function call #6
    float3 oV_CallOut6;
    AtAddFloat3(oV_CallOut5, g_DirAmbient0, oV_CallOut6);

	// Function call #7
    float3 oV_CallOut7;
    AtMultplyFloat3(oColor_CallOut1, oV_CallOut6, oV_CallOut7);

	// Function call #8
    float3 oColor_CallOut8;
    FinalBright(oV_CallOut7, FinalColorBright, oColor_CallOut8);

	// Function call #9
    AtCompositeColorAndOpacity(oColor_CallOut8, oV_CallOut4, Out.Color);

    return Out;
}

