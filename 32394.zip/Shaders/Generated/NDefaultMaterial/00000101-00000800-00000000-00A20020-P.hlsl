#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NDefaultMaterial\00000101-00000800-00000000-00A20020-P.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

sampler2D Base;
float FinalColorBright;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

    AtXFromFloat3
    
*/

void AtXFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.x;
    
}
//---------------------------------------------------------------------------
/*

    AtTextureRGBASample
    
*/

void AtTextureRGBASample(float2 iTexCoord,
    sampler2D iSampler,
    out float3 oColor,
    out float oOpacity)
{

    float4 lSampled = tex2D( iSampler, iTexCoord );
    oColor.rgb = lSampled.rgb;
    oOpacity = lSampled.a;
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat3
    
*/

void AtMultplyFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat
    
*/

void AtMultplyFloat(float iV1,
    float iV2,
    out float oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    FinalBright
    
*/

void FinalBright(float3 iColor,
    float iValue,
    out float3 oColor)
{

	oColor = iColor * iValue;
    
}
//---------------------------------------------------------------------------
/*

    AtCompositeColorAndOpacity
    
*/

void AtCompositeColorAndOpacity(float3 iColor,
    float iOpacity,
    out float4 oColor)
{

    oColor.rgb = iColor.rgb;
    oColor.a = iOpacity;
	//oColor.rgb = float3(1.0f, 1.0f, 1.0f);
	//oColor.a = 1.0f;
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float3 OpacityFogDot : TEXCOORD1;
    float3 DiffAccum : TEXCOORD2;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Color : COLOR0;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float oOutput_CallOut0;
    AtXFromFloat3(In.OpacityFogDot, oOutput_CallOut0);

	// Function call #1
    float3 oColor_CallOut1;
    float oOpacity_CallOut1;
    AtTextureRGBASample(In.UVSet0, Base, oColor_CallOut1, oOpacity_CallOut1);

	// Function call #2
    float3 oV_CallOut2;
    AtMultplyFloat3(oColor_CallOut1, In.DiffAccum, oV_CallOut2);

	// Function call #3
    float oV_CallOut3;
    AtMultplyFloat(oOutput_CallOut0, oOpacity_CallOut1, oV_CallOut3);

	// Function call #4
    float3 oColor_CallOut4;
    FinalBright(oV_CallOut2, FinalColorBright, oColor_CallOut4);

	// Function call #5
    AtCompositeColorAndOpacity(oColor_CallOut4, oV_CallOut3, Out.Color);

    return Out;
}

