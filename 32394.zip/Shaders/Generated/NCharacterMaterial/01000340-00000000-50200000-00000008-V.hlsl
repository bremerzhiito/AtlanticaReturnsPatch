#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NCharacterMaterial\01000340-00000000-50200000-00000008-V.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

float4x4 g_World;
float4x4 g_ViewProj;
float4 g_MaterialEmissive;
float4 g_MaterialSpecular;
float4 g_MaterialPower;
float4 g_EyeDir;
float4 g_DirDiffuse0;
float4 g_DirWorldDirection0;
float4 g_DirAmbient0;
float4 g_DirSpecular0;
float4 g_DirDiffuse;
float4 g_DirWorldDirection;
float4 g_DirAmbient;
float4 g_DirSpecular;
float4x4 g_WorldView;
float4 g_FogNearFar;
float g_CharacterAlpha;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

	AtTransformPosition
	
*/

void AtTransformPosition(float4 iPos,
    float4x4 iMatrix,
    out float4 oPos)
{

	oPos = mul( iPos, iMatrix );
	
}
//---------------------------------------------------------------------------
/*

    AtSplitColorAndOpacity
    
*/

void AtSplitColorAndOpacity(float4 iColor,
    out float3 oColor,
    out float oOpacity)
{

    oColor.rgb = iColor.rgb;
    oOpacity = iColor.a;
    
}
//---------------------------------------------------------------------------
/*

	AtCalculateLightSpecular
	
*/

void AtCalculateLightSpecular(float3 iMatSpecular,
    float4 iMatPower,
    float3 iLightSpecular,
    float3 iEyeDir,
    float3 iLightDir,
    float3 iSurfaceNormal,
    out float3 oResult)
{

   	// Get the half vector.
	float3 HalfVector = -normalize( iEyeDir + iLightDir );
	
	// Determine specular intensity.
	float LightNDotH = max( 0.0f, dot( iSurfaceNormal, HalfVector ) );
	float LightSpecIntensity = pow( LightNDotH, iMatPower.x );
	
	oResult = iMatSpecular * iLightSpecular * LightSpecIntensity;
	
}
//---------------------------------------------------------------------------
/*

	AtCalculateFog
	
*/

void AtCalculateFog(float4 iPos,
    float4x4 iWorldView,
    float2 iFogNearFar,
    out float oResult)
{

	float4 lTransformed = mul( iPos, iWorldView );
	oResult = saturate( ( lTransformed.z - iFogNearFar.x ) / ( iFogNearFar.y - iFogNearFar.x ) );	
	
}
//---------------------------------------------------------------------------
/*

	AtCalculateLightDiffuse
	
*/

void AtCalculateLightDiffuse(float3 iLightDiffuse,
    float3 iLightDirection,
    float3 iSurfaceNormal,
    out float3 oResult)
{

	oResult = iLightDiffuse * max( 0.0f, dot( -iLightDirection, iSurfaceNormal ) );
	
}
//---------------------------------------------------------------------------
/*

    AtAddFloat3
    
*/

void AtAddFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 + iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat
    
*/

void AtMultplyFloat(float iV1,
    float iV2,
    out float oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtXYZToFloat3
    
*/

void AtXYZToFloat3(float iX,
    float iY,
    float iZ,
    out float3 oOutput)
{

	oOutput = float3( iX, iY, iZ );
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float3 Normal : NORMAL0;
    float2 UVSet0 : TEXCOORD0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float3 OpacityFogDot : TEXCOORD1;
    float3 DiffAccum : TEXCOORD2;
    float3 SpecAccum : TEXCOORD3;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float4 oPos_CallOut0;
    AtTransformPosition(In.Position, g_World, oPos_CallOut0);

	// Function call #1
    float3 oColor_CallOut1;
    float oOpacity_CallOut1;
    AtSplitColorAndOpacity(g_MaterialEmissive, oColor_CallOut1, 
        oOpacity_CallOut1);

	// Function call #2
    float3 oResult_CallOut2;
    AtCalculateLightSpecular(g_MaterialSpecular, g_MaterialPower, 
        g_DirSpecular0, g_EyeDir, g_DirWorldDirection0, In.Normal, 
        oResult_CallOut2);

	// Function call #3
    float3 oResult_CallOut3;
    AtCalculateLightSpecular(g_MaterialSpecular, g_MaterialPower, g_DirSpecular, 
        g_EyeDir, g_DirWorldDirection, In.Normal, oResult_CallOut3);

	// Function call #4
    float oResult_CallOut4;
    AtCalculateFog(In.Position, g_WorldView, g_FogNearFar, oResult_CallOut4);

	// Function call #5
    AtTransformPosition(oPos_CallOut0, g_ViewProj, Out.Position);

	// Function call #6
    float3 oResult_CallOut6;
    AtCalculateLightDiffuse(g_DirDiffuse, g_DirWorldDirection, In.Normal, 
        oResult_CallOut6);

	// Function call #7
    AtAddFloat3(oResult_CallOut2, oResult_CallOut3, Out.SpecAccum);

	// Function call #8
    float oV_CallOut8;
    AtMultplyFloat(g_CharacterAlpha, oOpacity_CallOut1, oV_CallOut8);

	// Function call #9
    float3 oResult_CallOut9;
    AtCalculateLightDiffuse(g_DirDiffuse0, g_DirWorldDirection0, In.Normal, 
        oResult_CallOut9);

	// Function call #10
    AtXYZToFloat3(oV_CallOut8, oResult_CallOut4, float(1.0), Out.OpacityFogDot);

	// Function call #11
    float3 oV_CallOut11;
    AtAddFloat3(g_DirAmbient0, oResult_CallOut9, oV_CallOut11);

	// Function call #12
    float3 oV_CallOut12;
    AtAddFloat3(oV_CallOut11, oResult_CallOut6, oV_CallOut12);

	// Function call #13
    float3 oV_CallOut13;
    AtAddFloat3(g_DirAmbient, oV_CallOut12, oV_CallOut13);

	// Function call #14
    AtAddFloat3(oColor_CallOut1, oV_CallOut13, Out.DiffAccum);

    Out.UVSet0 = In.UVSet0;
    return Out;
}

