#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NCharacterMaterial\00800101-00000800-00000000-02AC0020-P.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

sampler2D Base;
float4 g_FogColor;
float4 g_CharacterBrighten;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

    AtXFromFloat3
    
*/

void AtXFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.x;
    
}
//---------------------------------------------------------------------------
/*

    AtTextureRGBASample
    
*/

void AtTextureRGBASample(float2 iTexCoord,
    sampler2D iSampler,
    out float3 oColor,
    out float oOpacity)
{

    float4 lSampled = tex2D( iSampler, iTexCoord );
    oColor.rgb = lSampled.rgb;
    oOpacity = lSampled.a;
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat3
    
*/

void AtMultplyFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtYFromFloat3
    
*/

void AtYFromFloat3(float3 iInput,
    out float oOutput)
{

	oOutput = iInput.y;
    
}
//---------------------------------------------------------------------------
/*

    AtLerpFloat3
    
*/

void AtLerpFloat3(float3 iV1,
    float3 iV2,
    float iInterp,
    out float3 oV)
{

	oV = lerp( iV1, iV2, iInterp );
	//oV = float3(1.0f, 1.0f, 1.0f);
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat
    
*/

void AtMultplyFloat(float iV1,
    float iV2,
    out float oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

	 AtBrighten
    
*/

void AtBrighten(float3 iColor,
    float3 iBrighten,
    out float3 oColor)
{

    oColor = iColor + ( 1.0f - iColor ) * iBrighten;
    
}
//---------------------------------------------------------------------------
/*

    AtCompositeColorAndOpacity
    
*/

void AtCompositeColorAndOpacity(float3 iColor,
    float iOpacity,
    out float4 oColor)
{

    oColor.rgb = iColor.rgb;
    oColor.a = iOpacity;
	//oColor.rgb = float3(1.0f, 1.0f, 1.0f);
	//oColor.a = 1.0f;
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float3 OpacityFogDot : TEXCOORD1;
    float3 DiffAccum : TEXCOORD2;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Color : COLOR0;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float oOutput_CallOut0;
    AtXFromFloat3(In.OpacityFogDot, oOutput_CallOut0);

	// Function call #1
    float3 oColor_CallOut1;
    float oOpacity_CallOut1;
    AtTextureRGBASample(In.UVSet0, Base, oColor_CallOut1, oOpacity_CallOut1);

	// Function call #2
    float3 oV_CallOut2;
    AtMultplyFloat3(oColor_CallOut1, In.DiffAccum, oV_CallOut2);

	// Function call #3
    float oOutput_CallOut3;
    AtYFromFloat3(In.OpacityFogDot, oOutput_CallOut3);

	// Function call #4
    float3 oV_CallOut4;
    AtLerpFloat3(oV_CallOut2, g_FogColor, oOutput_CallOut3, oV_CallOut4);

	// Function call #5
    float oV_CallOut5;
    AtMultplyFloat(oOutput_CallOut0, oOpacity_CallOut1, oV_CallOut5);

	// Function call #6
    float3 oColor_CallOut6;
    AtBrighten(oV_CallOut4, g_CharacterBrighten, oColor_CallOut6);

	// Function call #7
    AtCompositeColorAndOpacity(oColor_CallOut6, oV_CallOut5, Out.Color);

    return Out;
}

