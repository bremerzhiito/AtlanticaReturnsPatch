#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NCharacterMaterial\01000341-00000000-59200000-00000000-V.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

BONEMATRIX_TYPE g_SkinBoneMatrix3[20];
float4x4 g_World;
float4x4 g_ViewProj;
float4 g_MaterialEmissive;
float4 g_MaterialSpecular;
float4 g_MaterialPower;
float4 g_EyeDir;
float4 g_DirDiffuse0;
float4 g_DirWorldDirection0;
float4 g_DirAmbient0;
float4 g_DirSpecular0;
float4 g_DirDiffuse;
float4 g_DirWorldDirection;
float4 g_DirAmbient;
float4 g_DirSpecular;
float4x4 g_WorldView;
float4 g_FogNearFar;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

	AtCalculateSkinBoneTransform
    
*/

void AtCalculateSkinBoneTransform(int4 iBlendIndices,
    float4 iBlendWeights,
    BONEMATRIX_TYPE iBones[20],
    out float4x4 oSkinBoneTransform)
{

    // TransformSkinnedPosition *********************************************
    // Transform the skinned position into world space
    // Composite the skinning transform which will take the vertex
    // and normal to world space.
    float fWeight3 = 1.0 - iBlendWeights[0] - iBlendWeights[1] - iBlendWeights[2];
    BONEMATRIX_TYPE ShortSkinBoneTransform;
    ShortSkinBoneTransform  = iBones[iBlendIndices[0]] * iBlendWeights[0];
    ShortSkinBoneTransform += iBones[iBlendIndices[1]] * iBlendWeights[1];
    ShortSkinBoneTransform += iBones[iBlendIndices[2]] * iBlendWeights[2];
    ShortSkinBoneTransform += iBones[iBlendIndices[3]] * fWeight3;
    oSkinBoneTransform = float4x4(
		ShortSkinBoneTransform[0], 0.0f, 
        ShortSkinBoneTransform[1], 0.0f, 
        ShortSkinBoneTransform[2], 0.0f, 
        ShortSkinBoneTransform[3], 1.0f );
    
}
//---------------------------------------------------------------------------
/*

	AtTransformNormal
	
*/

void AtTransformNormal(float3 iNormal,
    float4x4 iWorld,
    out float3 oNormal)
{

	oNormal = normalize( mul( iNormal, (float3x3)iWorld ) );
	
}
//---------------------------------------------------------------------------
/*

	AtCalculateLightDiffuse
	
*/

void AtCalculateLightDiffuse(float3 iLightDiffuse,
    float3 iLightDirection,
    float3 iSurfaceNormal,
    out float3 oResult)
{

	oResult = iLightDiffuse * max( 0.0f, dot( -iLightDirection, iSurfaceNormal ) );
	
}
//---------------------------------------------------------------------------
/*

	AtCalculateLightSpecular
	
*/

void AtCalculateLightSpecular(float3 iMatSpecular,
    float4 iMatPower,
    float3 iLightSpecular,
    float3 iEyeDir,
    float3 iLightDir,
    float3 iSurfaceNormal,
    out float3 oResult)
{

   	// Get the half vector.
	float3 HalfVector = -normalize( iEyeDir + iLightDir );
	
	// Determine specular intensity.
	float LightNDotH = max( 0.0f, dot( iSurfaceNormal, HalfVector ) );
	float LightSpecIntensity = pow( LightNDotH, iMatPower.x );
	
	oResult = iMatSpecular * iLightSpecular * LightSpecIntensity;
	
}
//---------------------------------------------------------------------------
/*

	AtCalculateFog
	
*/

void AtCalculateFog(float4 iPos,
    float4x4 iWorldView,
    float2 iFogNearFar,
    out float oResult)
{

	float4 lTransformed = mul( iPos, iWorldView );
	oResult = saturate( ( lTransformed.z - iFogNearFar.x ) / ( iFogNearFar.y - iFogNearFar.x ) );	
	
}
//---------------------------------------------------------------------------
/*

	AtTransformPosition
	
*/

void AtTransformPosition(float4 iPos,
    float4x4 iMatrix,
    out float4 oPos)
{

	oPos = mul( iPos, iMatrix );
	
}
//---------------------------------------------------------------------------
/*

    AtSplitColorAndOpacity
    
*/

void AtSplitColorAndOpacity(float4 iColor,
    out float3 oColor,
    out float oOpacity)
{

    oColor.rgb = iColor.rgb;
    oOpacity = iColor.a;
    
}
//---------------------------------------------------------------------------
/*

    AtAddFloat3
    
*/

void AtAddFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 + iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtXYZToFloat3
    
*/

void AtXYZToFloat3(float iX,
    float iY,
    float iZ,
    out float3 oOutput)
{

	oOutput = float3( iX, iY, iZ );
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float4 BlendWeights : BLENDWEIGHT0;
    int4 BlendIndices : BLENDINDICES0;
    float3 Normal : NORMAL0;
    float2 UVSet0 : TEXCOORD0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Position : POSITION0;
    float2 UVSet0 : TEXCOORD0;
    float3 OpacityFogDot : TEXCOORD1;
    float3 DiffAccum : TEXCOORD2;
    float3 SpecAccum : TEXCOORD3;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float4x4 oSkinBoneTransform_CallOut0;
    AtCalculateSkinBoneTransform(In.BlendIndices, In.BlendWeights, 
        g_SkinBoneMatrix3, oSkinBoneTransform_CallOut0);

	// Function call #1
    float3 oNormal_CallOut1;
    AtTransformNormal(In.Normal, oSkinBoneTransform_CallOut0, oNormal_CallOut1);

	// Function call #2
    float3 oResult_CallOut2;
    AtCalculateLightDiffuse(g_DirDiffuse0, g_DirWorldDirection0, 
        oNormal_CallOut1, oResult_CallOut2);

	// Function call #3
    float3 oResult_CallOut3;
    AtCalculateLightSpecular(g_MaterialSpecular, g_MaterialPower, 
        g_DirSpecular0, g_EyeDir, g_DirWorldDirection0, oNormal_CallOut1, 
        oResult_CallOut3);

	// Function call #4
    float3 oResult_CallOut4;
    AtCalculateLightSpecular(g_MaterialSpecular, g_MaterialPower, g_DirSpecular, 
        g_EyeDir, g_DirWorldDirection, oNormal_CallOut1, oResult_CallOut4);

	// Function call #5
    float oResult_CallOut5;
    AtCalculateFog(In.Position, g_WorldView, g_FogNearFar, oResult_CallOut5);

	// Function call #6
    float4 oPos_CallOut6;
    AtTransformPosition(In.Position, oSkinBoneTransform_CallOut0, oPos_CallOut6);

	// Function call #7
    float3 oColor_CallOut7;
    float oOpacity_CallOut7;
    AtSplitColorAndOpacity(g_MaterialEmissive, oColor_CallOut7, 
        oOpacity_CallOut7);

	// Function call #8
    float3 oResult_CallOut8;
    AtCalculateLightDiffuse(g_DirDiffuse, g_DirWorldDirection, oNormal_CallOut1, 
        oResult_CallOut8);

	// Function call #9
    AtAddFloat3(oResult_CallOut3, oResult_CallOut4, Out.SpecAccum);

	// Function call #10
    AtXYZToFloat3(oOpacity_CallOut7, oResult_CallOut5, float(1.0), 
        Out.OpacityFogDot);

	// Function call #11
    AtTransformPosition(oPos_CallOut6, g_ViewProj, Out.Position);

	// Function call #12
    float3 oV_CallOut12;
    AtAddFloat3(g_DirAmbient0, oResult_CallOut2, oV_CallOut12);

	// Function call #13
    float3 oV_CallOut13;
    AtAddFloat3(oV_CallOut12, oResult_CallOut8, oV_CallOut13);

	// Function call #14
    float3 oV_CallOut14;
    AtAddFloat3(g_DirAmbient, oV_CallOut13, oV_CallOut14);

	// Function call #15
    AtAddFloat3(oColor_CallOut7, oV_CallOut14, Out.DiffAccum);

    Out.UVSet0 = In.UVSet0;
    return Out;
}

