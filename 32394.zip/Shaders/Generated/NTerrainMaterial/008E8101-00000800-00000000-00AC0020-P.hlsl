#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NTerrainMaterial\008E8101-00000800-00000000-00AC0020-P.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

sampler2D Base;
sampler2D Shader;
float4 g_FogColor;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

    AtSplitBaseUVFogDot
    
*/

void AtSplitBaseUVFogDot(float4 iInput,
    out float2 oBaseUV,
    out float oFog,
    out float oDot)
{

    oBaseUV = iInput.xy;
    oFog = iInput.z;
    oDot = iInput.w;
    
}
//---------------------------------------------------------------------------
/*

    AtSplitTwoUV
    
*/

void AtSplitTwoUV(float4 iInput,
    out float2 oUV1,
    out float2 oUV2)
{

    oUV1 = iInput.xy;
    oUV2 = iInput.zw;
    
}
//---------------------------------------------------------------------------
/*

    AtTextureRGBASample
    
*/

void AtTextureRGBASample(float2 iTexCoord,
    sampler2D iSampler,
    out float3 oColor,
    out float oOpacity)
{

    float4 lSampled = tex2D( iSampler, iTexCoord );
    oColor.rgb = lSampled.rgb;
    oOpacity = lSampled.a;
    
}
//---------------------------------------------------------------------------
/*

    AtSplitColorAndOpacity
    
*/

void AtSplitColorAndOpacity(float4 iColor,
    out float3 oColor,
    out float oOpacity)
{

    oColor.rgb = iColor.rgb;
    oOpacity = iColor.a;
    
}
//---------------------------------------------------------------------------
/*

    AtTextureRGBSample
    
*/

void AtTextureRGBSample(float2 iTexCoord,
    sampler2D iSampler,
    out float3 oColor)
{

    oColor.rgb = tex2D( iSampler, iTexCoord ).rgb;
    
}
//---------------------------------------------------------------------------
/*

    AtLerpFloat3
    
*/

void AtLerpFloat3(float3 iV1,
    float3 iV2,
    float iInterp,
    out float3 oV)
{

	oV = lerp( iV1, iV2, iInterp );
	//oV = float3(1.0f, 1.0f, 1.0f);
    
}
//---------------------------------------------------------------------------
/*

    AtMultplyFloat3
    
*/

void AtMultplyFloat3(float3 iV1,
    float3 iV2,
    out float3 oV)
{

    oV = iV1 * iV2;
    
}
//---------------------------------------------------------------------------
/*

    AtCompositeColorAndOpacity
    
*/

void AtCompositeColorAndOpacity(float3 iColor,
    float iOpacity,
    out float4 oColor)
{

    oColor.rgb = iColor.rgb;
    oColor.a = iOpacity;
	//oColor.rgb = float3(1.0f, 1.0f, 1.0f);
	//oColor.a = 1.0f;
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float3 DiffAccum : TEXCOORD0;
    float4 BaseUVFogDot : TEXCOORD1;
    float4 UVSet0 : TEXCOORD2;
    float4 UVSet1 : TEXCOORD3;
    float4 VertexColors : COLOR0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Color : COLOR0;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    float2 oBaseUV_CallOut0;
    float oFog_CallOut0;
    float oDot_CallOut0;
    AtSplitBaseUVFogDot(In.BaseUVFogDot, oBaseUV_CallOut0, oFog_CallOut0, 
        oDot_CallOut0);

	// Function call #1
    float2 oUV1_CallOut1;
    float2 oUV2_CallOut1;
    AtSplitTwoUV(In.UVSet0, oUV1_CallOut1, oUV2_CallOut1);

	// Function call #2
    float3 oColor_CallOut2;
    float oOpacity_CallOut2;
    AtTextureRGBASample(oUV2_CallOut1, Shader, oColor_CallOut2, 
        oOpacity_CallOut2);

	// Function call #3
    float2 oUV1_CallOut3;
    float2 oUV2_CallOut3;
    AtSplitTwoUV(In.UVSet1, oUV1_CallOut3, oUV2_CallOut3);

	// Function call #4
    float3 oColor_CallOut4;
    float oOpacity_CallOut4;
    AtTextureRGBASample(oUV2_CallOut3, Shader, oColor_CallOut4, 
        oOpacity_CallOut4);

	// Function call #5
    float3 oColor_CallOut5;
    float oOpacity_CallOut5;
    AtSplitColorAndOpacity(In.VertexColors, oColor_CallOut5, oOpacity_CallOut5);

	// Function call #6
    float3 oColor_CallOut6;
    AtTextureRGBSample(oBaseUV_CallOut0, Base, oColor_CallOut6);

	// Function call #7
    float3 oColor_CallOut7;
    AtTextureRGBSample(oUV1_CallOut3, Base, oColor_CallOut7);

	// Function call #8
    float3 oColor_CallOut8;
    AtTextureRGBSample(oUV1_CallOut1, Base, oColor_CallOut8);

	// Function call #9
    float3 oV_CallOut9;
    AtLerpFloat3(oColor_CallOut6, oColor_CallOut8, oOpacity_CallOut2, 
        oV_CallOut9);

	// Function call #10
    float3 oV_CallOut10;
    AtLerpFloat3(oV_CallOut9, oColor_CallOut7, oOpacity_CallOut4, oV_CallOut10);

	// Function call #11
    float3 oV_CallOut11;
    AtLerpFloat3(oV_CallOut10, oColor_CallOut5, oOpacity_CallOut5, oV_CallOut11);

	// Function call #12
    float3 oV_CallOut12;
    AtMultplyFloat3(oV_CallOut11, In.DiffAccum, oV_CallOut12);

	// Function call #13
    float3 oV_CallOut13;
    AtLerpFloat3(oV_CallOut12, g_FogColor, oFog_CallOut0, oV_CallOut13);

	// Function call #14
    AtCompositeColorAndOpacity(oV_CallOut13, float(1.0f), Out.Color);

    return Out;
}

