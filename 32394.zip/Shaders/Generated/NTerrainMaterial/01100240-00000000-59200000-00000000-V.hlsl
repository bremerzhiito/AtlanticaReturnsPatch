#line 2 "C:\ATLANTICA\VERSION CLIENTE SERVIDOR\AOReturnsOficial\Shaders\Generated\NTerrainMaterial\01100240-00000000-59200000-00000000-V.hlsl"
/*
Shader description:

*/

//---------------------------------------------------------------------------
// Types:
#if defined(DIRECT3D)
#define BONEMATRIX_TYPE float4x3
#else
#define BONEMATRIX_TYPE float3x4
#endif
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Constant variables:
//---------------------------------------------------------------------------

float4x4 g_World;
float4x4 g_ViewProj;
float4 g_DirDiffuse0;
float4 g_DirWorldDirection0;
float4x4 g_WorldView;
float4 g_FogNearFar;
float4x4 CamViewToLightProj_1;
float4x4 CamViewToLightProj_2;
//---------------------------------------------------------------------------
// Functions:
//---------------------------------------------------------------------------

/*

    AtCompositeTwoUV
    
*/

void AtCompositeTwoUV(float2 iUV1,
    float2 iUV2,
    out float4 oOutput)
{

    oOutput.xy = iUV1;
    oOutput.zw = iUV2;
    
}
//---------------------------------------------------------------------------
/*

	AtTransformPosition
	
*/

void AtTransformPosition(float4 iPos,
    float4x4 iMatrix,
    out float4 oPos)
{

	oPos = mul( iPos, iMatrix );
	
}
//---------------------------------------------------------------------------
/*

	AtCalculateLightDiffuseOutDot
	
*/

void AtCalculateLightDiffuseOutDot(float3 iLightDiffuse,
    float3 iLightDirection,
    float3 iSurfaceNormal,
    out float3 oResult,
    out float oDot)
{

	oDot = max( 0.0f, dot( -iLightDirection, iSurfaceNormal ) );
	oResult = iLightDiffuse * oDot;
	
}
//---------------------------------------------------------------------------
/*

	AtCalculateFogAndWorldViewPos
	
*/

void AtCalculateFogAndWorldViewPos(float4 iPos,
    float4x4 iWorldView,
    float2 iFogNearFar,
    out float oResult,
    out float4 oWorldViewPos)
{

	oWorldViewPos = mul( iPos, iWorldView );
	oResult = saturate( ( oWorldViewPos.z - iFogNearFar.x ) / ( iFogNearFar.y - iFogNearFar.x ) );	
	
}
//---------------------------------------------------------------------------
/*

    AtCompositeBaseUVFogDot
    
*/

void AtCompositeBaseUVFogDot(float2 iBaseUV,
    float iFog,
    float iDot,
    out float4 oOutput)
{

    oOutput.xy = iBaseUV;
    oOutput.z = iFog;
    oOutput.w = iDot;
    
}
//---------------------------------------------------------------------------
/*

    AtCalculateDSShadowUV
    
*/

void AtCalculateDSShadowUV(float4 iInput,
    out float4 oOutput)
{

	oOutput = iInput;
    oOutput.x = iInput.x * 0.5 + (0.5 + 0.5/1024.0) * iInput.w;
    oOutput.y = iInput.y * -0.5 + (0.5 + 0.5/1024.0) * iInput.w;	
    
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// Input:
//---------------------------------------------------------------------------

struct Input
{
    float4 Position : POSITION0;
    float3 Normal : NORMAL0;
    float2 BaseUV : TEXCOORD0;
    float2 UVSet0 : TEXCOORD1;
    float2 UVSet1 : TEXCOORD2;
    float2 UVSet2 : TEXCOORD3;
    float2 UVSet3 : TEXCOORD4;
    float4 VertexColors : COLOR0;

};

//---------------------------------------------------------------------------
// Output:
//---------------------------------------------------------------------------

struct Output
{
    float4 Position : POSITION0;
    float3 DiffAccum : TEXCOORD0;
    float4 BaseUVFogDot : TEXCOORD1;
    float4 UVSet0 : TEXCOORD2;
    float4 UVSet1 : TEXCOORD3;
    float4 ShadowUV1 : TEXCOORD4;
    float4 ShadowUV2 : TEXCOORD5;
    float4 VertexColors : COLOR0;

};

//---------------------------------------------------------------------------
// Main():
//---------------------------------------------------------------------------

Output Main(Input In)
{
    Output Out;
	// Function call #0
    AtCompositeTwoUV(In.UVSet0, In.UVSet1, Out.UVSet0);

	// Function call #1
    float4 oPos_CallOut1;
    AtTransformPosition(In.Position, g_World, oPos_CallOut1);

	// Function call #2
    float oDot_CallOut2;
    AtCalculateLightDiffuseOutDot(g_DirDiffuse0, g_DirWorldDirection0, 
        In.Normal, Out.DiffAccum, oDot_CallOut2);

	// Function call #3
    AtCompositeTwoUV(In.UVSet2, In.UVSet3, Out.UVSet1);

	// Function call #4
    AtTransformPosition(oPos_CallOut1, g_ViewProj, Out.Position);

	// Function call #5
    float oResult_CallOut5;
    float4 oWorldViewPos_CallOut5;
    AtCalculateFogAndWorldViewPos(In.Position, g_WorldView, g_FogNearFar, 
        oResult_CallOut5, oWorldViewPos_CallOut5);

	// Function call #6
    float4 oPos_CallOut6;
    AtTransformPosition(oWorldViewPos_CallOut5, CamViewToLightProj_1, 
        oPos_CallOut6);

	// Function call #7
    float4 oPos_CallOut7;
    AtTransformPosition(oWorldViewPos_CallOut5, CamViewToLightProj_2, 
        oPos_CallOut7);

	// Function call #8
    AtCompositeBaseUVFogDot(In.BaseUV, oResult_CallOut5, oDot_CallOut2, 
        Out.BaseUVFogDot);

	// Function call #9
    AtCalculateDSShadowUV(oPos_CallOut7, Out.ShadowUV2);

	// Function call #10
    AtCalculateDSShadowUV(oPos_CallOut6, Out.ShadowUV1);

    Out.VertexColors = In.VertexColors;
    return Out;
}

