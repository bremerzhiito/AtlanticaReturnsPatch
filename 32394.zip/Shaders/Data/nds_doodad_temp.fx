//------------------------------------------------------------------------------
//
//	Transformation Matrices
//

float4x4 WorldViewProj	: WORLDVIEWPROJECTION;
float4x4 WorldView		: WORLDVIEW;
float4x4 World			: WORLD;

//------------------------------------------------------------------------------
//
//	Fog Paramters
//

float4 FogColor		: FOGCOLOR = { 0.42f, 0.45f, 0.6f, 1.f };
float4 FogNearFar	: FOGNEARFAR = { 0.0f, 0.0f, 0.f, 0.f };
float4 FogDensity	: FOGDENSITY = { 1.0f, 1.0f, 1.0f, 1.0f };

//------------------------------------------------------------------------------
//
//	Light Paramters
//

float4 LightAmbient : Ambient
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float4 LightDiffuse : Diffuse
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float3 LightDirection : Direction
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float4 BaseMapMultiplier_Doodad : GLOBAL = { 1.0f, 1.0f, 1.0f, 1.0f };

//------------------------------------------------------------------------------
//
//	Shadow Paramters
//

float4x4 ViewToLightView_0		: GLOBAL; // Transform from view space to light view space
float4x4 ViewToLightProj_0		: GLOBAL; // Transform from view space to light projection space
float	 ShadowEpsilon_0		: GLOBAL;
float    ShadowMapSize_0		: GLOBAL;
float    ShadowMapSizeInverse_0	: GLOBAL;

//------------------------------------------------------------------------------
//
//	BaseMap
//

texture BaseMap
<
	string NTM = "base";
>;
sampler2D BaseSampler = sampler_state
{
	Texture = (BaseMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MINFILTER = LINEAR;
	MAGFILTER = LINEAR;
	MIPFILTER = LINEAR;
};

//------------------------------------------------------------------------------
//
//	DarkMap
//

texture DarkMap
<
	string NTM = "dark";
>;
sampler2D DarkSampler = sampler_state
{
	Texture = (DarkMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MINFILTER = LINEAR;
	MAGFILTER = LINEAR;
	MIPFILTER = LINEAR;
};

//------------------------------------------------------------------------------
//
//	GlowMap
//

texture GlowMap
<
	string NTM = "glow";
>;
sampler2D GlowSampler = sampler_state
{
	Texture = (GlowMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MINFILTER = LINEAR;
	MAGFILTER = LINEAR;
	MIPFILTER = LINEAR;
};

//------------------------------------------------------------------------------
//
//	ShadowMap
//

texture ShadowMap
< 
    string NTM = "shader";
    int NTMIndex = 0;
>;
sampler2D ShadowSamplerDS = sampler_state
{
    Texture = <ShadowMap>;
    ADDRESSU = CLAMP;
    ADDRESSV = CLAMP;
    MINFILTER = LINEAR;
    MAGFILTER = LINEAR;
    MIPFILTER = NONE;
};
sampler2D ShadowSamplerFP = sampler_state
{
    Texture = <ShadowMap>;
    ADDRESSU = CLAMP;
    ADDRESSV = CLAMP;
    MINFILTER = POINT;
    MAGFILTER = POINT;
    MIPFILTER = NONE;
};

//------------------------------------------------------------------------------
//
//	MaskMap
//

texture MaskMap
< 
    string NTM = "shader";
    int NTMIndex = 1;
>;
sampler2D MaskSampler = sampler_state
{
    Texture = <MaskMap>;
    ADDRESSU = CLAMP;
    ADDRESSV = CLAMP;
    MINFILTER = LINEAR;
    MAGFILTER = LINEAR;
    MIPFILTER = NONE;
};

//------------------------------------------------------------------------------
//
//	Calculation Functions
//

float4 CalculateLightAmbientDiffuse(in float3 iNormal)
{
	return LightDiffuse * saturate( dot( -LightDirection, iNormal ) ) + LightAmbient;
}

float4 CalculateLightDiffuse(in float3 iNormal)
{
	return LightDiffuse * saturate( dot( -LightDirection, iNormal ) );
}

float CalculateFogValue(in float4 iPos)
{
	return saturate( ( iPos.z - FogNearFar.x ) / ( FogNearFar.y - FogNearFar.x ) );	
}

void CalculateShadowFPTex(in float4 iPosLight, out float3 oShadowTex)
{
	oShadowTex.xy = 0.5f * iPosLight.xy / iPosLight.w + float2( 0.5f, 0.5f );
	oShadowTex.y = 1.0f - oShadowTex.y;
	oShadowTex.z = saturate( iPosLight.z / iPosLight.w );
}

float CalculateShadowFPIntensity(in float3 iNormal, in float3 iShadowTex)
{
	float oIntensity = 0.0f;
    if( dot( -LightDirection, iNormal ) > 0.0f )
    {
		// 2x2 filtering
        float afSourcevals[4];
        afSourcevals[0] = tex2D( ShadowSamplerFP, iShadowTex.xy ).r;
        afSourcevals[1] = tex2D( ShadowSamplerFP, iShadowTex.xy + float2( ShadowMapSizeInverse_0, 0 ) ).r;
        afSourcevals[2] = tex2D( ShadowSamplerFP, iShadowTex.xy + float2( 0, ShadowMapSizeInverse_0 ) ).r;
        afSourcevals[3] = tex2D( ShadowSamplerFP, iShadowTex.xy + float2( ShadowMapSizeInverse_0, ShadowMapSizeInverse_0 ) ).r;
        afSourcevals[0] = ( afSourcevals[0] + ShadowEpsilon_0 < iShadowTex.z ) ? 0.0f : 1.0f;
        afSourcevals[1] = ( afSourcevals[1] + ShadowEpsilon_0 < iShadowTex.z ) ? 0.0f : 1.0f;  
        afSourcevals[2] = ( afSourcevals[2] + ShadowEpsilon_0 < iShadowTex.z ) ? 0.0f : 1.0f;  
        afSourcevals[3] = ( afSourcevals[3] + ShadowEpsilon_0 < iShadowTex.z ) ? 0.0f : 1.0f;  

        float2 lerps = frac( ShadowMapSize_0 * iShadowTex.xy );
        
        oIntensity = lerp( lerp( afSourcevals[0], afSourcevals[1], lerps.x ),
                           lerp( afSourcevals[2], afSourcevals[3], lerps.x ),
                           lerps.y );

/*
		float4 vTexCoords[9];
		float4 vTexC = float4(iShadowTex.xy, 0.0f, 0.0f);

		// Generate the tecture co-ordinates for the specified depth-map size
		// 4 3 5
		// 1 0 2
		// 7 6 8
		vTexCoords[0] = vTexC;

		vTexCoords[1] = vTexC + float4( -ShadowMapSizeInverse_0, 0.0f, 0.0f, 0.0f );
		vTexCoords[2] = vTexC + float4(  ShadowMapSizeInverse_0, 0.0f, 0.0f, 0.0f );
		vTexCoords[3] = vTexC + float4( 0.0f, -ShadowMapSizeInverse_0, 0.0f, 0.0f );
		vTexCoords[6] = vTexC + float4( 0.0f,  ShadowMapSizeInverse_0, 0.0f, 0.0f );

		vTexCoords[4] = vTexC + float4( -ShadowMapSizeInverse_0, -ShadowMapSizeInverse_0, 0.0f, 0.0f );
		vTexCoords[5] = vTexC + float4(  ShadowMapSizeInverse_0, -ShadowMapSizeInverse_0, 0.0f, 0.0f );
		vTexCoords[7] = vTexC + float4( -ShadowMapSizeInverse_0,  ShadowMapSizeInverse_0, 0.0f, 0.0f );
		vTexCoords[8] = vTexC + float4(  ShadowMapSizeInverse_0,  ShadowMapSizeInverse_0, 0.0f, 0.0f );

		// Sample each of them checking whether the pixel under test is shadowed or not
		float fShadowTerm = 0.0f;
		float fTmp = iShadowTex.z;
		
		for( int i = 0; i < 9; i++ )
		{
			float A = tex2D( ShadowSamplerFP, vTexCoords[i] ).r;
			
			float B = (fTmp - ShadowEpsilon_0);
			
			// Texel is shadowed
			fShadowTerm += A < B ? 0.1f : 1.0f;			
		}
								
		oIntensity = fShadowTerm / 9.0f;
*/
    }
    
    // Masking
    float fValue = max( tex2D( MaskSampler, iShadowTex.xy ).a, tex2D( MaskSampler, iShadowTex.zz ).a );
	oIntensity = lerp( oIntensity, 1.0f, fValue );
    
    return oIntensity;
}

void CalculateShadowDSTex(in float4 iPosLight, out float4 oShadowTex)
{
	oShadowTex = iPosLight;
	//oShadowTex.z -= ( 1.0f - saturate( dot( iNormal, -LightDirection ) ) ) * 0.01f;
    oShadowTex.x = oShadowTex.x * 0.5f + ( 0.5f /*+ 0.5f / 1024.0f*/ ) * oShadowTex.w;
    oShadowTex.y = oShadowTex.y * -0.5f + ( 0.5f /*+ 0.5f / 1024.0f*/ ) * oShadowTex.w;
}

//------------------------------------------------------------------------------
//
//	BaseMap
//

void V11_B(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float3	oLightAmDi	: TEXCOORD1,
	out float	oFogVal		: TEXCOORD2)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );
	
	// Set texture coords
	oTexBase = iTexBase;	
	
	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightAmDi = CalculateLightAmbientDiffuse( lNormal );
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );
}

void P20_B(
	in	float2	iTexBase	: TEXCOORD0,
	in	float3	iLightAmDi	: TEXCOORD1,
	in	float	iFogVal		: TEXCOORD2,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * float4( iLightAmDi, 1.0f );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	GlowMap
//

void V11_G(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexGlow	: TEXCOORD0,
	out float4	oPos		: POSITION,
	out float2	oTexGlow	: TEXCOORD0,
	out float	oFogVal		: TEXCOORD1)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );
	
	// Set texture coords
	oTexGlow = iTexGlow;	
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );
}

void P20_G(
	in	float2	iTexGlow	: TEXCOORD0,
	in	float	iFogVal		: TEXCOORD1,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( GlowSampler, iTexGlow );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	BaseMap + DarkMap
//

void V11_BD(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	in	float4	iTexDark	: TEXCOORD1,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float2	oTexDark	: TEXCOORD1,
	out float3	oLightAmDi	: TEXCOORD2,
	out float	oFogVal		: TEXCOORD3)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );

	// Set texture coords
	oTexBase = iTexBase;	
	oTexDark = iTexDark;

	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightAmDi = CalculateLightAmbientDiffuse( lNormal );

	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );
}

void P20_BD(
	in	float2	iTexBase	: TEXCOORD0,
	in	float2	iTexDark	: TEXCOORD1,
	in	float3	iLightAmDi	: TEXCOORD2,
	in	float	iFogVal		: TEXCOORD3,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * tex2D( DarkSampler, iTexDark ) * float4( iLightAmDi, 1.0f );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	BaseMap + GlowMap
//

void V11_BG(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	in	float4	iTexGlow	: TEXCOORD1,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float2	oTexGlow	: TEXCOORD1,
	out float3	oLightAmDi	: TEXCOORD2,
	out float	oFogVal		: TEXCOORD3)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );
	
	// Set texture coords
	oTexBase = iTexBase;
	oTexGlow = iTexGlow;
	
	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightAmDi = CalculateLightAmbientDiffuse( lNormal );
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );
}

void P20_BG(
	in	float2	iTexBase	: TEXCOORD0,
	in	float2	iTexGlow	: TEXCOORD1,
	in	float3	iLightAmDi	: TEXCOORD2,
	in	float	iFogVal		: TEXCOORD3,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * float4( iLightAmDi, 1.0f ) + tex2D( GlowSampler, iTexGlow );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	BaseMap + DarkMap + GlowMap
//

void V11_BDG(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	in	float4	iTexDark	: TEXCOORD1,
	in	float4	iTexGlow	: TEXCOORD2,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float2	oTexDark	: TEXCOORD1,
	out float2	oTexGlow	: TEXCOORD2,
	out float3	oLightAmDi	: TEXCOORD3,
	out float	oFogVal		: TEXCOORD4)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );
	
	// Set texture coords
	oTexBase = iTexBase;
	oTexDark = iTexDark;
	oTexGlow = iTexGlow;
	
	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightAmDi = CalculateLightAmbientDiffuse( lNormal );
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );
}

void P20_BDG(
	in	float2	iTexBase	: TEXCOORD0,
	in	float2	iTexDark	: TEXCOORD1,
	in	float2	iTexGlow	: TEXCOORD2,
	in	float3	iLightAmDi	: TEXCOORD3,
	in	float	iFogVal		: TEXCOORD4,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * tex2D( DarkSampler, iTexDark ) * float4( iLightAmDi, 1.0f ) + tex2D( GlowSampler, iTexGlow );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	BaseMap + Depth-Stencil Shadow
//

void V11_B_DSS(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float3	oLightDi	: TEXCOORD1,
	out float	oFogVal		: TEXCOORD2,
	out float4	oShadowTex	: TEXCOORD3)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );

	// Set texture coords
	oTexBase = iTexBase;	
	
	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightDi = CalculateLightDiffuse( lNormal );
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );

	// Caculate shadow paramters
	float4 lPosLight = mul( lPos, ViewToLightProj_0 );
	CalculateShadowDSTex( lPosLight, oShadowTex );
}

void P20_B_DSS(
	in	float2	iTexBase	: TEXCOORD0,
	in	float3	iLightDi	: TEXCOORD1,
	in	float	iFogVal		: TEXCOORD2,
	in	float4	iShadowTex	: TEXCOORD3,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * ( tex2D( ShadowSamplerDS, iShadowTex ) * float4( iLightDi, 1.0f ) + LightAmbient );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	BaseMap + DarkMap + Depth-Stencil Shadow
//

void V11_BD_DSS(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	in	float4	iTexDark	: TEXCOORD1,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float2	oTexDark	: TEXCOORD1,
	out float3	oLightDi	: TEXCOORD2,
	out float	oFogVal		: TEXCOORD3,
	out float4	oShadowTex	: TEXCOORD4)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );

	// Set texture coords
	oTexBase = iTexBase;	
	oTexDark = iTexDark;
	
	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightDi = CalculateLightDiffuse( lNormal );
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );

	// Caculate shadow paramters
	float4 lPosLight = mul( lPos, ViewToLightProj_0 );
	CalculateShadowDSTex( lPosLight, oShadowTex );
}

void P20_BD_DSS(
	in	float2	iTexBase	: TEXCOORD0,
	in	float2	iTexDark	: TEXCOORD1,
	in	float3	iLightDi	: TEXCOORD2,
	in	float	iFogVal		: TEXCOORD3,
	in	float4	iShadowTex	: TEXCOORD4,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * tex2D( DarkSampler, iTexDark ) * ( tex2D( ShadowSamplerDS, iShadowTex ) * float4( iLightDi, 1.0f ) + LightAmbient );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	BaseMap + Floating-Point Shadow
//

void V11_B_FPS(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float3	oLightDi	: TEXCOORD1,
	out float	oFogVal		: TEXCOORD2,
	out float3	oNormal		: TEXCOORD3,
	out	float3	oShadowTex	: TEXCOORD4)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );

	// Set texture coords
	oTexBase = iTexBase;	
	
	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightDi = CalculateLightDiffuse( lNormal );
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );

	// Caculate shadow paramters
	oNormal = lNormal;
	float4 lPosLight = mul( lPos, ViewToLightProj_0 );
	CalculateShadowFPTex( lPosLight, oShadowTex );
}

void P20_B_FPS(
	in	float2	iTexBase	: TEXCOORD0,
	in	float3	iLightDi	: TEXCOORD1,
	in	float	iFogVal		: TEXCOORD2,
	in	float3	iNormal		: TEXCOORD3,
	in	float3	iShadowTex	: TEXCOORD4,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * ( CalculateShadowFPIntensity( iNormal, iShadowTex ) * float4( iLightDi, 1.0f ) + LightAmbient );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	BaseMap + DarkMap + Floating-Point Shadow
//

void V11_BD_FPS(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	in	float4	iTexDark	: TEXCOORD1,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float2	oTexDark	: TEXCOORD1,
	out float3	oLightDi	: TEXCOORD2,
	out float	oFogVal		: TEXCOORD3,
	out float3	oNormal		: TEXCOORD4,
	out	float3	oShadowTex	: TEXCOORD5)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );

	// Set texture coords
	oTexBase = iTexBase;
	oTexDark = iTexDark;
	
	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightDi = CalculateLightDiffuse( lNormal );
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );

	// Caculate shadow paramters
	oNormal = lNormal;
	float4 lPosLight = mul( lPos, ViewToLightProj_0 );
	CalculateShadowFPTex( lPosLight, oShadowTex );
}

void P20_BD_FPS(
	in	float2	iTexBase	: TEXCOORD0,
	in	float2	iTexDark	: TEXCOORD1,
	in	float3	iLightDi	: TEXCOORD2,
	in	float	iFogVal		: TEXCOORD3,
	in	float3	iNormal		: TEXCOORD4,
	in	float3	iShadowTex	: TEXCOORD5,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * tex2D( DarkSampler, iTexDark ) * ( CalculateShadowFPIntensity( iNormal, iShadowTex ) * float4( iLightDi, 1.0f ) + LightAmbient );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	BaseMap + GlowMap + Floating-Point Shadow
//

void V11_BG_FPS(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	in	float4	iTexGlow	: TEXCOORD1,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float2	oTexGlow	: TEXCOORD1,
	out float3	oLightDi	: TEXCOORD2,
	out float	oFogVal		: TEXCOORD3,
	out float3	oNormal		: TEXCOORD4,
	out	float3	oShadowTex	: TEXCOORD5)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );

	// Set texture coords
	oTexBase = iTexBase;
	oTexGlow = iTexGlow;
	
	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightDi = CalculateLightDiffuse( lNormal );
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );

	// Caculate shadow paramters
	oNormal = lNormal;
	float4 lPosLight = mul( lPos, ViewToLightProj_0 );
	CalculateShadowFPTex( lPosLight, oShadowTex );
}

void P20_BG_FPS(
	in	float2	iTexBase	: TEXCOORD0,
	in	float2	iTexGlow	: TEXCOORD1,
	in	float3	iLightDi	: TEXCOORD2,
	in	float	iFogVal		: TEXCOORD3,
	in	float3	iNormal		: TEXCOORD4,
	in	float3	iShadowTex	: TEXCOORD5,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * ( CalculateShadowFPIntensity( iNormal, iShadowTex ) * float4( iLightDi, 1.0f ) + LightAmbient ) + tex2D( GlowSampler, iTexGlow );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	BaseMap + DarkMap + GlowMap + Floating-Point Shadow
//

void V11_BDG_FPS(
	in	float4	iPos		: POSITION,
	in	float3	iNormal		: NORMAL,
	in	float4	iTexBase	: TEXCOORD0,
	in	float4	iTexDark	: TEXCOORD1,
	in	float4	iTexGlow	: TEXCOORD2,
	out float4	oPos		: POSITION,
	out float2	oTexBase	: TEXCOORD0,
	out float2	oTexDark	: TEXCOORD1,
	out float2	oTexGlow	: TEXCOORD2,
	out float3	oLightDi	: TEXCOORD3,
	out float	oFogVal		: TEXCOORD4,
	out float3	oNormal		: TEXCOORD5,
	out	float3	oShadowTex	: TEXCOORD6)
{
	// Calculate transformation
	oPos = mul( iPos, WorldViewProj );

	// Set texture coords
	oTexBase = iTexBase;
	oTexDark = iTexDark;
	oTexGlow = iTexGlow;
	
	// Calculate light parameters
	float3 lNormal = normalize( mul( iNormal, (float3x3)World ) );
	oLightDi = CalculateLightDiffuse( lNormal );
	
	// Calculate fog parameters
	float4 lPos = mul( iPos, WorldView );
	oFogVal = CalculateFogValue( lPos );

	// Caculate shadow paramters
	oNormal = lNormal;
	float4 lPosLight = mul( lPos, ViewToLightProj_0 );
	CalculateShadowFPTex( lPosLight, oShadowTex );
}

void P20_BDG_FPS(
	in	float2	iTexBase	: TEXCOORD0,
	in	float2	iTexDark	: TEXCOORD1,
	in	float2	iTexGlow	: TEXCOORD2,
	in	float3	iLightDi	: TEXCOORD3,
	in	float	iFogVal		: TEXCOORD4,
	in	float3	iNormal		: TEXCOORD5,
	in	float3	iShadowTex	: TEXCOORD6,
	out float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase ) * BaseMapMultiplier_Doodad * tex2D( DarkSampler, iTexDark ) * ( CalculateShadowFPIntensity( iNormal, iShadowTex ) * float4( iLightDi, 1.0f ) + LightAmbient ) + tex2D( GlowSampler, iTexGlow );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}

//------------------------------------------------------------------------------
//
//	Techniques
//

// BaseMap
technique nds_doodad_v11_p20_b
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_B();
		PixelShader = compile ps_2_0 P20_B();
	}
}

// GlowMap
technique nds_doodad_v11_p20_g
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_G();
		PixelShader = compile ps_2_0 P20_G();
	}
}

// BaseMap + DarkMap
technique nds_doodad_v11_p20_bd
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_BD();
		PixelShader = compile ps_2_0 P20_BD();
	}
}

// BaseMap + GlowMap
technique nds_doodad_v11_p20_bg
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_BG();
		PixelShader = compile ps_2_0 P20_BG();
	}
}

// BaseMap + DarkMap + GlowMap
technique nds_doodad_v11_p20_bdg
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_BDG();
		PixelShader = compile ps_2_0 P20_BDG();
	}
}

// BaseMap + Depth-Stencil Shadow
technique nds_doodad_v11_p20_b_dss
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_B_DSS();
		PixelShader = compile ps_2_0 P20_B_DSS();
	}
}

// BaseMap + DarkMap + Depth-Stencil Shadow
technique nds_doodad_v11_p20_bd_dss
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_BD_DSS();
		PixelShader = compile ps_2_0 P20_BD_DSS();
	}
}

// BaseMap + Floating-Point Shadow
technique nds_doodad_v11_p20_b_fps
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_B_FPS();
		PixelShader = compile ps_2_0 P20_B_FPS();
	}
}

// BaseMap + DarkMap + Floating-Point Shadow
technique nds_doodad_v11_p20_bd_fps
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_BD_FPS();
		PixelShader = compile ps_2_0 P20_BD_FPS();
	}
}

// BaseMap + GlowMap + Floating-Point Shadow
technique nds_doodad_v11_p20_bg_fps
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_BG_FPS();
		PixelShader = compile ps_2_0 P20_BG_FPS();
	}
}
// BaseMap + DarkMap + GlowMap + Floating-Point Shadow
technique nds_doodad_v11_p20_bdg_fps
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 V11_BDG_FPS();
		PixelShader = compile ps_2_0 P20_BDG_FPS();
	}
}