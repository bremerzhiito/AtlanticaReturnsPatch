float4x4 WorldViewProj : WORLDVIEWPROJECTION;
float SceneTrail_DecayRate : GLOBAL = 0.9f;

struct VS_OUTPUT
{
	float4 Pos : POSITION;
	float2 Tex0 : TEXCOORD0;
};

texture BaseMap
<
    string NTM = "base";
>;

sampler BaseSampler = sampler_state
{
   Texture = (BaseMap);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = LINEAR;
};

VS_OUTPUT VS(float4 Pos : POSITION, float2 Tex0 : TEXCOORD0)
{
	VS_OUTPUT Out;
	
	Out.Pos = mul(Pos, WorldViewProj);
	Out.Tex0 = Tex0;
	
	return Out;
}

float4 PSFront(VS_OUTPUT In) : COLOR
{
	return tex2D(BaseSampler, In.Tex0);
}

float4 PSBack(VS_OUTPUT In) : COLOR
{
	float4 Out = tex2D(BaseSampler, In.Tex0);
	Out.a = SceneTrail_DecayRate;
	return Out;
}

technique SceneTrailFront
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PSFront();
	}
}

technique SceneTrailBack
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SRCALPHA;
		DestBlend = INVSRCALPHA;
		AlphaTestEnable = false;
		
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PSBack();
	}
}