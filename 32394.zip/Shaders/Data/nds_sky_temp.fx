//--------------------------------------------------------------
float4x4 WorldViewProj		: WORLDVIEWPROJECTION;
float4x2 TexTransformBase	: TEXTRANSFORMBASE;
float4x2 TexTransformDark	: TEXTRANSFORMDARK;
float4x2 TexTransformGlow	: TEXTRANSFORMGLOW;
float4x2 TexTransformGloss	: TEXTRANSFORMGLOSS;
float4   MaterialEmissive	: MATERIALEMISSIVE;
//--------------------------------------------------------------
texture MapStars
<
    string NTM = "Base";
>;
sampler SamplerStars = sampler_state
{
   Texture = (MapStars);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapGradDest
<
    string NTM = "Shader";
    int NTMIndex = 0;
>;
sampler SamplerGradDest = sampler_state
{
   Texture = (MapGradDest);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapGradSrc
<
	string NTM = "Shader";
	int NTMIndex = 1;
>;
sampler SamplerGradSrc = sampler_state
{
   Texture = (MapGradSrc);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapHighSrc
<
	string NTM = "Base";
>;
sampler SamplerHighSrc = sampler_state
{
   Texture = (MapHighSrc);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapHighDest
<
	string NTM = "Dark";
>;
sampler SamplerHighDest = sampler_state
{
   Texture = (MapHighDest);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapLowSrc
<
	string NTM = "Glow";
>;
sampler SamplerLowSrc = sampler_state
{
   Texture = (MapLowSrc);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapLowDest
<
	string NTM = "Gloss";
>;
sampler SamplerLowDest = sampler_state
{
   Texture = (MapLowDest);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapCloudColorSrc
<
	string NTM = "Detail";
>;
sampler SamplerCloudColorSrc = sampler_state
{
   Texture = (MapCloudColorSrc);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapCloudColorDest
<
	string NTM = "Normal";
>;
sampler SamplerCloudColorDest = sampler_state
{
   Texture = (MapCloudColorDest);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapSun
<
	string NTM = "Base";
>;
sampler2D SamplerSun = sampler_state
{
   Texture = (MapSun);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapMoon
<
	string NTM = "Base";
>;
sampler2D SamplerMoon = sampler_state
{
   Texture = (MapMoon);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
texture MapSkyBox
<
	string NTM = "Base";
>;
sampler2D SamplerSkyBox = sampler_state
{
   Texture = (MapSkyBox);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};
//--------------------------------------------------------------
float Sky_Day			: GLOBAL;
float Sky_FracDay		: GLOBAL;
float Sky_Interpolation : GLOBAL;
float Sky_StarsAlpha	: GLOBAL;
//--------------------------------------------------------------
void VSSkySphere(
	in	float4	iPos		: POSITION,
	in	float3	iColor		: COLOR0,
	in	float3	iNormal		: NORMAL,
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oPos		: POSITION,
	out	float3	oColor		: COLOR0,
	out	float2	oBaseTex	: TEXCOORD0,
	out	float3	oNormal		: TEXCOORD1)
{
	oPos = mul( iPos, WorldViewProj );
	oColor = iColor;
	oBaseTex = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformBase );
	oNormal = -iNormal;
}
//--------------------------------------------------------------
void PSSkySphere(
	in	float3	iColor		: COLOR0,
	in	float2	iBaseTex	: TEXCOORD0,
	in	float3	iNormal		: TEXCOORD1,
	out	float4	oColor		: COLOR)
{
	// Gradation
	float2 GradTexCoord = float2( iNormal.z, Sky_FracDay );
	oColor = lerp( tex2D( SamplerGradSrc, GradTexCoord ), tex2D( SamplerGradDest, GradTexCoord ), Sky_Interpolation );
	
	// Stars
	float4 StarsColor = tex2D( SamplerStars, iBaseTex );
	float Alpha = StarsColor.a * Sky_StarsAlpha * iColor.r;
	oColor.rgb = ( 1.0f - Alpha ) * oColor + Alpha * StarsColor.rgb;
}
//--------------------------------------------------------------
void PSSkySphereSrcOnly(
	in	float3	iColor		: COLOR0,
	in	float2	iBaseTex	: TEXCOORD0,
	in	float3	iNormal		: TEXCOORD1,
	out	float4	oColor		: COLOR)
{
	// Gradation
	float2 GradTexCoord = float2( iNormal.z, Sky_FracDay );
	oColor = tex2D( SamplerGradSrc, GradTexCoord );
	
	// Stars
	float4 StarsColor = tex2D( SamplerStars, iBaseTex );
	float Alpha = StarsColor.a * Sky_StarsAlpha * iColor.r;
	oColor.rgb = ( 1.0f - Alpha ) * oColor + Alpha * StarsColor.rgb;
}
//--------------------------------------------------------------
void PSSkySphereDestOnly(
	in	float3	iColor		: COLOR0,
	in	float2	iBaseTex	: TEXCOORD0,
	in	float3	iNormal		: TEXCOORD1,
	out	float4	oColor		: COLOR)
{
	// Gradation
	float2 GradTexCoord = float2( iNormal.z, Sky_FracDay );
	oColor = tex2D( SamplerGradDest, GradTexCoord );
	
	// Stars
	float4 StarsColor = tex2D( SamplerStars, iBaseTex );
	float Alpha = StarsColor.a * Sky_StarsAlpha * iColor.r;
	oColor.rgb = ( 1.0f - Alpha ) * oColor + Alpha * StarsColor.rgb;
}
//--------------------------------------------------------------
void VSSkyDome(
	in	float4	iPos			: POSITION,
	in	float3	iColor			: COLOR0,
	in	float2	iBaseTex		: TEXCOORD0,
	out	float4	oPos			: POSITION,
	out	float3	oColor			: COLOR0,
	out	float2	oHighTexSrc		: TEXCOORD0,
	out	float2	oHighTexDest	: TEXCOORD1)/*,
	out	float2	oLowTexSrc		: TEXCOORD2,
	out	float2	oLowTexDest		: TEXCOORD3)*/
{
	oPos = mul( iPos, WorldViewProj );
	
	oColor = iColor;
	
	//oHighTexSrc = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformBase );
	//oHighTexDest = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformDark );

	// LowCloud ���
	oHighTexSrc = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformGlow );
	oHighTexDest = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformGloss );

	//oLowTexSrc = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformGlow );
	//oLowTexDest = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformGloss );
}
//--------------------------------------------------------------
void PSSkyDome(
	in	float3	iColor			: COLOR0,
	in	float2	iHighTexSrc		: TEXCOORD0,
	in	float2	iHighTexDest	: TEXCOORD1,
	//in	float2	iLowTexSrc		: TEXCOORD2,
	//in	float2	iLowTexDest		: TEXCOORD3,
	out	float4	oColor			: COLOR)
{
	float4 SrcColor, DestColor;

/*	
	SrcColor = tex2D( SamplerHighSrc, iHighTexSrc );
	SrcColor *= tex2D( SamplerCloudColorSrc, float2( SrcColor.a, Sky_FracDay ) );
	DestColor = tex2D( SamplerHighDest, iHighTexDest );
	DestColor *= tex2D( SamplerCloudColorDest, float2( DestColor.a, Sky_FracDay ) );
	float4 HighColor = lerp( SrcColor, DestColor, Sky_Interpolation );
*/

	// LowCloud ���
	SrcColor = tex2D( SamplerLowSrc, iHighTexSrc );
	SrcColor *= tex2D( SamplerCloudColorSrc, float2( SrcColor.a, Sky_FracDay ) );
	DestColor = tex2D( SamplerLowDest, iHighTexDest );
	DestColor *= tex2D( SamplerCloudColorDest, float2( DestColor.a, Sky_FracDay ) );
	float4 HighColor = lerp( SrcColor, DestColor, Sky_Interpolation );

/*
	SrcColor = tex2D( SamplerLowSrc, iLowTexSrc );
	SrcColor *= tex2D( SamplerCloudColorSrc, float2( SrcColor.a, Sky_FracDay ) );
	DestColor = tex2D( SamplerLowDest, iLowTexDest );
	DestColor *= tex2D( SamplerCloudColorDest, float2( DestColor.a, Sky_FracDay ) );
	float4 LowColor = lerp( SrcColor, DestColor, Sky_Interpolation );
*/
	
	oColor = HighColor;
//	oColor.rgb = ( 1.0f - LowColor.a) * oColor.rgb + LowColor.a * LowColor.rgb;
//	oColor.a = oColor.a + ( 1.0f - oColor.a) * LowColor.a;
	oColor.a *= iColor.r;
}
//--------------------------------------------------------------
void VSSkyDomeSrcOnly(
	in	float4	iPos			: POSITION,
	in	float3	iColor			: COLOR0,
	in	float2	iBaseTex		: TEXCOORD0,
	out	float4	oPos			: POSITION,
	out	float3	oColor			: COLOR0,
	out	float2	oHighTexSrc		: TEXCOORD0)/*,
	out	float2	oLowTexSrc		: TEXCOORD1)*/
{
	oPos = mul( iPos, WorldViewProj );
	
	oColor = iColor;
	
	//oHighTexSrc = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformBase );
	oHighTexSrc = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformGlow );
	//oLowTexSrc = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformGlow );
}
//--------------------------------------------------------------
void PSSkyDomeSrcOnly(
	in	float3	iColor			: COLOR0,
	in	float2	iHighTexSrc		: TEXCOORD0,
	//in	float2	iLowTexSrc		: TEXCOORD1,
	out	float4	oColor			: COLOR)
{
	float4 HighColor, LowColor;
	
	//HighColor = tex2D( SamplerHighSrc, iHighTexSrc );
	//HighColor *= tex2D( SamplerCloudColorSrc, float2( HighColor.a, Sky_FracDay ) );

	HighColor = tex2D( SamplerLowSrc, iHighTexSrc );
	HighColor *= tex2D( SamplerCloudColorSrc, float2( HighColor.a, Sky_FracDay ) );

	//LowColor = tex2D( SamplerLowSrc, iLowTexSrc );
	//LowColor *= tex2D( SamplerCloudColorSrc, float2( LowColor.a, Sky_FracDay ) );
	
	oColor = HighColor;
	//oColor.rgb = ( 1.0f - LowColor.a) * oColor.rgb + LowColor.a * LowColor.rgb;
	//oColor.a = oColor.a + ( 1.0f - oColor.a) * LowColor.a;
	oColor.a *= iColor.r;
}
//--------------------------------------------------------------
void VSSkyDomeDestOnly(
	in	float4	iPos			: POSITION,
	in	float3	iColor			: COLOR0,
	in	float2	iBaseTex		: TEXCOORD0,
	out	float4	oPos			: POSITION,
	out	float3	oColor			: COLOR0,
	out	float2	oHighTexDest	: TEXCOORD0)/*,
	out	float2	oLowTexDest		: TEXCOORD1)*/
{
	oPos = mul( iPos, WorldViewProj );
	
	oColor = iColor;
	
	//oHighTexDest = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformDark );
	oHighTexDest = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformGloss );
	//oLowTexDest = mul( float4(iBaseTex, 1.0f, 1.0f), TexTransformGloss );
}
//--------------------------------------------------------------
void PSSkyDomeDestOnly(
	in	float3	iColor			: COLOR0,
	in	float2	iHighTexDest	: TEXCOORD0,
	//in	float2	iLowTexDest		: TEXCOORD1,
	out	float4	oColor			: COLOR)
{
	float4 HighColor, LowColor;
	
	//HighColor = tex2D( SamplerHighDest, iHighTexDest );
	//HighColor *= tex2D( SamplerCloudColorDest, float2( HighColor.a, Sky_FracDay ) );

	HighColor = tex2D( SamplerLowDest, iHighTexDest );
	HighColor *= tex2D( SamplerCloudColorDest, float2( HighColor.a, Sky_FracDay ) );

	//LowColor = tex2D( SamplerLowDest, iLowTexDest );
	//LowColor *= tex2D( SamplerCloudColorDest, float2( LowColor.a, Sky_FracDay ) );
	
	oColor = HighColor;
	//oColor.rgb = ( 1.0f - LowColor.a) * oColor.rgb + LowColor.a * LowColor.rgb;
	//oColor.a = oColor.a + ( 1.0f - oColor.a) * LowColor.a;
	oColor.a *= iColor.r;
}

//--------------------------------------------------------------
void VSSun(
	in	float4	iPos		: POSITION,
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oPos		: POSITION,
	out	float2	oBaseTex	: TEXCOORD0)
{
	oPos = mul( iPos, WorldViewProj );
	
	oBaseTex = iBaseTex;
}
//--------------------------------------------------------------
void PSSun(
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oColor		: COLOR)
{
	oColor = tex2D( SamplerSun, iBaseTex );
}
//--------------------------------------------------------------
void VSMoon(
	in	float4	iPos		: POSITION,
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oPos		: POSITION,
	out	float2	oBaseTex	: TEXCOORD0)
{
	oPos = mul( iPos, WorldViewProj );
	
	oBaseTex = iBaseTex;
}
//--------------------------------------------------------------
void PSMoon(
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oColor		: COLOR)
{
/*
	float4 MoonColor = tex2D( SamplerMoon, iBaseTex );
	oColor.rgb = MoonColor.rgb * MoonColor.a;
	oColor.a = saturate( MoonColor.a * 10.f );
*/
	oColor = tex2D( SamplerMoon, iBaseTex );
}
//--------------------------------------------------------------
void VSSkyBox(
	in	float4	iPos		: POSITION,
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oPos		: POSITION,
	out	float2	oBaseTex	: TEXCOORD0)
{
	oPos = mul( iPos, WorldViewProj );
	
	oBaseTex = iBaseTex;
}
//--------------------------------------------------------------
void PSSkyBox(
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oColor		: COLOR)
{
	oColor = MaterialEmissive - tex2D( SamplerSkyBox, iBaseTex ) * ( MaterialEmissive - 1.0f );
}
//--------------------------------------------------------------
technique nds_sky_sphere
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSSkySphere();
		PixelShader = compile ps_2_0 PSSkySphere();
	}
}
//--------------------------------------------------------------
technique nds_sky_sphere_srconly
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSSkySphere();
		PixelShader = compile ps_2_0 PSSkySphereSrcOnly();
	}
}
//--------------------------------------------------------------
technique nds_sky_sphere_destonly
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSSkySphere();
		PixelShader = compile ps_2_0 PSSkySphereDestOnly();
	}
}
//--------------------------------------------------------------
technique nds_sky_dome
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SRCALPHA;
		DestBlend = INVSRCALPHA;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSSkyDome();
		PixelShader = compile ps_2_0 PSSkyDome();
	}
}
//--------------------------------------------------------------
technique nds_sky_dome_srconly
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SRCALPHA;
		DestBlend = INVSRCALPHA;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSSkyDomeSrcOnly();
		PixelShader = compile ps_2_0 PSSkyDomeSrcOnly();
	}
}
//--------------------------------------------------------------
technique nds_sky_dome_destonly
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SRCALPHA;
		DestBlend = INVSRCALPHA;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSSkyDomeDestOnly();
		PixelShader = compile ps_2_0 PSSkyDomeDestOnly();
	}
}
//--------------------------------------------------------------
technique nds_sky_sun
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SRCALPHA;
		DestBlend = ONE;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSSun();
		PixelShader = compile ps_2_0 PSSun();
	}
}
//--------------------------------------------------------------
technique nds_sky_moon
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SRCALPHA;
		DestBlend = ONE;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSMoon();
		PixelShader = compile ps_2_0 PSMoon();
	}
}
//--------------------------------------------------------------
technique nds_sky_skybox
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSSkyBox();
		PixelShader = compile ps_2_0 PSSkyBox();
	}
}