//------------------------------------------------------------------------------
//
//	Transformation Matrices
//

float4x4 WorldViewProj	: WORLDVIEWPROJECTION;
float4x4 WorldView		: WORLDVIEW;
float4x4 World			: WORLD;
float4x4 ViewProj		: VIEWPROJ;
float4 MaterialEmissive	: MATERIALEMISSIVE;

//------------------------------------------------------------------------------
//
//	Fog Paramters
//

float4 FogColor		: FOGCOLOR;
float4 FogNearFar	: FOGNEARFAR;

//------------------------------------------------------------------------------
//
//	Global Constants
//

float3 BrightenColor	: GLOBAL = float3(0.f, 0.f, 0.f);
float Transparency		: GLOBAL = 1.f;

//------------------------------------------------------------------------------
//
//	Skinning Related
//

float4x4 SkinWorldViewProj	: WORLDVIEWPROJ;
float4x4 SkinWorldView		: WORLDVIEW;
float4x4 SkinWorld			: WORLD;
static const int MAX_BONES = 20;
float4x3 Bone[MAX_BONES] : SKINBONEMATRIX3;

//----------------------------------------------------
//
//	Light
//

float3 LightAmbient : Ambient
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float3 LightDiffuse : Diffuse
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float3 LightDirection : Direction
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float3 BaseMapMultiplier_Character : GLOBAL = float3(1.4f, 1.4f, 1.4f);

//------------------------------------------------------------------------------
//
//	BaseMap
//

texture BaseMap
<
	string NTM = "base";
>;
sampler2D BaseSampler = sampler_state
{
	Texture = (BaseMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MINFILTER = LINEAR;
	MAGFILTER = LINEAR;
	MIPFILTER = LINEAR;
};
sampler2D BlobShadowSampler = sampler_state
{
	Texture = (BaseMap);
	ADDRESSU = CLAMP;
	ADDRESSV = CLAMP;
	MINFILTER = LINEAR;
	MAGFILTER = LINEAR;
	MIPFILTER = NONE;
};

//------------------------------------------------------------------------------
//
//	Calculation Functions
//

float3 CalculateLightAmbientDiffuse(in float3 iNormal)
{
	float3 DiffuseMultiplier = float3(0.3f, 0.3f, 0.3f);
	return LightAmbient + LightDiffuse * DiffuseMultiplier * max( 0.0f, dot( -LightDirection, iNormal ) );
}

float CalculateFogValue(in float4 iPos)
{
	return saturate( ( iPos.z - FogNearFar.x ) / ( FogNearFar.y - FogNearFar.x ) );	
}

void CalculateSkinnedPosNorm(
		in float4 iPos, in float3 iNormal, in float4 iBlendWeights, in float4 iBlendIndices,
		out float4 oPos, out float3 oNormal)
{
	// Compensate for lack of UBYTE4 on Geforce3
    int4 indices = iBlendIndices;

    // Calculate normalized fourth bone weight
    float weight4 = 1.0f - iBlendWeights[0] - iBlendWeights[1] - iBlendWeights[2];

    // Calculate bone transform to world space
    float4x3 BoneWorld;
	BoneWorld = iBlendWeights[0] * Bone[indices[0]];
	BoneWorld += iBlendWeights[1] * Bone[indices[1]];
	BoneWorld += iBlendWeights[2] * Bone[indices[2]];
	BoneWorld += weight4 * Bone[indices[3]];
	
    //
    // Transform skinned position to view space
    //
	oPos = float4( mul( iPos, BoneWorld ), 1.0f );

	// BoneSpace Normal
	oNormal = mul( iNormal, (float3x3)BoneWorld );
}

//----------------------------------------------------
//
//	Vertex shader no skin
//

void VSNoSkinned(
	in	float4 iPos				: POSITION,
	in	float3 iNormal			: NORMAL,
	in	float2 iTexBase			: TEXCOORD0,
	out float4 oPos				: POSITION,
	out	float2 oBaseTex			: TEXCOORD0,
	out	float3 oNormal			: TEXCOORD1,
	out	float3 oLightDiAm		: TEXCOORD2,
	out	float  oFogVal			: TEXCOORD3)
{
	// Position
	oPos = mul( iPos, WorldViewProj );

	// Tex coord
	oBaseTex = iTexBase;

 	// Normal
 	oNormal = normalize( mul( iNormal, (float3x3)World ) );
 	oLightDiAm = CalculateLightAmbientDiffuse( oNormal );
    
  	// Fog
	float4 lPos = mul( iPos, WorldView );
    oFogVal = CalculateFogValue( lPos );
}

//----------------------------------------------------
//
//	Vertex shader skin
//

void VSSkinned(
	in	float4 iPos				: POSITION,
	in	float3 iNormal			: NORMAL,
	in	float4 iBlendWeights	: BLENDWEIGHT,
	in	float4 iBlendIndices	: BLENDINDICES,
	in	float2 iTexBase			: TEXCOORD0,
	out float4 oPos				: POSITION,
	out	float2 oBaseTex			: TEXCOORD0,
	out	float3 oNormal			: TEXCOORD1,
	out	float3 oLightDiAm		: TEXCOORD2,
	out	float  oFogVal			: TEXCOORD3)
{
	// Position
	float4 lBoneSpacePos;
	float3 lBoneSpaceNormal;
	CalculateSkinnedPosNorm( iPos, iNormal, iBlendWeights, iBlendIndices, lBoneSpacePos, lBoneSpaceNormal );
	//oPos = mul( lBoneSpacePos, SkinWorldViewProj );
	oPos = mul( lBoneSpacePos, ViewProj );

	// Tex coord
	oBaseTex = iTexBase;

 	// Normal
    oNormal = normalize( mul( lBoneSpaceNormal, (float3x3)SkinWorld ) );
 	oLightDiAm = CalculateLightAmbientDiffuse( oNormal );
 	
 	// Fog
    float4 lPos = mul( lBoneSpacePos, SkinWorldView );
    oFogVal = CalculateFogValue( lPos );
}

//----------------------------------------------------
//
//	Pixel shader default
//

void PSDefault(
	in	float2 iTexBase		: TEXCOORD0,
	in	float3 iNormal		: TEXCOORD1,
	in	float3 iLightAmDi	: TEXCOORD2,
	in	float  iFogVal		: TEXCOORD3,
	out	float4 oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iTexBase );
	oColor.rgb = oColor.rgb + ( float3( 1.0f, 1.0f, 1.0f ) - oColor.rgb ) * BrightenColor;
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, iFogVal );
}



//--------------------------------------------------------
//
//	No Skinned technique
//
//

technique nds_housing_default
<
	bool UsesNiRenderState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSNoSkinned();
		PixelShader = compile ps_2_0 PSDefault();
	}
}

//--------------------------------------------------------
//
//	Skinned technique
//
//

technique nds_housing_skinned_default
<
	int BonesPerPartition = MAX_BONES;
	bool UsesNiRenderState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSSkinned();
		PixelShader = compile ps_2_0 PSDefault();
	}
}

