float4x4	WorldViewProj		: register(c0);
float4x2	TexTransformBase	: register(c4);
float4		MaterialEmissive	: register(c6);
//float		g_CharacterAlpha	: register(c7);

struct VS_INPUT
{
	float4 Pos			: POSITION;
	float4 Color		: COLOR0;
	float2 TexCoords	: TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 Pos			: POSITION;
	float4 Color		: COLOR0;
	float2 TexCoords    : TEXCOORD0;
};

VS_OUTPUT VS(VS_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;

	// Position
	Out.Pos = mul( In.Pos, WorldViewProj );
	
	// Color
	float4 oColor = In.Color * MaterialEmissive;
	//oColor.a = oColor.a * g_CharacterAlpha;
	Out.Color = oColor;
	
	// Tex coord
	Out.TexCoords = mul( float4( In.TexCoords, 1.0f, 1.0f ), TexTransformBase );
	
	return Out;	
}

sampler2D BaseSampler : register(s0);

float4 PS(VS_OUTPUT In) : COLOR
{
	return In.Color * tex2D( BaseSampler, In.TexCoords );
}