
float4x4 g_mWorld				: World;
float4x4 g_mView				: View;
float4x4 g_mProj				: Projection;
float4 g_vFogNearFar			: FogNearFar;

float3 g_vLightDir0 			= float3(1.0f, 1.0f, 1.0f);
float3 g_vLightDiffuse0 		= float3(1.0f, 1.0f, 1.0f);

//////////////////////////////////////////////////////////////////////////////////////

struct VS_INPUT
{
	float3 vPosition		: POSITION;
	float3 vNormal			: NORMAL;
	float2 vTexCoord0		: TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 vPosition		: POSITION;
	float2 vTexCoord0		: TEXCOORD0;
	float3 vLightDiAm		: TEXCOORD1;
	float fFogVal			: TEXCOORD2;
};


float3 CalculateLightAmbientDiffuse(float3 vNormal)
{
	float3 vDiffuseMultiplier = float3(0.3f, 0.3f, 0.3f);// jp ����_ ĳ���� ��ǻ� 30% �� ����
	return g_vLightDiffuse0 * vDiffuseMultiplier * max(0.0f, dot(-g_vLightDir0, vNormal));
	//return float3(1.0f, 0.0f, 0.0f);
}

float CalculateFogValue(float3 vPos)
{
	return saturate((vPos.z - g_vFogNearFar.x) / (g_vFogNearFar.y - g_vFogNearFar.x));	
}


VS_OUTPUT VS(VS_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;
	
	float3 vPos = mul(float4(In.vPosition, 1.0f), (float4x3)g_mWorld);
	float3 vViewPos  = mul(float4(vPos, 1.0f), (float4x3)g_mView);
	Out.vPosition  = mul(float4(vViewPos, 1.0f), g_mProj);
	
	float3 vNormal = mul(In.vNormal, (float3x3)g_mWorld);
	
	Out.vTexCoord0 = In.vTexCoord0;
//	Out.vTexCoord0 = In.vTexCoord0.yx;

//	Out.vLightDiAm = normalize(vNormal) * 0.5f + 0.5f;
	Out.vLightDiAm = normalize(CalculateLightAmbientDiffuse(vNormal)) * 0.5f + 0.5f;
	Out.fFogVal = CalculateFogValue(vViewPos);

	return Out;
}

//////////////////////////////////////////////////////////////////////////////////////

typedef VS_OUTPUT PS_INPUT;

sampler2D BaseSampler0			: register(s0);

//float3 BaseMapMultiplier_Character = float3(1.0f, 1.0f, 1.0f);
//float3 BrightenColor = float3(1.0f, 1.0f, 1.0f);

float4 g_vFogColor				: FogColor;

//////////////////////////////////////////////////////////////////////////////////////

float4 PS(PS_INPUT In) : COLOR
{   
	float4 vTexColor0;
	float4 vColor0;
	
	vTexColor0 = tex2D(BaseSampler0, In.vTexCoord0);
	
	//vColor0.rgb = (vTexColor0.rgb * g_vLightDiffuse0);
	vColor0.rgb = lerp( vTexColor0.rgb, g_vFogColor.rgb, In.fFogVal );
	//vColor0.rgb = lerp( vTexColor0.rgb, float3(1.0f, 0.0f, 0.0f), In.fFogVal );
	// + (vTexColor0.rgb * g_vLightAmbient0 * 0.5f);
	vColor0.a = vTexColor0.a;
	
	return vColor0;
}
