
//--------------------------------------------------------------//

//float4x4 mWorldViewProj	: WORLDVIEWPROJ;
float4x2 mMatrixTexbase		: TexTransformBase;
float4x2 mMatrixTexdark		: TexTransformDark;
float4x4 mWorldView			: WORLDVIEW;
float4x4 mProjection		: PROJECTION;
float4 g_FogNearFar			: FOGNEARFAR;

//--------------------------------------------------------------//

struct VS_INPUT
{
	float4 Pos :		POSITION;
	float2 UVSet0 :		TEXCOORD0;
};

struct VS_OUTPUT
{
   float4 Pos :			POSITION;
   float2 UVSet0 :		TEXCOORD0;
   float2 UVSet1 :		TEXCOORD1;   
   float3 FogDot :		TEXCOORD2;
};

VS_OUTPUT VS(VS_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;

	float4x4 outMatrix = mul(mWorldView, mProjection);
	Out.Pos = mul(In.Pos, outMatrix);
	//Out.Pos = mul(In.Pos, mWorldViewProj);
	Out.UVSet0 = mul(float4(In.UVSet0, 1.0f, 1.0f), mMatrixTexbase);
	Out.UVSet1 = mul(float4(In.UVSet0, 1.0f, 1.0f), mMatrixTexdark);
	Out.FogDot = float3(1.0f, 0.0f, 0.0f);

	float4 WorldViewPos = mul(In.Pos, mWorldView);
	Out.FogDot.x = saturate((WorldViewPos.z - g_FogNearFar.x) / (g_FogNearFar.y - g_FogNearFar.x));
	    
	return Out;
}

//--------------------------------------------------------------//

//float4 g_time : TIME;
//float FlowSpeed;
//bool g_FlowDirectionY = true;
float4 g_MaterialEmissive	: MaterialEmissive;
float4 g_FogColor			: FOGCOLOR;

sampler2D BaseSampler : register(s0);
sampler2D DarkSampler : register(s1);

//--------------------------------------------------------------//

typedef VS_OUTPUT PS_INPUT;

float4 PS(PS_INPUT In) : COLOR 
{
//	float4 vColor;
//	g_FlowDirectionY ? (vColor = float4(1.0f, 0.0f, 0.0f, 1.0f)) : (vColor = float4(0.0f, 1.0f, 0.0f, 1.0f));
//	vColor = float4(g_FlowDirectionY, 0.0f, 1.0f, 1.0f);
//	return vColor;

	float2 TexCoord = In.UVSet0;

//	if(g_FlowDirectionY == false) 
//	{
//		TexCoord.x = In.UVSet0.x;// + (g_time * FlowSpeed);
//	}
//	else
//	{
//		TexCoord.y = In.UVSet0.y;// + (g_time * FlowSpeed);
//	}

	float4 finalColor1;
	float4 maskColor = tex2D(BaseSampler, TexCoord);
	float4 patternColor = tex2D(DarkSampler, In.UVSet1);
	float4 finalColor = maskColor * patternColor * g_MaterialEmissive;

	// fog color calculate
	if((finalColor.r + finalColor.g + finalColor.b) <= 0.1f)
	{    
		finalColor1 = finalColor;
	}
	else
	{ 
		finalColor1.rgb = lerp(finalColor.rgb, g_FogColor.rgb, In.FogDot.x);
	}
	
	return finalColor1;
}
