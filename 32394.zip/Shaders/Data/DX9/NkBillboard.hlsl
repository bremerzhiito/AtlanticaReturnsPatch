float4x4 view_proj_matrix	: WORLDVIEWPROJ;
float4x2 TexTransformBase	: TEXTRANSFORMBASE;
sampler2D BaseSampler		: register(s0);

// Constants
float BillAlpha : ATTRIBUTE
<
    float min = 0.0f;
    float max = 1.0f;
> = 1.0f;

//--------------------------------------------------------------//
// Object
//--------------------------------------------------------------//
struct VS_OUTPUT {
   float4 Pos		: POSITION;
   float4 Color		: COLOR0;
   float2 TexUV		: TEXCOORD0;
};

VS_OUTPUT VS(float4 Pos : POSITION, float4 Color : COLOR0, float2 TexUV : TEXCOORD0)
{
	VS_OUTPUT Out;
	
	Out.Pos = mul(Pos, view_proj_matrix);
	Out.Color = Color;
	Out.TexUV = mul(float4(TexUV, 1.0f, 1.0f), TexTransformBase);

    return Out;
}

float4 PS(float2 TexUV : TEXCOORD0) : COLOR 
{
	float4 Out =  tex2D(BaseSampler, TexUV);
	Out.a = Out.a * BillAlpha;
	
	return Out;
}
