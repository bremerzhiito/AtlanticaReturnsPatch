//
//���� 4:01 2010-06-23

// This is used by 3dsmax to load the correct parser
string ParamID = "0x0";

	
//Using Texture 0 //////////////////////////////////////////////////////

	
texture Tex0 : DIFFUSEMAP < 
	//string name = "tiger.bmp"; 
	string UIName = "Base Texture"; 
	int Texcoord = 0;
	int MapChannel = 1;
>;



// Control Texture0 UV ///////////////////////////////////////////////////

float t0U<
	string UIName = "BaseTextureUScroll";
	string UIType = "IntSpinner";
	float UIMin = -100.0f;
	float UIMax = 100.0f;	
	>  = 0;
	

float t0V<
	string UIName = "BaseTextureVScroll";
	string UIType = "IntSpinner";
	float UIMin = -100.0f;
	float UIMax = 100.0f;	
	>  = 0;



// Control Texture0 Tile ///////////////////////////////////////////////////
float t0tU<
	string UIName = "BaseTextureUTile";
	string UIType = "IntSpinner";
	float UIMin = 0.1f;
	float UIMax = 100.0f;	
	>  = 1;
	
	bool BasetileU
<
string UIName = "Tile";
> = 1;

	
float t0tV<
	string UIName = "BaseTextureVTile";
	string UIType = "IntSpinner";
	float UIMin = 0.1f;
	float UIMax = 100.0f;	
	>  = 1;

bool BasetileV
<
string UIName = "Tile";
> = 1;

/////////////////////////////////////////////////////////////////////////////////////////


float4 EmittanceColor
<
	string UIName = "Emittance";
	string UIType = "MaxSwatch";
> = { 0.0, 0.0, 0.0,1.0f};


int texcoord1 : Texcoord
<
	int Texcoord = 1;
	int MapChannel = 0;
>;




sampler2D Diffusesampler = sampler_state
{
	Texture = <Tex0>;
	MinFilter = Linear;
	MagFilter = Linear;
	MipFilter = Linear;
	AddressU = WRAP;
	AddressV = WRAP;
};


// transformations
//float4x4 World      : 		WORLD;
//float4x4 View       : 		VIEW;
//float4x4 Projection : 		PROJECTION;
float4x4 WorldViewProj : 	WORLDVIEWPROJ;
//float4x4 WorldView : 		WORLDVIEW;
//float4 Col : COLOR0;

struct VS_OUTPUT
{
    float4 Pos  : POSITION;
    float2 Tex  : TEXCOORD0;
    float4 col	:TEXCOORD1;
    //float2 Tex1  : TEXCOORD1;
       
};

VS_OUTPUT VS(
    float3 Pos  : POSITION, 
    float3 Norm : NORMAL, 
    float2 Tex  : TEXCOORD0,
    float4 col	: TEXCOORD1
    //float2 Tex1  : TEXCOORD1
    )
{
    VS_OUTPUT Out = (VS_OUTPUT)0;

    Out.Pos  = mul(float4(Pos,1),WorldViewProj);    // position (projected)
    Out.Tex = Tex;
    //Out.Tex1 = Tex;
	Out.col =col;

    return Out;
}



float4 PS(
    float2 Tex  : TEXCOORD0,
    float4 col : TEXCOORD1
	) : COLOR
{

	float2 diffuseTex = float2((Tex.x-t0U),(Tex.y+t0V));
	diffuseTex = float2(((diffuseTex.x-0.5f)*t0tU)+0.5f,((diffuseTex.y+0.5f)*t0tV)+0.5f);
	
	
	float TiletexU;
	float TiletexV;
	
	// tileU check	
	if (BasetileU ==1)
		TiletexU = diffuseTex.x;
	else
		TiletexU = saturate(diffuseTex.x);
	
	// tileV check	
	if (BasetileV ==1)
		TiletexV = diffuseTex.y;
	else
		TiletexV = saturate(diffuseTex.y);


	
	float2 tileUV = float2( TiletexU,TiletexV);
	float4 diffusemap = tex2D(Diffusesampler,tileUV);
	float4 color = diffusemap * EmittanceColor *col;

	
	
    return  color ;
}

technique Standard
{
    pass P0
    {
        // shaders
        CullMode = none;
        ShadeMode = Gouraud;
        VertexShader = compile vs_2_0 VS();
        PixelShader  = compile ps_2_0 PS();
        
                // enable alpha blending
        AlphaBlendEnable = TRUE;
        SrcBlend         = SRCALPHA;
        DestBlend        = INVSRCALPHA;
        
    } 
    
}


technique Additive
{
    pass P0
    {
        // shaders
        CullMode = none;
        ShadeMode = Gouraud;
        VertexShader = compile vs_2_0 VS();
        PixelShader  = compile ps_2_0 PS();
        
                // enable alpha blending
        AlphaBlendEnable = TRUE;
        SrcBlend         = ONE;
        DestBlend        = ONE;
        
    } 
    
}

technique Screen
{
    pass P0
    {
        // shaders
        CullMode = none;
        ShadeMode = Gouraud;
        VertexShader = compile vs_2_0 VS();
        PixelShader  = compile ps_2_0 PS();
        
                // enable alpha blending
        AlphaBlendEnable = TRUE;
        SrcBlend         = SRCCOLOR;
        DestBlend        = ONE;
        
    } 
    
}

technique MultiInv
{
    pass P0
    {
        // shaders
        CullMode = none;
        ShadeMode = Gouraud;
        VertexShader = compile vs_2_0 VS();
        PixelShader  = compile ps_2_0 PS();
        
                // enable alpha blending
        AlphaBlendEnable = TRUE;
        SrcBlend         = ZERO;
        DestBlend        = INVSRCCOLOR;
        
    } 
    
}

