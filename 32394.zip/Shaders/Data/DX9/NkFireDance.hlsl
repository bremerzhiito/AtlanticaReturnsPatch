float4x4 view_proj_matrix : WORLDVIEWPROJ;
float4x4 world_view : WORLDVIEW;
float4x4 proj_matrix : PROJECTION;
float4 g_time : TIME;
float4 g_fogcolor : FOGCOLOR;
float4 g_fognearfar : FOGNEARFAR;
sampler FireMask 	: 	register(s0);
sampler FirePattern : 	register(s1);

//--------------------------------------------------------------//
// Object
//--------------------------------------------------------------//
struct VS_OUTPUT {
   float4 Pos:     POSITION;
   float2 UVSet0:  TEXCOORD0;
   float3 FogDot:  TEXCOORD1;
};

VS_OUTPUT VS(float4 Pos: POSITION, float2 UVSet0 : TEXCOORD0){
   VS_OUTPUT Out;

	float4x4 outMatrix = mul(world_view, proj_matrix);
	Out.Pos = mul(Pos, outMatrix);
	//Out.Pos = mul(Pos, view_proj_matrix);
	Out.UVSet0 = UVSet0;
	Out.FogDot = float3(1.0f, 0.0f, 0.0f);

	float4 WorldViewPos = mul( Pos, world_view );
	Out.FogDot.x = saturate( ( WorldViewPos.z - g_fognearfar.x ) / ( g_fognearfar.y - g_fognearfar.x ) );
    
    return Out;
}

float4 PS(float2 UVSet0: TEXCOORD0, float3 FogDot: TEXCOORD1) : COLOR {
   float2 coord = UVSet0;
   coord.y = UVSet0.y + g_time;
   float4 maskColor = tex2D(FireMask, UVSet0);
   float4 patternColor = tex2D(FirePattern, coord);
   float4 finalColor = maskColor * patternColor;
   
   // fog color calculate
   finalColor.rgb = lerp( finalColor.rgb, g_fogcolor.rgb, FogDot.x );
   return finalColor;
}
