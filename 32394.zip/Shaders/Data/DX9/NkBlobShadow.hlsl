float4x4 view_proj_matrix : WORLDVIEWPROJ;
sampler2D BaseSampler : register(s0);

//--------------------------------------------------------------//
// Object
//--------------------------------------------------------------//
struct VS_OUTPUT {
   float4 Pos	: POSITION;
   float2 TexUV	: TEXCOORD0;	
};

VS_OUTPUT VS(float4 Pos : POSITION, float2 TexUV : TEXCOORD0)
{
	VS_OUTPUT Out;
	Out.Pos = mul(Pos, view_proj_matrix);
	Out.TexUV = TexUV;	
        
    return Out;
}

float4 PS(float2 TexUV : TEXCOORD0) : COLOR 
{
	//return float4(1.0f, 1.0f, 0.0f, 1.0f);
	//return tex2D( BlobShadowSampler, TexUV ) * MaterialEmissive;
	return tex2D( BaseSampler, TexUV );
}
