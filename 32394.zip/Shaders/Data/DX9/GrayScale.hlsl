float4x4	WorldViewProj		: register(c0);

float3		GrayScaleFactor		: register(c0);
float		GrayBlendingValue	: register(c1);

struct VS_INPUT
{
	float4 Pos	: POSITION;
	float2 Tex0	: TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 Pos	: POSITION;
	float2 Tex0	: TEXCOORD0;
};

VS_OUTPUT VS11(VS_INPUT In)
{
	VS_OUTPUT Out;
	
	Out.Pos = mul( In.Pos, WorldViewProj );
	Out.Tex0 = In.Tex0;
	
	return Out;
}

sampler2D BaseSampler : register(s0);

float4 PS11(VS_OUTPUT In) : COLOR
{
	float4 Color = tex2D( BaseSampler, In.Tex0 );
	float3 Target = mul( GrayScaleFactor, Color.rgb );
	Color.rgb = Color.rgb + GrayBlendingValue * ( Target.rgb - Color.rgb );
	return Color;
}

float4 PS14(VS_OUTPUT In) : COLOR
{
	float4 Color = tex2D( BaseSampler, In.Tex0 );
	Color.rgb = lerp( Color.rgb, mul( GrayScaleFactor, Color.rgb ), GrayBlendingValue );
	return Color;
}