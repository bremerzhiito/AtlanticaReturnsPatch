float4x4	WorldViewProj		: register(c0);
float4x4	ViewProj			: register(c4);
float4x2	TexTransformBase	: register(c8);
float4		MaterialEmissive	: register(c10);

static const int MAX_BONES = 20;
float4x3 Bone[MAX_BONES];

struct VS_INPUT
{
	float4 Pos				: POSITION;
	float4 iBlendWeights	: BLENDWEIGHT;
	float4 iBlendIndices	: BLENDINDICES;
	float4 Color			: COLOR0;
	float2 TexCoords		: TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 Pos				: POSITION;
	float4 Color			: COLOR0;
	float2 TexCoords    	: TEXCOORD0;
};

void CalculateSkinnedPos(
		in float4 iPos, 
		in float4 iBlendWeights, 
		in float4 iBlendIndices,
		out float4 oPos)
{
	// Compensate for lack of UBYTE4 on Geforce3
    int4 indices = D3DCOLORtoUBYTE4(iBlendIndices);

    // Calculate normalized fourth bone weight
    float weight4 = 1.0f - iBlendWeights[0] - iBlendWeights[1] - iBlendWeights[2];

    // Calculate bone transform to world space
    float4x3 BoneWorld;
	BoneWorld = iBlendWeights[0] * Bone[indices[0]];
	BoneWorld += iBlendWeights[1] * Bone[indices[1]];
	BoneWorld += iBlendWeights[2] * Bone[indices[2]];
	BoneWorld += weight4 * Bone[indices[3]];
	
    //
    // Transform skinned position to view space
    //
	oPos = float4( mul( iPos, BoneWorld ), 1.0f );
}

VS_OUTPUT VS(VS_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;

	// Position
	float4 lBoneSpacePos;
	CalculateSkinnedPos( In.Pos, In.iBlendWeights, In.iBlendIndices, lBoneSpacePos);
	Out.Pos = mul( lBoneSpacePos, ViewProj );
	
	// Color
	float4 oColor = In.Color * MaterialEmissive;
	Out.Color = oColor;
	
	// Tex coord
	Out.TexCoords = mul( float4( In.TexCoords, 1.0f, 1.0f ), TexTransformBase );
	
	return Out;	
}

sampler2D BaseSampler : register(s0);

float4 PS(VS_OUTPUT In) : COLOR
{
	//return float4(1.0f, 0.0f, 0.0f, 1.0f);
	return In.Color * tex2D( BaseSampler, In.TexCoords );
}