
//------------------------------------------------------------------------------
//
//	Transformation Matrices
//
float4x4 World			: WORLD;
float4x4 View			: VIEW;
float4x4 ViewProj		: VIEWPROJ;
float4x4 InvView		: INVVIEW;
float3 EyePos			: EYEPOS;
float4x4 ReflViewProj	: ATTRIBUTE;

//------------------------------------------------------------------------------
//
//	Fog Paramters
//

float4 FogColor		: FOGCOLOR = { 0.42f, 0.45f, 0.6f, 1.f };
float4 FogNearFar	: FOGNEARFAR = { 0.0f, 0.0f, 0.f, 0.f };
float4 FogDensity	: FOGDENSITY = { 1.0f, 1.0f, 1.0f, 1.0f };

//------------------------------------------------------------------------------
//
//	Light Paramters
//

float4 LightAmbient : Ambient
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float4 LightDiffuse : Diffuse
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float3 LightDirection : Direction
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float4 Multiplier : GLOBAL = 1.0f;

//------------------------------------------------------------------------------
//
//	Water Paramters
//

float	 kBumpScale				: GLOBAL = 0.14f;
float4	 kTexScale              : GLOBAL = float4( 0.7f, 1.2f, 0.0f, 0.0f);				// texture scale
float4   kBumpSpeed				: GLOBAL = float4( 0.006f, 0.003f, 0.0f, 0.0f);

float4	 kDeepColor				: GLOBAL = float4( 0.4f, 0.4f, 0.8f, 1.0f );   // deep water color
float4	 kShallowColor          : GLOBAL = float4( 0.4f, 0.6f, 1.0f, 1.0f );   // shallow water color
float4	 kReflectionColor       : GLOBAL = float4( 0.35f, 0.35f, 0.35f, 1.0f );  // reflection color

float	 kReflectionAmount		: GLOBAL = 1.0f;                // reflection amount
float	 kWaterAmount			: GLOBAL = 0.3f;                // water color amount

float	 kFresnelPower			: GLOBAL = 9.0f;
float	 kFresnelBias			: GLOBAL = 0.228f;

float    kTime					: GLOBAL = 100.0f;				

//------------------------------------------------------------------------------
//
//	Calculation Functionsd
//

float4 CalculateLightAmbientDiffuse(in float3 iNormal)
{
	return LightAmbient + LightDiffuse * saturate( dot( -LightDirection, iNormal ) );
}

float CalculateFogValue(in float4 iPos)
{
	return saturate( ( iPos.z - FogNearFar.x ) / ( FogNearFar.y - FogNearFar.x ) );	
}

//------------------------------------------------------------------------------
//
//	Vertex Shader
//

void VS(
	in float4 iPos : POSITION,
	in float2 iUV0 : TEXCOORD0,
	out float4 oPos : POSITION,
	out float2 oBumpCoord0 : TEXCOORD0,
	out float2 oBumpCoord1 : TEXCOORD1,
	out float2 oBumpCoord2 : TEXCOORD2,
	out float3 oEyeVector : TEXCOORD3,
	out float4 oReflUV : TEXCOORD4,
	out float oFog : TEXCOORD5)
{
	// Transform vertex
	float4 WorldPos = mul( iPos, World );
	oPos = mul( WorldPos, ViewProj );
	
	// calculate texture coordinates for normal map lookup
	oBumpCoord0 = iUV0 * kTexScale + kTime * kBumpSpeed;
	oBumpCoord1 = iUV0 * kTexScale * 2.0f + kTime * kBumpSpeed * 4.0f;
	oBumpCoord2 = iUV0 * kTexScale * 4.0f + kTime * kBumpSpeed * 8.0f;
	
	/*
	oBumpCoord0 = iUV0 * kTexScale + kTime * kBumpSpeed;
	oBumpCoord1 = iUV0.yx * kTexScale - kTime * kBumpSpeed;
	oBumpCoord2 = iUV0 * kTexScale * 2.0f + kTime * kBumpSpeed;
	*/
	
	// Calculate reflection texcoord
	float4 reflPos = mul( WorldPos, ReflViewProj );
	oReflUV.x = 0.5 * (reflPos.w + reflPos.x);
	oReflUV.y = 0.5 * (reflPos.w - reflPos.y);
	oReflUV.z = length( WorldPos.xyz - EyePos );
	oReflUV.w = reflPos.w;
	
	// Calculate eye vector
	oEyeVector = EyePos - WorldPos.xyz;
	
	// Calculate fog value
	float4 viewPos = mul( WorldPos, View );
	oFog = CalculateFogValue( viewPos );
}

//------------------------------------------------------------------------------
//
//	Textures and Samplers
//

texture NormalTex
<
	string NTM = "Shader";
	int NTMIndex = 1;
>;

sampler2D NormalSampler = sampler_state
{
	Texture = (NormalTex);	
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = LINEAR;
};

texture ReflectionMap
<
	string NTM = "Shader";
	int NTMIndex = 2;
>;

sampler2D ReflectionSampler = sampler_state
{
   Texture = (ReflectionMap);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};

//------------------------------------------------------------------------------
//
//	Pixel Shader
//

void PS(
	in float2 iBumpCoord0 : TEXCOORD0,
	in float2 iBumpCoord1 : TEXCOORD1,
	in float2 iBumpCoord2 : TEXCOORD2,
	in float3 iEyeVector : TEXCOORD3,
	in float4 iReflUV : TEXCOORD4,
	in float iFog : TEXCOORD5,
	out float4 oColor : COLOR)
{
	// Get surface normal
    float4 t0 = tex2D( NormalSampler, iBumpCoord0 );
    float4 t1 = tex2D( NormalSampler, iBumpCoord1 );
    float4 t2 = tex2D( NormalSampler, iBumpCoord2 );
    float3 N = 2.0f * ( t0.xyz + t1.xyz + t2.xyz ) - 3.0f;
    N.xy = N.xy * kBumpScale;
    N = normalize( N );
    
    // Calculate light
    //float4 Light = CalculateLightAmbientDiffuse( N );

	// Eye Vector
	float3 E = normalize( iEyeVector );
	
	// fresnel
	float facing = 1.0f - max( dot( N, E ), 0 );
	float fresnel = kFresnelBias + ( 1.0f - kFresnelBias ) * pow( facing, kFresnelPower ); 
	
	// water color
	float4 waterColor = lerp( kShallowColor, kDeepColor, facing ) * kWaterAmount;

	// reflection color
	float2 refUV = iReflUV.xy / iReflUV.w + N.xy * ( 10.f / iReflUV.z );// * 0.5f;
	float4 reflection = tex2D( ReflectionSampler, refUV );
    reflection.rgb *= (reflection.r + reflection.g + reflection.b) * kReflectionAmount; // cheap hdr effect
	reflection = lerp( waterColor, reflection * kReflectionColor, fresnel ) * kReflectionAmount;
	
	float3 finalColor = ( waterColor.rgb + reflection.rgb );// * Light;
	finalColor = lerp( finalColor, FogColor.rgb, iFog );
	
	oColor = float4( finalColor, 1.0f );
}

//------------------------------------------------------------------------------
//
//	Techniques
//

technique nds_ocean_with_reflection
<
	bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
    pass P0
    {
        VertexShader = compile vs_2_0 VS();
        PixelShader  = compile ps_2_0 PS();
    }
}