//--------------------------------------------------------------
//
//	Constants
//
//--------------------------------------------------------------

float4x4 WorldViewProj		: WORLDVIEWPROJECTION;
float Sky_Interpolation 	: GLOBAL;

//--------------------------------------------------------------
//
//	Textures and Samplers
//
//--------------------------------------------------------------

texture BaseMap
<
	string NTM = "Base";
>;

sampler2D BaseSampler = sampler_state
{
   Texture = (BaseMap);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};

texture NormalMap
<
	string NTM = "Normal";
>;
sampler2D NormalSample = sampler_state
{
   Texture = (NormalMap);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = NONE;
};

//--------------------------------------------------------------
//
//	Vertex Shader
//
//--------------------------------------------------------------

void VS(
	in	float4	iPos		: POSITION,
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oPos		: POSITION,
	out	float2	oBaseTex	: TEXCOORD0)
{
	oPos = mul( iPos, WorldViewProj );
	
	oBaseTex = iBaseTex;
}

//--------------------------------------------------------------
//
//	Pixel Shader
//
//--------------------------------------------------------------

void PS(
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iBaseTex );
}

void PS_src(
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oColor		: COLOR)
{
	oColor = tex2D( BaseSampler, iBaseTex );
}

void PS_dst(
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oColor		: COLOR)
{
	oColor = tex2D( NormalSample, iBaseTex );
}

void PS_blending(
	in	float2	iBaseTex	: TEXCOORD0,
	out	float4	oColor		: COLOR)
{
	float4 colorSrc = tex2D( BaseSampler, iBaseTex );
	float4 colorDst = tex2D( NormalSample, iBaseTex );
	oColor = lerp( colorSrc, colorDst, Sky_Interpolation );
}

//--------------------------------------------------------------
//
//	Techniques
//
//--------------------------------------------------------------

technique nds_skybox_default
<
	bool UsesNiRenderState = true;
	bool UsesNiLightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}

technique nds_skybox_onlySrc
<
	bool UsesNiRenderState = true;
	bool UsesNiLightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS_src();
	}
}

technique nds_skybox_onlyDest
<
	bool UsesNiRenderState = true;
	bool UsesNiLightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS_dst();
	}
}

technique nds_skybox_blending
<
	bool UsesNiRenderState = true;
	bool UsesNiLightState = false;
>
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS_blending();
	}
}
