float4x4 WorldViewProj : WORLDVIEWPROJECTION;
float4x4 ViewProjTopCamera : GLOBAL;

static const int MAX_LIGHTS = 5;
static const float TEXSIZE = 1024.0f;
static const float MINBRIGHT = 0.4f;
float4 Lights[MAX_LIGHTS] : GLOBAL;
float3 g_warfogColor : GLOBAL;

//------------------------------------------------------------------------------
//	BaseMap

texture BaseMap
<
	string NTM = "base";
>;

sampler2D BaseSampler = sampler_state
{
	Texture = (BaseMap);
	ADDRESSU = CLAMP;
	ADDRESSV = CLAMP;
    MAGFILTER = LINEAR;
    MINFILTER = LINEAR;
    MIPFILTER = LINEAR;
};

struct VS_OUTPUT
{
	float4 Pos : POSITION;
	float4 ViewPos : TEXCOORD0;
	float2 UV1 : TEXCOORD1;
};

VS_OUTPUT VS(float4 Pos : POSITION)
{
	VS_OUTPUT Out;
	
	Out.Pos = mul(Pos, ViewProjTopCamera);
	
	Out.ViewPos = Out.Pos / Out.Pos.w;
	Out.UV1.x = Out.ViewPos.x * 0.5f + 0.5f + 0.5/TEXSIZE;
	Out.UV1.y = Out.ViewPos.y * -0.5f + 0.5f + 0.5/TEXSIZE;	
	Out.ViewPos.z = 0.0f;
	
	return Out;
}

float4 PS(float4 vPos : TEXCOORD0, float2 UV1 : TEXCOORD1) : COLOR
{	
	float4 oColor = float4(0.0f, 0.0f, 0.0f, 1.0f);
	
	for(int i=0;i<MAX_LIGHTS;++i)
	{
		if(Lights[i].w < 0.0f)
		 continue;
		 
		float3 kLightPos = Lights[i];
		//float radius = kLightPos.z;
		//float radius = 0.013f;
		float radius = Lights[i].w;
		kLightPos.z = 0;
		float fDistance = distance(kLightPos, vPos);
		float intention = saturate(radius / fDistance);
		//if(intention < 1.0f)
			//intention = intention * 0.5f;

		intention = pow(intention, 10);
		
		//oColor += float4(1.0f, 1.0f, 1.0f, 1.0f)  * saturate(radius / fDistance);
		//oColor += float4(1.0f, 1.0f, 1.0f, 1.0f)  * saturate((radius - fDistance) / radius);
		//oColor += float4(1.0f, 0.0f, 0.0f, 1.0f)  * intention;
		oColor.rgb += g_warfogColor * intention;
	}
	
	float4 DstColor = tex2D(BaseSampler, UV1);
	oColor = oColor + DstColor;
	
	oColor.r = oColor.r > MINBRIGHT ? oColor.r : MINBRIGHT;
	oColor.g = oColor.g > MINBRIGHT ? oColor.g : MINBRIGHT;
	oColor.b = oColor.b > MINBRIGHT ? oColor.b : MINBRIGHT;

	return oColor;
}

technique NkWarFogLightMap
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}
