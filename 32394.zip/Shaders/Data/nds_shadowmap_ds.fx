// EMERGENT GAME TECHNOLOGIES PROPRIETARY INFORMATION
//
// This software is supplied under the terms of a license agreement or
// nondisclosure agreement with Emergent Game Technologies and may not 
// be copied or disclosed except in accordance with the terms of that 
// agreement.
//
//      Copyright (c) 1996-2006 Emergent Game Technologies.
//      All Rights Reserved.
//
// Emergent Game Technologies, Chapel Hill, North Carolina 27517
// http://www.emergent.net

// This file based heavily on ShadowMap.fx, from the DirectX 9.0 SDK Update 
// (Summer 2004). Parts of this file are Copyright (c) Microsoft Corporation. 

float4x4 kWorldView				: WORLDVIEW;
float4x4 kSkinWorldView			: WORLDVIEW;
float4x4 ViewProj				: VIEWPROJ;
float4x4 ShadowViewToLightProj	: GLOBAL;

static const int MAX_BONES = 20;
float4x3 Bones[MAX_BONES] : SKINBONEMATRIX3;





//------------------------------------------------------------------------------
//
//	BaseMap
//

texture BaseMap
<
	string NTM = "base";
>;
sampler2D BaseSampler = sampler_state
{
	Texture = (BaseMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MINFILTER = LINEAR;
	MAGFILTER = LINEAR;
	MIPFILTER = LINEAR;
};





//-----------------------------------------------------------------------------
// Vertex Shader: VertShadowDS
// Desc: 
//-----------------------------------------------------------------------------
void VertShadowDS( float4 Pos : POSITION,
				   float2 BaseTex : TEXCOORD0,
                   out float4 oPos : POSITION,
                   out float2 oBaseTex : TEXCOORD0 )
{
    //
    // Compute the projected coordinates
    //
    oPos = mul( Pos, kWorldView );    
    oPos = mul( oPos, ShadowViewToLightProj );
    
    oBaseTex = BaseTex;
}


//-----------------------------------------------------------------------------
// Vertex Shader: VertShadowSkinnedDS
// Desc: 
//-----------------------------------------------------------------------------
void VertShadowSkinnedDS( float4 Pos : POSITION,						  
                          float4 inBlendWeights : BLENDWEIGHT, 
                          float4 inBlendIndices : BLENDINDICES,
                          float2 BaseTex : TEXCOORD0,
                          out float4 oPos : POSITION,
                          out float2 oBaseTex : TEXCOORD0 )
{
	// Compensate for lack of UBYTE4 on Geforce3
    //int4 indices = D3DCOLORtoUBYTE4(inBlendIndices);

    // Calculate normalized fourth bone weight
    float fWeight3 = 1.0 - inBlendWeights[0] - inBlendWeights[1] - inBlendWeights[2];
    float4x3 ShortSkinBoneTransform;
    ShortSkinBoneTransform  = Bones[inBlendIndices[0]] * inBlendWeights[0];
    ShortSkinBoneTransform += Bones[inBlendIndices[1]] * inBlendWeights[1];
    ShortSkinBoneTransform += Bones[inBlendIndices[2]] * inBlendWeights[2];
    ShortSkinBoneTransform += Bones[inBlendIndices[3]] * fWeight3;

    // Transform into world space.
   	oPos = float4( mul( Pos, ShortSkinBoneTransform ), 1.0f );
	//oPos.xyz = mul( Pos, ShortSkinBoneTransform );
    //oPos = mul( float4(oPos.xyz, 1.0), kSkinWorldView );
    oPos = mul( oPos, ViewProj );

        	
    //
    //
	oBaseTex = BaseTex;
}


//-----------------------------------------------------------------------------
// Pixel Shader: PixShadowDS
// Desc: 
//-----------------------------------------------------------------------------
void PixShadowDS( in  float2 BaseTex : TEXCOORD0,
				  out float4 Color : COLOR )
{    
    Color = float4( 0.0f, 0.0f, 0.0f, tex2D(BaseSampler, BaseTex).a );    
}


//-----------------------------------------------------------------------------
// Technique: ShadowMapRenderShadowDS
// Desc: 
//-----------------------------------------------------------------------------
technique nds_ShadowMap_RenderShadow_DS
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = false;
>
{
    pass p0
    {        
        AlphaBlendEnable = FALSE;
		ZWriteEnable = TRUE;
        
        VertexShader = compile vs_2_0 VertShadowDS();
        PixelShader = compile ps_2_0 PixShadowDS();
    }
}


//-----------------------------------------------------------------------------
// Technique: ShadowMapRenderShadowSkinnedDS
// Desc: 
//-----------------------------------------------------------------------------
technique nds_ShadowMap_RenderShadowSkinned_DS
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = false;
    int BonesPerPartition = MAX_BONES;
>
{
    pass p0
    {        
        AlphaBlendEnable = FALSE;
        ZWriteEnable = TRUE;
        
        VertexShader = compile vs_2_0 VertShadowSkinnedDS();        
        PixelShader = compile ps_2_0 PixShadowDS();        
    }
}
