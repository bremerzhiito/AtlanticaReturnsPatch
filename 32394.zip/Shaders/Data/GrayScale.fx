float4x4 WorldViewProj : WORLDVIEWPROJECTION;
float3 GrayScaleFactor : GLOBAL = { 0.3, 0.59, 0.11 };
float GrayBlendingValue : GLOBAL = 0;

struct VS_OUTPUT
{
	float4 Pos : POSITION;
	float2 Tex0 : TEXCOORD0;
};

texture BaseMap
<
    string NTM = "base";
>;

sampler BaseSampler = sampler_state
{
   Texture = (BaseMap);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = LINEAR;
};

VS_OUTPUT VS(float4 Pos : POSITION, float2 Tex0 : TEXCOORD0)
{
	VS_OUTPUT Out;
	
	Out.Pos = mul(Pos, WorldViewProj);
	Out.Tex0 = Tex0;
	
	return Out;
}

float4 PS(VS_OUTPUT In) : COLOR
{	
	//float4 Color = tex2D(BaseSampler, In.Tex0);
	//Color.rgb = lerp(Color.rgb, mul(GrayScaleVector, Color.rgb), GrayBlendingValue);
	
	float4 Color = tex2D( BaseSampler, In.Tex0 );
	float3 Target = mul( GrayScaleFactor, Color.rgb );
	Color.rgb = Color.rgb + GrayBlendingValue * ( Target.rgb - Color.rgb );
	
	return Color;
}

technique GrayScale_Old
{
	pass P0
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}