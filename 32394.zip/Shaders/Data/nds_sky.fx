//--------------------------------------------------------------
float4x4 World			: WORLD;
float4x4 WorldViewProj	: WORLDVIEWPROJECTION;
float4x2 TransHighCloud	: TEXTRANSFORMDETAIL;
float4x2 TransLowCloud	: TEXTRANSFORMGLOSS;
//--------------------------------------------------------------
float3 Sky_EyePos		: GLOBAL;
float Sky_Day			: GLOBAL;
float Sky_SpaceScale	: GLOBAL = { 4.0 };
float3 Sky_EyeDir		: GLOBAL;
float3 Sky_SunDir		: GLOBAL;
//--------------------------------------------------------------
texture MapGrad
<
    string NTM = "Base";
>;
sampler SamplerGrad= sampler_state
{
   Texture = (MapGrad);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = LINEAR;
};
//--------------------------------------------------------------
texture MapSpace
<
    string NTM = "Dark";
>;
sampler SamplerSpace = sampler_state
{
   Texture = (MapSpace);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = LINEAR;
};
//--------------------------------------------------------------
texture MapHighCloud
<
    string NTM = "Detail";
>;
sampler SamplerHighCloud = sampler_state
{
   Texture = (MapHighCloud);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = LINEAR;
};
//--------------------------------------------------------------
texture MapLowCloud
<
    string NTM = "Gloss";
>;
sampler SamplerLowCloud = sampler_state
{
   Texture = (MapLowCloud);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = LINEAR;
};
//--------------------------------------------------------------
struct VS_BASE_INPUT
{
	float4 Pos : POSITION;
};
struct VS_BASE_OUTPUT
{
	float4 Pos		: POSITION;
	float3 Vec		: TEXCOORD0;
	float Scale		: TEXCOORD1;
	float Offset	: TEXCOORD2;
	float Blend		: TEXCOORD3;
};
//--------------------------------------------------------------
VS_BASE_OUTPUT VSBase(VS_BASE_INPUT In)
{
	VS_BASE_OUTPUT Out;
	
	Out.Pos = mul(In.Pos, WorldViewProj);
	Out.Vec = mul(In.Pos, World) - Sky_EyePos;
	
	Out.Scale = Sky_SpaceScale * 0.1592;
	Out.Offset = Sky_SpaceScale * frac(Sky_Day) + Sky_SpaceScale / 365 * Sky_Day;
	Out.Blend = min(pow(3.5 * (frac(Sky_Day) - 0.5), 6), 1);
	
	return Out;
}
//--------------------------------------------------------------
float4 PSBase(VS_BASE_OUTPUT In) : COLOR
{
	float4 Out;
	float3 Vec = normalize(In.Vec);
	float4 tempColor;
	float2 tempCoord;
	
	//-----------------------------------------------------------------------
	// Gradation
	
	tempCoord.x = Vec.z;
	tempCoord.y = frac(Sky_Day);
	
	Out = tex2D(SamplerGrad, tempCoord);

	//-----------------------------------------------------------------------
	// Space
	
	tempCoord = normalize(In.Vec.xy);
	tempCoord = tempCoord * acos(Vec.z) * In.Scale;
	tempCoord.x = tempCoord.x + In.Offset;
	
	tempColor = tex2D(SamplerSpace, tempCoord);
	tempColor.a = tempColor.a * In.Blend;
	tempColor.a = tempColor.a * clamp(3 * Vec.z / (Vec.z + 0.5) + 0.1, 0, 1);
	
	Out.rgb = (1 - tempColor.a) * Out.rgb + tempColor.a * tempColor.rgb;

	return Out;
}
//--------------------------------------------------------------
struct VS_SUN_INPUT
{
	float4 Pos			: POSITION;
};
struct VS_SUN_OUTPUT
{
	float4 Pos				: POSITION;
	float3 Vec				: TEXCOORD0;
	float A					: TEXCOORD1;
	float B					: TEXCOORD2;
};
//--------------------------------------------------------------
VS_SUN_OUTPUT VSSun(VS_SUN_INPUT In)
{
	VS_SUN_OUTPUT Out;
	
	Out.Pos = mul(In.Pos, WorldViewProj);
	Out.Vec = mul(In.Pos, World) - Sky_EyePos;
	Out.A = 15 * exp( dot(Sky_SunDir, Sky_EyeDir) + 1 ) - 1;
	Out.A = clamp( Out.A, 55, 78 );
	Out.B = dot(Sky_SunDir, float3(0, 0, 1));
	Out.A *= ((0.1 * Out.B) + 0.9);

	return Out;
}
//--------------------------------------------------------------
float4 PSSun(VS_SUN_OUTPUT In) : COLOR
{
	float4 Out = float4(0, 0, 0, 0);
	float3 Vec = normalize(In.Vec);
	float4 tempColor;
	
	//-----------------------------------------------------------------------
	// Sun
	tempColor = tex2D(SamplerGrad, float2(0, frac(Sky_Day)));
	float C = clamp(pow( 500 * ( dot(Sky_SunDir, Vec) - 0.999995 ), 3 ) + 1, 0, 1);
	Out.rgb = tempColor.rgb;
	Out.a = C;
	
	//-----------------------------------------------------------------------
	// Inner Glow
	float E = max(exp( 512 * (dot(Sky_SunDir, Vec) - 1 ) ), 0);
	Out.rgb = Out.rgb + ( -Out.rgb + 1 ) * ( tempColor.rgb * 4 ) * E;
	Out.a = max(E, Out.a);
	
	//-----------------------------------------------------------------------
	// Outer Glow
	E = max(exp( ( 100 - In.A ) / 5 * (dot(Sky_SunDir, Vec) - 1.1 ) ), 0);
	Out.rgb = Out.rgb + ( -Out.rgb + 1 ) * ( float3(1, 0.9, 0.1) * 2 ) * E;
	Out.a = max(E, Out.a);

	return Out;
}
//--------------------------------------------------------------
struct VS_CLOUD_INPUT
{
	float4 Pos			: POSITION;
	float2 CloudCoord	: TEXCOORD0;
};
struct VS_CLOUD_OUTPUT
{
	float4 Pos				: POSITION;
	float2 CoordHighCloud	: TEXCOORD0;
	float2 CoordLowCloud	: TEXCOORD1;
	float3 Vec				: TEXCOORD2;
};
//--------------------------------------------------------------
VS_CLOUD_OUTPUT VSCloud(VS_CLOUD_INPUT In)
{
	VS_CLOUD_OUTPUT Out;
	
	Out.Pos = mul(In.Pos, WorldViewProj);
	Out.CoordHighCloud = mul(float4(In.CloudCoord, 1.0f, 1.0f), TransHighCloud);
	Out.CoordLowCloud = mul(float4(In.CloudCoord, 1.0f, 1.0f), TransLowCloud);
	Out.Vec = mul(In.Pos, World) - Sky_EyePos;

	return Out;
}
//--------------------------------------------------------------
float4 PSCloud(VS_CLOUD_OUTPUT In) : COLOR
{
	float4 Out = float4(0, 0, 0, 0);
	float3 Vec = normalize(In.Vec);
	float4 tempColor;
	
	float rate = 3 * Vec.z / (Vec.z + 0.5);
	rate = clamp(rate, 0, 1);

	//-----------------------------------------------------------------------
	// High cloud
	tempColor = tex2D(SamplerHighCloud, In.CoordHighCloud);
	tempColor.a = tempColor.a * rate;
	Out = tempColor;

	//-----------------------------------------------------------------------
	// Low cloud
	tempColor = tex2D(SamplerLowCloud, In.CoordLowCloud);
	tempColor.a = tempColor.a * rate;
	Out.rgb = (1 - tempColor.a) * Out.rgb + tempColor.a * tempColor.rgb;
	Out.a = Out.a + (1 - Out.a) * tempColor.a;
	
	return Out;
}
//--------------------------------------------------------------
technique nds_sky
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = false;
>
{
	pass BasePass
	{
		AlphaBlendEnable = false;
		AlphaTestEnable = false;
		ZEnable = false;
		ZWriteEnable = false;
		
		VertexShader = compile vs_2_0 VSBase();
		PixelShader = compile ps_2_0 PSBase();
	}
	
	pass SunPass
	{
		AlphaBlendEnable = true;
		AlphaTestEnable = false;
		SrcBlend = SRCALPHA;
		DestBlend = ONE;
		ZEnable = false;
		ZWriteEnable = false;

		VertexShader = compile vs_2_0 VSSun();
		PixelShader = compile ps_2_0 PSSun();
	}

	pass CloudPass
	{
		AlphaBlendEnable = true;
		AlphaTestEnable = false;
		SrcBlend = SRCALPHA;
		DestBlend = INVSRCALPHA;
		ZEnable = false;
		ZWriteEnable = false;
	
		VertexShader = compile vs_2_0 VSCloud();
		PixelShader = compile ps_2_0 PSCloud();
	}
}