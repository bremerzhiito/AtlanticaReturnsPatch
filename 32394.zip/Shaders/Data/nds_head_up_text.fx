// from Simple FX Skinning Shader

// World
float4x4	WorldViewProj		: WORLDVIEWPROJECTION;

// Material
float4x2	TexTransformBase	: TEXTRANSFORMBASE;

struct VSHEADUP_INPUT
{
	float4 Pos			: POSITION;
	float4 Color		: COLOR0;
	float2 TexCoords	: TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 Pos			: POSITION;
	float4 Color		: COLOR0;
	float2 TexCoords 	: TEXCOORD0;
};

//----------------------------------------------------
//
//	Map
//
//----------------------------------------------------

texture BaseMap
<
	string NTM = "base";
>;


//----------------------------------------------------
//
//	Sampler
//
//----------------------------------------------------

sampler BaseSampler = sampler_state
{
	Texture = (BaseMap);
	AddressU = WRAP;
	AddressV = WRAP;
	MinFilter = LINEAR;
	MagFilter = LINEAR;
	MipFilter = NONE;
};


//----------------------------------------------------
//
//	Vertex shader effect
//
//----------------------------------------------------

VS_OUTPUT VSHEADUP(VSHEADUP_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;

	// Position
	Out.Pos = mul(In.Pos, WorldViewProj);
	
	// Color
	Out.Color = In.Color;
	
	// Tex coord
	Out.TexCoords = mul(float4(In.TexCoords, 1.0f, 1.0f), TexTransformBase);
	
	return Out;	
}

//----------------------------------------------------
//
//	Pixel shader effect
//
//----------------------------------------------------

float4 PSHEADUP(VS_OUTPUT In) : COLOR
{
	float4 Source = tex2D(BaseSampler, In.TexCoords);
	float4 Out = In.Color;
	Out.a = Source.a;
	return Out;
}

//--------------------------------------------------------
//
//	effect technique
//
//
//----------------------------------------------------

technique nds_head_up_text
<
	bool UsesNiRenderState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSHEADUP();
		PixelShader  = compile ps_2_0 PSHEADUP();
	}
}
