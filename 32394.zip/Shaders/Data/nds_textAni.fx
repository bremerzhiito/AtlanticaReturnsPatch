// from Simple FX Skinning Shader

// World
float4x4 WorldViewProj		: WORLDVIEWPROJECTION;
float4x4 InvWorld			: INVWORLD;

// Material
float4 Emmitance			: MATERIALEMISSIVE;
float4x2 TexTransformBase	: TEXTRANSFORMBASE;


//----------------------------------------------------
//
//	Light
//

float4 cLightAmbient : Ambient
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;

float4 cLightDiffuse : Diffuse
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;


struct VSANITEXT_INPUT
{
	float4 Pos			: POSITION;
	float4 Color		: COLOR0;
	float2 TexCoords	: TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 Pos			: POSITION;
	float4 Color		: COLOR0;
	float2 TexCoords    : TEXCOORD0;
};


//----------------------------------------------------
//
//	Map
//

texture BaseMap
<
	string NTM = "base";
>;

//----------------------------------------------------
//
//	Sampler
//

sampler BaseSampler = sampler_state
{
	Texture = (BaseMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MAGFILTER = LINEAR;
	MINFILTER = LINEAR;
	MIPFILTER = LINEAR;
};

//----------------------------------------------------
//
//	Vertex shader effect
//
VS_OUTPUT VSTEXTANI(VSANITEXT_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;

	// Position
	Out.Pos = mul(In.Pos, WorldViewProj);
	
	// Color
	Out.Color = In.Color;
	Out.Color *= Emmitance;
	
	// Tex coord
	Out.TexCoords = mul(float4(In.TexCoords, 1.0f, 1.0f), TexTransformBase);
	
	return Out;	
}

//----------------------------------------------------
//
//	Pixel shader effect
//

float4 PSTEXTANI(VS_OUTPUT In) : COLOR
{
	float4 Out =  tex2D(BaseSampler, In.TexCoords);
	Out = Out * In.Color;
	
	return Out;
}

//--------------------------------------------------------
//
//	effect technique
//
//

technique nds_anitext
<
	bool UsesNiRenderState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSTEXTANI();
		PixelShader = compile ps_2_0 PSTEXTANI();
	}
}


