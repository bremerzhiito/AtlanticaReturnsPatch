// from Simple FX Skinning Shader

// World
float4x4 WorldViewProj		: WORLDVIEWPROJECTION;
float4x4 InvWorld		: INVWORLD;

// Material
float4 Emmitance		: MATERIALEMISSIVE;
float4x2 TexTransformBase	: TEXTRANSFORMBASE;

// Constants
float BillAlpha : ATTRIBUTE 
<
    float min = 0.0f;
    float max = 1.0f;
> = 1.0f;


struct VSBILLUNIT_INPUT
{
	float4 Pos		: POSITION;
	float4 Color		: COLOR0;
	float2 TexCoords	: TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 Pos		: POSITION;
	float4 Color		: COLOR0;
	float2 TexCoords 	: TEXCOORD0;
};

//----------------------------------------------------
//
//	Map
//

texture BaseMap
<
	string NTM = "base";
>;

//----------------------------------------------------
//
//	Sampler
//

sampler BaseSampler = sampler_state
{
	Texture = (BaseMap);
	AddressU = WRAP;
	AddressV = WRAP;
	MinFilter = LINEAR;
	MagFilter = LINEAR;
	MipFilter = NONE;
};


//----------------------------------------------------
//
//	Vertex shader effect
//
VS_OUTPUT VSBILLUNIT(VSBILLUNIT_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;

	// Position
	Out.Pos = mul(In.Pos, WorldViewProj);
	
	// Color
	Out.Color = In.Color;
	
	// Tex coord
	Out.TexCoords = mul(float4(In.TexCoords, 1.0f, 1.0f), TexTransformBase);
	
	return Out;	
}

//----------------------------------------------------
//
//	Pixel shader effect
//
float4 PSBILLUNIT(VS_OUTPUT In) : COLOR
{
	float4 Out =  tex2D(BaseSampler, In.TexCoords);
	Out.a = Out.a * BillAlpha;
	return Out;
}

float4 PSBILLUNITNOALPHA(VS_OUTPUT In) : COLOR
{
	float4 Out =  tex2D(BaseSampler, In.TexCoords);
	return Out;
}

float4 PSBILLUNITNOALPHA_NAME(VS_OUTPUT In) : COLOR
{
	float4 Alpha =  tex2D(BaseSampler, In.TexCoords);
    float4 Out = In.Color * Alpha;
	return Out;
}


//--------------------------------------------------------
//
//	effect technique
//
//

technique nds_billunit
<
	bool UsesNiRenderState = true;
>
{
	pass P0
	{
		ZEnable = FALSE;
		ZWriteEnable = FALSE;
		VertexShader = compile vs_2_0 VSBILLUNIT();
		PixelShader = compile ps_2_0 PSBILLUNIT();
	}
}

technique nds_billunit_noZbuffer
<
	bool UsesNiRenderState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSBILLUNIT();
		PixelShader = compile ps_2_0 PSBILLUNITNOALPHA();
	}
}

technique nds_billunit_noZbuffer_Name
<
	bool UsesNiRenderState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSBILLUNIT();
		PixelShader = compile ps_2_0 PSBILLUNITNOALPHA_NAME();
	}
}

technique nds_billunit_noZbuffer_Alpha
<
	bool UsesNiRenderState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSBILLUNIT();
		PixelShader = compile ps_2_0 PSBILLUNIT();
	}
}
