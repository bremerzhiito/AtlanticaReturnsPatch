texture BaseMap
<
	string NTM = "base";
>;
sampler2D BaseSampler = sampler_state
{
	Texture = (BaseMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MINFILTER = LINEAR;
	MAGFILTER = LINEAR;
	MIPFILTER = LINEAR;
};

float4x4 SkinWorldViewProj	: VIEWPROJ;
float4x4 g_WorldViewProj	: WORLDVIEWPROJ;
static const int MAX_BONES = 20;
float4x3 Bone[MAX_BONES] : SKINBONEMATRIX3;
float3 g_silhouetteColor : GLOBAL = {1.0f, 0.0f, 0.0f};

void CalculateSkinnedPos(
		in float4 iPos, 
		in float4 iBlendWeights, 
		in float4 iBlendIndices,
		out float4 oPos)
{
	// Compensate for lack of UBYTE4 on Geforce3
    int4 indices = iBlendIndices;

    // Calculate normalized fourth bone weight
    float weight4 = 1.0f - iBlendWeights[0] - iBlendWeights[1] - iBlendWeights[2];

    // Calculate bone transform to world space
    float4x3 BoneWorld;
	BoneWorld = iBlendWeights[0] * Bone[indices[0]];
	BoneWorld += iBlendWeights[1] * Bone[indices[1]];
	BoneWorld += iBlendWeights[2] * Bone[indices[2]];
	BoneWorld += weight4 * Bone[indices[3]];
	
	oPos = float4( mul( iPos, BoneWorld ), 1.0f );
}

void VSSkinned(
	in	float4 iPos				: POSITION,
	in	float4 iBlendWeights	: BLENDWEIGHT,
	in	float4 iBlendIndices	: BLENDINDICES,
	in  float2 BaseTex 			: TEXCOORD0,
	out float2 oBaseTex 		: TEXCOORD0,
	out float4 oPos				: POSITION)
{
	// Position
	float4 lBoneSpacePos;
	CalculateSkinnedPos( iPos, iBlendWeights, iBlendIndices, lBoneSpacePos );
	oPos = mul( lBoneSpacePos, SkinWorldViewProj );
	oBaseTex = BaseTex;
}

void VSDefault( 
	float4 Pos : POSITION, 
	float2 BaseTex : TEXCOORD0, 
	out float4 oPos : POSITION, 
	out float2 oBaseTex : TEXCOORD0)
{
    oPos = mul( Pos, g_WorldViewProj );
	oBaseTex = BaseTex;
}

void PS( in float2 BaseTex : TEXCOORD0, out float4 Color : COLOR )
{    
	//Color = float4(1.0f, 0.1f, 0.1f, 1.0f);
    Color = float4( g_silhouetteColor.r, g_silhouetteColor.g, g_silhouetteColor.b, tex2D(BaseSampler, BaseTex).a );
}

technique nds_silhouette_skinned
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = false;
>
{
    pass p0
    {        
        AlphaBlendEnable = FALSE;
		//AlphaTestEnable = TRUE;
		ZWriteEnable = FALSE;
		ZFunc = GREATER;
        VertexShader = compile vs_2_0 VSSkinned();
        PixelShader = compile ps_2_0 PS();
    }
}

technique nds_silhouette_default
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = false;
>
{
    pass p0
    {        
        AlphaBlendEnable = FALSE;
		ZWriteEnable = FALSE;
		ZEnable = TRUE;
		ZFunc = GREATER;
		//CullMode = CCW;
		//AlphaFunc = GREATER;
        
        VertexShader = compile vs_2_0 VSDefault();
        PixelShader = compile ps_2_0 PS();
    }
}
