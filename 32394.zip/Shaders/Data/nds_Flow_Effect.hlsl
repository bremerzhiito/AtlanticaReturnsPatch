
//float4x4 view_proj_matrix : WORLDVIEWPROJ;
float4x4 world_view : WORLDVIEW;
float4x4 proj_matrix : PROJECTION;
float4 g_time : TIME;
float4 g_fogcolor : FOGCOLOR;
float4x2	MatrixTexbase;
float4x2	MatrixTexdark;
float4 g_fognearfar : FOGNEARFAR;
sampler2D BaseSampler : register(s0);
sampler2D DarkSampler : register(s1);
float4		MaterialEmissive	: register(c6);
float FlowSpeed;
float FlowDirectionY;

//--------------------------------------------------------------//
// Object
//--------------------------------------------------------------//
struct VS_OUTPUT {
   float4 Pos:     POSITION;
   float2 UVSet0:  TEXCOORD0;
   float2 UVSet1:  TEXCOORD1;   
   float3 FogDot:  TEXCOORD2;
};

VS_OUTPUT VS(float4 Pos: POSITION, float2 UVSet0 : TEXCOORD0){
   VS_OUTPUT Out;

	float4x4 outMatrix = mul(world_view, proj_matrix);
	Out.Pos = mul(Pos, outMatrix);
	//Out.Pos = mul(Pos, view_proj_matrix);
	Out.UVSet0 = mul ( float4 (UVSet0,1.0f, 1.0f),MatrixTexbase);
	Out.UVSet1 = mul ( float4 (UVSet0,1.0f, 1.0f),MatrixTexdark);
	Out.FogDot = float3(1.0f, 0.0f, 0.0f);

	float4 WorldViewPos = mul( Pos, world_view );
	Out.FogDot.x = saturate( ( WorldViewPos.z - g_fognearfar.x ) / ( g_fognearfar.y - g_fognearfar.x ) );
        
    return Out;
}

float4 PS
(
float2 UVSet0: TEXCOORD0,
float2 UVSet1: TEXCOORD1, 
float3 FogDot: TEXCOORD2
) : COLOR 
{
   float2 coord = UVSet0;
   
   
  if (FlowDirectionY == 0.0f)
     {
      coord.x = UVSet0.x;// + (g_time * FlowSpeed);
   }
 else
   {
	 coord.y = UVSet0.y;// + (g_time * FlowSpeed);
	}
	
	
   float4 finalColor1 ;
   float4 maskColor = tex2D(BaseSampler, coord);
   float4 patternColor = tex2D(DarkSampler, UVSet1);
   float4 finalColor = maskColor * patternColor * MaterialEmissive;
   
   // fog color calculate
    if ((finalColor.r+finalColor.g+finalColor.b)<=0.1f)
   {    
   finalColor1 = finalColor;
    }
 else
 { 
 finalColor1.rgb = lerp( finalColor.rgb, g_fogcolor.rgb, FogDot.x );
   }

  
   return finalColor1;
}
