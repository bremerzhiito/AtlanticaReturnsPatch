// from Simple FX Skinning Shader

// World
float4x4 WorldViewProj	: WORLDVIEWPROJECTION;
float4x4 WorldView		: WORLDVIEW;
float4x4 InvWorld		: INVWORLD;
float4x4 InvWorldView   : INVWORLDVIEW;

//----------------------------------------------------
//
//	Fog
//

// begin: narlamy ...................................
//
float4  FogColor	: FOGCOLOR = { 0.42f, 0.45f, 0.6f, 1.f };
float4	FogNearFar	: FOGNEARFAR = { 0.0f, 0.0f, 0.f, 0.f };
float4  FogDensity	: FOGDENSITY = { 1.0f, 1.0f, 1.0f, 1.0f };
//
// end: naralmy ......................................


//----------------------------------------------------
//
//	Light
//

float4 cLightAmbient : Ambient
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;

float4 cLightDiffuse : Diffuse
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;

float3 cLightDirection : Direction
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;

//----------------------------------------------------
//
//	Struct
//

struct VSNOSKINNED_INPUT
{
	float3 Pos			: POSITION;
	float3 Normal		: NORMAL;
	float4 Color		: COLOR0;
	float2 TexCoords	: TEXCOORD0;
	float2 TexCoords2	: TEXCOORD1;
};

struct VS_OUTPUT
{
	float4 Pos			: POSITION;
	float4 Color		: COLOR0;
	float4 FogVal       : COLOR1;
	float2 TexCoords    : TEXCOORD0;
	float2 TexCoords2   : TEXCOORD1;
};

//----------------------------------------------------
//
//	Map
//

texture BaseMap
<
	string NTM = "base";
>;

texture DarkMap
<
	string NTM = "dark";
>;

texture GlowMap
<
	string NTM = "glow";
>;

//----------------------------------------------------
//
//	Sampler
//

sampler BaseSampler = sampler_state
{
	Texture = (BaseMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MAGFILTER = LINEAR;
	MINFILTER = LINEAR;
	MIPFILTER = LINEAR;
};

sampler DarkSampler = sampler_state
{
	Texture = (DarkMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MAGFILTER = LINEAR;
	MINFILTER = LINEAR;
	MIPFILTER = LINEAR;
};

sampler GlowSampler = sampler_state
{
	Texture = (GlowMap);
	ADDRESSU = WRAP;
	ADDRESSV = WRAP;
	MAGFILTER = LINEAR;
	MINFILTER = LINEAR;
	MIPFILTER = LINEAR;
};

//----------------------------------------------------
//
//	Vertex shader no skin
//

VS_OUTPUT VSNoSkinned(VSNOSKINNED_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;

	// Position
	Out.Pos = mul( float4(In.Pos, 1), WorldViewProj );

 	// Normal
	float3 L = -cLightDirection;    
    float3 N = In.Normal;
    
	float3 vEyePos = mul( float4( 0, 0, 0, 1 ), InvWorldView );
    float3 Eye = normalize( vEyePos - In.Pos );
    
    float3 R = -Eye * 2.0f * dot( N, Eye ) * N;
    
    // �ݻ���
    float4 k_a = { 0.7f, 0.7f, 0.7f, 0.7f };	// ambient
    float4 k_d = { 1.0f, 1.0f, 1.0f, 1.0f };	// diffuse

	// Color
    Out.Color = cLightAmbient * k_a + cLightDiffuse * k_d * max(0, dot(N, L));
                //+ pow( max( 0, dot( L, R ) ), 3 );

	// Tex coord
	Out.TexCoords = In.TexCoords;
	Out.TexCoords2 = In.TexCoords2;
	
    // FOG

	// begin: narlamy *****************************
	//
	float3 camPos = mul( float4(In.Pos, 1), WorldView );
	float fFogRange = FogNearFar.y - FogNearFar.x;
	float fVertexDist = FogNearFar.y - camPos.z;
		
	Out.FogVal.x = clamp( (fVertexDist/fFogRange), 0.0f, 1.0f );	
	//
	// end: narlamy *******************************
	
	return Out;	
}


//----------------------------------------------------
//
//	Pixel shader default
//

float4 PSDefault(VS_OUTPUT In) : COLOR
{
	float4 Final;
	float4 Out =  tex2D(BaseSampler, In.TexCoords);

	Final = 1.5f * Out * In.Color;
	
	Final = lerp(FogColor, Final, In.FogVal.x);
	Final.a = Out.a;
	
	return Final;
}

float4 PS_Dark(VS_OUTPUT In) : COLOR
{
	float4 Final;
	float4 Out =  tex2D(BaseSampler, In.TexCoords);
	float4 Out2 = tex2D(DarkSampler, In.TexCoords2);
	
	Final = Out * Out2 * 1.5f * In.Color;
	
	Final = lerp(FogColor, Final, In.FogVal.x);
	Final.a = Out.a;
	
	return Final;
}

float4 PS_Glow(VS_OUTPUT In) : COLOR
{
	float4 Final;
	float4 Out = tex2D(BaseSampler, In.TexCoords);
	float4 Out2 = tex2D(GlowSampler, In.TexCoords2);
	
	Final = ( Out + Out2 ) * 0.75f * In.Color;
	
	Final = lerp(FogColor, Final, In.FogVal.x);
	Final.a = Out.a;
	
	return Final;
}

//--------------------------------------------------------
//
//	No Skinned technique
//
//

technique nds_doodad_default
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSNoSkinned();
		PixelShader = compile ps_2_0 PSDefault();
	}
}


technique nds_doodad_darkmap
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSNoSkinned();
		PixelShader = compile ps_2_0 PS_Dark();
	}
}


technique nds_doodad_glowmap
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VSNoSkinned();
		PixelShader = compile ps_2_0 PS_Glow();
	}
}


