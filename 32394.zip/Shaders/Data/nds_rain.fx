float4x4 WorldViewProj : WORLDVIEWPROJECTION;
float4 RainColor : GLOBAL;

struct VS_INPUT
{
    float4 Pos			: POSITION;
    float2 TexCoords	: TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 Pos			: POSITION;
	float2 TexCoords	: TEXCOORD0;
};

texture BaseMap
<
    string NTM = "base";
>;

sampler BaseSampler = sampler_state
{
   Texture = (BaseMap);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MAGFILTER = LINEAR;
   MINFILTER = LINEAR;
   MIPFILTER = LINEAR;
};

VS_OUTPUT VS(VS_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;
	Out.Pos = mul(In.Pos, WorldViewProj);
	Out.TexCoords = In.TexCoords;
	return Out;	
}

float4 PS(VS_OUTPUT In) : COLOR
{
	float4 Out = tex2D(BaseSampler, In.TexCoords);
	Out *= RainColor;
	return Out;
}

technique nds_rain
<
>
{
	pass P0
	{
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS();
		
		AlphaBlendEnable = TRUE;
		SrcBlend = SRCALPHA;
		DestBlend = INVSRCALPHA;

		ZWriteEnable = FALSE;
		ZFunc = LESSEQUAL;
		CullMode = CW;
	}
}