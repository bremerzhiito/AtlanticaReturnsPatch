// textures
texture BaseMap 
<
    string NTM = "base";
>;

texture PatternMap 
<
    string NTM = "shader";
>;

float4x4 WorldViewProjection    : WORLDVIEWPROJECTION;
float4x4 WorldView              : WORLDVIEW;
float4x4 InvWorld				: INVWORLD;
float4x4 InvWorldView			: INVWORLDVIEW;

float4x4 kMVPT					: GLOBAL;

//------------------------------------------------------------
// FOG

//float4 FogVal		        : GLOBAL = { 3000.f, 300.f, 0.f, 0.f };
//float4 FogColor             	: GLOBAL = { 0.42f, 0.45f, 0.6f, 1.f };

float4 FogNearFar		: FOGNEARFAR = { 300.0f, 3000.0f, 0.0f, 0.0f };
float4 FogColor			: FOGCOLOR = { 0.42f, 0.45f, 0.6f, 1.0f };

//------------------------------------------------------------

float4 cLightAmbient : Ambient
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;

float4 cLightDiffuse : Diffuse
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;

float3 cLightDirection : Direction
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;

// Vertex Shaders
struct VS_INPUT
{
    float3 Position  : POSITION;
    float4 Color     : COLOR0;
    float3 Normal    : NORMAL;
    float2 TexCoord0 : TEXCOORD0;
    float2 TexCoord1 : TEXCOORD1;
    float2 TexCoord2 : TEXCOORD2;
    float2 Pattern1  : TEXCOORD3;
    float2 Pattern2  : TEXCOORD4;
};

struct VS_OUTPUT 
{
    float4 Position  	: POSITION;
    float4 Color     	: COLOR0;
    float4 VertexColor 	: COLOR1;
    float2 BaseTex   	: TEXCOORD0;
    float2 Layer1Tex 	: TEXCOORD1;
    float2 Layer2Tex 	: TEXCOORD2;
    float2 Pattern1Tex  : TEXCOORD3;
    float2 Pattern2Tex  : TEXCOORD4;
    float4 FogVal       : TEXCOORD5;
};

VS_OUTPUT VS( VS_INPUT In )
{
    VS_OUTPUT Out = (VS_OUTPUT)0;

    // Transform position
    Out.Position = mul(float4(In.Position, 1), WorldViewProjection);

    float3 L = -cLightDirection;    
    float3 N = In.Normal;

    float3 vEyePos = mul( float4( 0, 0, 0, 1 ), InvWorldView );
    float3 Eye = normalize( vEyePos - In.Position );
    
    float3 R = -Eye * 2.0f * dot( N, Eye ) * N;

    // �ݻ���
    float4 k_a = { 0.4f, 0.4f, 0.4f, 0.4f };	// ambient
    float4 k_d = { 1.0f, 1.0f, 1.0f, 1.0f };	// diffuse
    
    Out.Color = cLightAmbient * k_a + cLightDiffuse * k_d * max( 0, dot( N, L ) );
               // + pow( max( 0, dot( L, R ) ), 3 );
                
    Out.VertexColor = In.Color;

    // Fill in texture coordinates

    Out.BaseTex = In.TexCoord0;
    Out.Layer1Tex = In.TexCoord1;
    Out.Layer2Tex = In.TexCoord2;
    Out.Pattern1Tex = In.Pattern1;
    Out.Pattern2Tex = In.Pattern2;

//    Out.ShadowTex = mul( float4(Position, 1), kMVPT ); 

    //------------------------------------------------------------
    // FOG

    float4 camPos = mul( float4(In.Position, 1), WorldView );

    float fFogEnd = FogNearFar.y;	//FogVal.x;
    float fFogStart = FogNearFar.x;	//FogVal.y;

    float fFogRange = fFogEnd - fFogStart;
    float fVertexDist = fFogEnd - camPos.z;

    Out.FogVal.x = clamp( (fVertexDist / fFogRange), 0.0f, 1.0f );

    //------------------------------------------------------------

    return Out;
}

// Samplers
sampler2D BaseSampler = 
sampler_state
{ 
    Texture = (BaseMap);
    AddressU = Clamp;
    AddressV = Clamp;
    MipFilter = LINEAR;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
};

sampler2D PatternSampler = 
sampler_state
{ 
    Texture = (PatternMap);
    AddressU = Clamp;
    AddressV = Clamp;
    MipFilter = LINEAR;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
};



// Pixel shader
float4 PS(VS_OUTPUT In) : COLOR
{
	float t;
	float4 r0, r1, r2, r3, r4, fog;

	r0 = tex2D( BaseSampler, In.BaseTex );
	r1 = tex2D( BaseSampler, In.Layer1Tex );
	r2 = tex2D( BaseSampler, In.Layer2Tex );
	r3 = tex2D( PatternSampler, In.Pattern1Tex );
	r4 = tex2D( PatternSampler, In.Pattern2Tex );
	
	//r4 = tex2Dproj( ShadowSampler, In.ShadowTex );

	r1 = lerp( r0, r1, r3.w );
	r2 = lerp( r1, r2, r4.w );
	
	r3 = 1.6f * In.Color * r2;
	r3 = lerp( r3, In.VertexColor, In.VertexColor.a );
	

	//------------------------------------------------------------
	// FOG

	fog = lerp( FogColor, r3, In.FogVal.x );

	fog.a = r3.a;

	//------------------------------------------------------------

	return fog;
}



// techniques
technique NDSMultiTexture
<
	string Description = "This shader applies a base map and performs "
	"per-pixel lighting using a normal map and a point light. This version "
	"of the shader does the lighting computations in a pixel shader.";

    string NBTMethod = "ATI";
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
    pass P0
    {	
		VertexShader = compile vs_2_0 VS();
        PixelShader = compile ps_2_0 PS();

		AlphaBlendEnable    = false;
    }

}
