//------------------------------------------------------------------------------
//
//	Transformation Matrices
//

float4x4 WorldViewProj	: WORLDVIEWPROJECTION;
float4x4 WorldView		: WORLDVIEW;
float4x4 CamViewToLightProj_1 : GLOBAL;
float4x4 CamViewToLightProj_2 : GLOBAL;




//------------------------------------------------------------------------------
//
//	Fog Paramters
//

float4 FogColor		: FOGCOLOR;
float4 FogNearFar	: FOGNEARFAR;




//------------------------------------------------------------------------------
//
//	Light Paramters
//

float3 LightAmbient : Ambient
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float3 LightDiffuse : Diffuse
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float3 LightDirection : Direction
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;




//------------------------------------------------------------------------------
//
//	Shadow Paramters
//

float4x4 ViewToLightView_0		: GLOBAL; // Transform from view space to light view space
float4x4 ViewToLightProj_0		: GLOBAL; // Transform from view space to light projection space
float	 ShadowEpsilon_0		: GLOBAL;
float    ShadowMapSize_0		: GLOBAL;
float    ShadowMapSizeInverse_0	: GLOBAL;





//------------------------------------------------------------------------------
//
//	BaseMap
//

texture BaseMap 
<
    string NTM = "base";
>;
sampler2D BaseSampler = sampler_state
{ 
    Texture = (BaseMap);
    AddressU = Clamp;
    AddressV = Clamp;
    MipFilter = LINEAR;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
};




//------------------------------------------------------------------------------
//
//	PatternMap
//

texture PatternMap 
<
    string NTM = "shader";
    int NTMIndex = 0;
>;
sampler2D PatternSampler = sampler_state
{ 
    Texture = (PatternMap);
    AddressU = Clamp;
    AddressV = Clamp;
    MipFilter = LINEAR;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
};


//------------------------------------------------------------------------------
//
//	MaskMap
//

texture MaskMap
< 
    string NTM = "shader";
    int NTMIndex = 1;
>;
sampler2D MaskSampler = sampler_state
{
    Texture = <MaskMap>;
    ADDRESSU = CLAMP;
    ADDRESSV = CLAMP;
    MINFILTER = LINEAR;
    MAGFILTER = LINEAR;
    MIPFILTER = NONE;
};



//------------------------------------------------------------------------------
//
//	ShadowMap1 
//

texture ShadowMap1
< 
    string NTM = "shader";
    int NTMIndex = 2;
>;

sampler2D ShadowSamplerFP1 = sampler_state
{
    Texture = <ShadowMap1>;
    ADDRESSU = CLAMP;
    ADDRESSV = CLAMP;
    //MINFILTER = POINT;
    //MAGFILTER = POINT;
    MINFILTER = Linear;
    MAGFILTER = Linear;    
    MIPFILTER = NONE;
};




//------------------------------------------------------------------------------
//
//	ShadowMap2
//

texture ShadowMap2
< 
    string NTM = "shader";
    int NTMIndex = 3;
>;

sampler2D ShadowSamplerFP2 = sampler_state
{
    Texture = <ShadowMap2>;
    ADDRESSU = CLAMP;
    ADDRESSV = CLAMP;
    //MINFILTER = POINT;
    //MAGFILTER = POINT;
    MINFILTER = Linear;
    MAGFILTER = Linear;  
    MIPFILTER = NONE;
};



//------------------------------------------------------------------------------
//
//	Calculation Functions
//

float3 CalculateLightAmbientDiffuse(in float3 iNormal)
{
	return LightAmbient + LightDiffuse * max( 0.0f, dot( -LightDirection, iNormal ) );
}

float3 CalculateLightDiffuse(in float3 iNormal)
{
	return LightDiffuse * max( 0.0f, dot( -LightDirection, iNormal ) );
}

float CalculateFogValue(in float4 iPos)
{
	return saturate( ( iPos.z - FogNearFar.x ) / ( FogNearFar.y - FogNearFar.x ) );	
}

float4 CalculateVertexColor(in float4 iColor, in float4 iVertexColor)
{
	return lerp( iColor, float4( iVertexColor.rgb, 1.0f ), iVertexColor.a );
}






//------------------------------------------------------------------------------
//
//	DepthStencil Shadow Functions
//

void CalculateShadowDSTex(in float4 iPosLight, out float4 oShadowTex)
{              	
	
	
	/*
		(( a * 0.5 ) / b) + 0.5f;
		
		{ (a * 0.5) + (0.5 + 0.5/1024.0f)*b } / b
		= { (( a * 0.5 ) / b) + 0.5f } + 0.5/1024.0f
	*/
	oShadowTex = iPosLight;
    oShadowTex.x = iPosLight.x * 0.5 + (0.5 + 0.5/1024.0) * iPosLight.w;
    oShadowTex.y = iPosLight.y * -0.5 + (0.5 + 0.5/1024.0) * iPosLight.w;	    
    //oShadowTex.z = 0.0f;//saturate( iPosLight.z / iPosLight.w );
}

float CalculateShadowDSIntensity(in float iNormal, in float4 iShadowTex1, in float4 iShadowTex2)
{
	float oIntensity1 = 0.0f;	
	float oIntensity2 = 0.0f;	
	
    if( iNormal > 0.0f )
    {
		// DepthStencil �ؽ��Ŀ� tex2D �� ����ϸ� �ڵ����� z ���� ���� �����Ѵ�.
		oIntensity1 = tex2D(ShadowSamplerFP1, iShadowTex1);
		oIntensity2 = tex2D(ShadowSamplerFP2, iShadowTex2);		
		oIntensity2 = lerp( oIntensity2, 1.0f, tex2D( MaskSampler, iShadowTex2.xy ) );   
    }
    
    return min(oIntensity1, oIntensity2);
}






//------------------------------------------------------------------------------
//
//	Floating Point Shadow Functions
//

void CalculateShadowFPTex(in float4 iPosLight, out float3 oShadowTex)
{               
	oShadowTex.xy = 0.5f * iPosLight.xy / iPosLight.w + float2( 0.5f, 0.5f );
	oShadowTex.y = 1.0f - oShadowTex.y;
	oShadowTex.z = saturate( iPosLight.z / iPosLight.w );
}
                
float CalculateShadowFPIntensity2(in float3 iNormal, in float3 iShadowTex1, in float3 iShadowTex2)
{
	float oIntensity1 = 0.0f;	
	float oIntensity2 = 0.0f;	
		
    if( dot( -LightDirection, iNormal ) > 0.0f )
    {
 		    
		float afSourcevals[4];
		
		// 2x2 filtering
		/*
        afSourcevals[0] = ( tex2D( ShadowSamplerFP1, iShadowTex1.xy ).r +
							ShadowEpsilon_0 < iShadowTex1.z ) ? 0.0f : 1.0f;
							
        afSourcevals[1] = ( tex2D( ShadowSamplerFP1, iShadowTex1.xy + float2( ShadowMapSizeInverse_0, 0 ) ).r + 
							ShadowEpsilon_0 < iShadowTex1.z ) ? 0.0f : 1.0f;
							
        afSourcevals[2] = ( tex2D( ShadowSamplerFP1, iShadowTex1.xy + float2( 0, ShadowMapSizeInverse_0 ) ).r +
							ShadowEpsilon_0 < iShadowTex1.z ) ? 0.0f : 1.0f;
							
        afSourcevals[3] = ( tex2D( ShadowSamplerFP1, iShadowTex1.xy + float2( ShadowMapSizeInverse_0, ShadowMapSizeInverse_0 ) ).r +
							ShadowEpsilon_0 < iShadowTex1.z ) ? 0.0f : 1.0f;
        
			
        float2 lerps = frac( ShadowMapSize_0 * iShadowTex1.xy );                
        
        oIntensity1 = lerp( lerp( afSourcevals[0], afSourcevals[1], lerps.x ),
                            lerp( afSourcevals[2], afSourcevals[3], lerps.x ),
                            lerps.y );                                   
        */
	    
	    oIntensity1 = ( tex2D( ShadowSamplerFP1, iShadowTex1.xy ).r + ShadowEpsilon_0 < iShadowTex1.z ) ? 0.0f : 1.0f;
	      
	                     
		// 2x2 filtering			
		
        afSourcevals[0] = ( tex2D( ShadowSamplerFP2, iShadowTex2.xy ).r +
							ShadowEpsilon_0 < iShadowTex2.z ) ? 0.0f : 1.0f;
							
        afSourcevals[1] = ( tex2D( ShadowSamplerFP2, iShadowTex2.xy + float2( ShadowMapSizeInverse_0, 0 ) ).r + 
							ShadowEpsilon_0 < iShadowTex2.z ) ? 0.0f : 1.0f;
							
        afSourcevals[2] = ( tex2D( ShadowSamplerFP2, iShadowTex2.xy + float2( 0, ShadowMapSizeInverse_0 ) ).r +
							ShadowEpsilon_0 < iShadowTex2.z ) ? 0.0f : 1.0f;
							
        afSourcevals[3] = ( tex2D( ShadowSamplerFP2, iShadowTex2.xy + float2( ShadowMapSizeInverse_0, ShadowMapSizeInverse_0 ) ).r +
							ShadowEpsilon_0 < iShadowTex2.z ) ? 0.0f : 1.0f;
        
		
        float2 lerps = frac( ShadowMapSize_0 * iShadowTex2.xy );        
        
        
        oIntensity2 = lerp( lerp( afSourcevals[0], afSourcevals[1], lerps.x ),
                            lerp( afSourcevals[2], afSourcevals[3], lerps.x ),
                            lerps.y );          
                		                                    
        // Masking    
		oIntensity2 = lerp( oIntensity2, 1.0f, tex2D( MaskSampler, iShadowTex2.xy ) );                                		
    }
        
    return min(oIntensity1, oIntensity2);
}

float CalculateShadowFPIntensity(in float3 iNormal, in float3 iShadowTex)
{
	float oIntensity = 0.0f;
    if( dot( -LightDirection, iNormal ) > 0.0f )
    {
		// 2x2 filtering
        float afSourcevals[4];
        afSourcevals[0] = tex2D( ShadowSamplerFP1, iShadowTex.xy ).r;
        afSourcevals[1] = tex2D( ShadowSamplerFP1, iShadowTex.xy + float2( ShadowMapSizeInverse_0, 0 ) ).r;
        afSourcevals[2] = tex2D( ShadowSamplerFP1, iShadowTex.xy + float2( 0, ShadowMapSizeInverse_0 ) ).r;
        afSourcevals[3] = tex2D( ShadowSamplerFP1, iShadowTex.xy + float2( ShadowMapSizeInverse_0, ShadowMapSizeInverse_0 ) ).r;
        afSourcevals[0] = ( afSourcevals[0] + ShadowEpsilon_0 < iShadowTex.z ) ? 0.0f : 1.0f;
        afSourcevals[1] = ( afSourcevals[1] + ShadowEpsilon_0 < iShadowTex.z ) ? 0.0f : 1.0f;  
        afSourcevals[2] = ( afSourcevals[2] + ShadowEpsilon_0 < iShadowTex.z ) ? 0.0f : 1.0f;  
        afSourcevals[3] = ( afSourcevals[3] + ShadowEpsilon_0 < iShadowTex.z ) ? 0.0f : 1.0f;  

        float2 lerps = frac( ShadowMapSize_0 * iShadowTex.xy );
        
        oIntensity = lerp( lerp( afSourcevals[0], afSourcevals[1], lerps.x ),
                           lerp( afSourcevals[2], afSourcevals[3], lerps.x ),
                           lerps.y );

		
		/*		
		// 3x3 ���͸�
		float4 vTexCoords[9];
		float4 vTexC = float4(iShadowTex.xy, 0.0f, 0.0f);

		// Generate the tecture co-ordinates for the specified depth-map size
		// 4 3 5
		// 1 0 2
		// 7 6 8
		vTexCoords[0] = vTexC;

		vTexCoords[1] = vTexC + float4( -ShadowMapSizeInverse_0, 0.0f, 0.0f, 0.0f );
		vTexCoords[2] = vTexC + float4(  ShadowMapSizeInverse_0, 0.0f, 0.0f, 0.0f );
		vTexCoords[3] = vTexC + float4( 0.0f, -ShadowMapSizeInverse_0, 0.0f, 0.0f );
		vTexCoords[6] = vTexC + float4( 0.0f,  ShadowMapSizeInverse_0, 0.0f, 0.0f );

		vTexCoords[4] = vTexC + float4( -ShadowMapSizeInverse_0, -ShadowMapSizeInverse_0, 0.0f, 0.0f );
		vTexCoords[5] = vTexC + float4(  ShadowMapSizeInverse_0, -ShadowMapSizeInverse_0, 0.0f, 0.0f );
		vTexCoords[7] = vTexC + float4( -ShadowMapSizeInverse_0,  ShadowMapSizeInverse_0, 0.0f, 0.0f );
		vTexCoords[8] = vTexC + float4(  ShadowMapSizeInverse_0,  ShadowMapSizeInverse_0, 0.0f, 0.0f );

		// Sample each of them checking whether the pixel under test is shadowed or not
		float fShadowTerm = 0.0f;
		float fTmp = iShadowTex.z;
		
		for( int i = 0; i < 9; i++ )
		{
			float A = tex2D( ShadowSamplerFP, vTexCoords[i] ).r;
			
			float B = (fTmp - ShadowEpsilon_0);
			
			// Texel is shadowed
			fShadowTerm += A < B ? 0.1f : 1.0f;			
		}
								
		oIntensity = fShadowTerm / 9.0f;
		*/
    }
    
    // Masking
    float fValue = max( tex2D( MaskSampler, iShadowTex.xy ).a, tex2D( MaskSampler, iShadowTex.zz ).a );
	oIntensity = lerp( oIntensity, 1.0f, fValue );
    
    return oIntensity;
}







//------------------------------------------------------------------------------
//
//	Decl
//

struct INPUT
{
    float4 Pos			: POSITION;
    float4 Color		: COLOR0;
    float3 Normal		: NORMAL;
    float2 TexCoord0	: TEXCOORD0;
    float2 TexCoord1	: TEXCOORD1;
    float2 Pattern1		: TEXCOORD2;
    float2 TexCoord2	: TEXCOORD3;
    float2 Pattern2		: TEXCOORD4;
};

struct OUTPUT 
{
    float4 Pos			: POSITION;
    float4 VertexColor 	: COLOR1;
    float2 BaseTex   	: TEXCOORD0;
    float2 Layer1Tex 	: TEXCOORD1;
    float2 Layer2Tex 	: TEXCOORD2;
    float4 PatternTex   : TEXCOORD3;    
    float4 Light		: TEXCOORD4;
};









//------------------------------------------------------------------------------
//
//	No Shadow
//

void VS11(
	in	INPUT	In,
	out OUTPUT	Out)
{
	// Calculate transformation
    Out.Pos = mul( In.Pos, WorldViewProj );

	// Set texture coords
    Out.BaseTex		  = In.TexCoord0;
    Out.Layer1Tex	  = In.TexCoord1;
    Out.Layer2Tex	  = In.TexCoord2;
	Out.PatternTex.xy = In.Pattern1;
	Out.PatternTex.zw = In.Pattern2;
	

	// Set Vertex Color                
    Out.VertexColor = In.Color;
    
	// Calculate light parameters
	Out.Light.rgb = CalculateLightDiffuse( In.Normal );
	
	// Calculate fog parameters
	float4 lPos = mul( In.Pos, WorldView );
	Out.Light.a = CalculateFogValue( lPos );
}

// Pixel shader
void PS20(
	in	OUTPUT	In,
	out	float4	oColor : COLOR)
{
	float4 r0, r1, r2, r3, r4, r5, r6;

	r0 = tex2D( BaseSampler, In.BaseTex );
	r1 = tex2D( BaseSampler, In.Layer1Tex );
	r2 = tex2D( BaseSampler, In.Layer2Tex );
	r4 = tex2D( PatternSampler, In.PatternTex.xy );
	r5 = tex2D( PatternSampler, In.PatternTex.zw );

	
	r1 = lerp( r0, r1, r4.w );
	r2 = lerp( r1, r2, r5.w );
	r3 = CalculateVertexColor( r2, In.VertexColor );

	oColor = float4( r3 * ( In.Light.rgb + LightAmbient ), 1.0f );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, In.Light.a );
}







//------------------------------------------------------------------------------
//
//	Shadow
//

void VS11_FPS(
	in	INPUT	In,
	out OUTPUT	Out,
	out float	oNormal		: TEXCOORD5,
	out	float4	oShadowTex1	: TEXCOORD6,
	out	float4	oShadowTex2	: TEXCOORD7 )
	
{
	// Calculate transformation
    Out.Pos = mul( In.Pos, WorldViewProj );

	// Set texture coords
    Out.BaseTex = In.TexCoord0;
    Out.Layer1Tex = In.TexCoord1;
    Out.Layer2Tex = In.TexCoord2;
	Out.PatternTex.xy = In.Pattern1;
	Out.PatternTex.zw = In.Pattern2;

	// Set Vertex Color                
    Out.VertexColor = In.Color;
    
	// Calculate light parameters
	Out.Light.rgb = CalculateLightDiffuse( In.Normal );
	
	// Calculate fog parameters
	float4 lPos = mul( In.Pos, WorldView );
	Out.Light.a = CalculateFogValue( lPos );

	// Caculate shadow paramters
	oNormal = saturate( dot( -LightDirection, In.Normal.xyz ) );

	float4 lPosLight1 = mul( lPos, CamViewToLightProj_1 );
	float4 lPosLight2 = mul( lPos, CamViewToLightProj_2 );
	
	CalculateShadowDSTex( lPosLight1, oShadowTex1 );
	CalculateShadowDSTex( lPosLight2, oShadowTex2 );
}

// Pixel shader
void PS20_FPS(
	in	OUTPUT	In,
	in	float	iNormal		: TEXCOORD5,
	in	float4	iShadowTex1	: TEXCOORD6,
	in	float4	iShadowTex2	: TEXCOORD7,
	out	float4	oColor		: COLOR)
{
	float4 r0, r1, r2, r3, r4, r5;

	r0 = tex2D( BaseSampler, In.BaseTex );
	r1 = tex2D( BaseSampler, In.Layer1Tex );
	r2 = tex2D( BaseSampler, In.Layer2Tex );
	r4 = tex2D( PatternSampler, In.PatternTex.xy );
	r5 = tex2D( PatternSampler, In.PatternTex.zw );
	
	r1 = lerp( r0, r1, r4.w );
	r2 = lerp( r1, r2, r5.w );
	r3 = CalculateVertexColor( r2, In.VertexColor );
	

	oColor = float4( r3 * ( CalculateShadowDSIntensity(iNormal, iShadowTex1,  iShadowTex2) * In.Light.rgb + LightAmbient ), 1.0f );
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, In.Light.a );
}





//------------------------------------------------------------------------------
//
//	Techniques
//

technique nds_terrain
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
    pass P0
    {	
        DepthBias = 0.0;
        SlopeScaleDepthBias = 0.0;
            
		VertexShader = compile vs_2_0 VS11();
        PixelShader = compile ps_2_0 PS20();
		AlphaBlendEnable    = false;
    }
}

technique nds_terrain_fps
<
    bool UsesNiRenderState = true;
    bool UsesNiLightState = true;
>
{
    pass P0
    {	
        DepthBias = 0.0;
        SlopeScaleDepthBias = 0.0;
    
    
		VertexShader = compile vs_2_0 VS11_FPS();
        PixelShader = compile ps_2_0 PS20_FPS();
		AlphaBlendEnable    = false;
    }
}
