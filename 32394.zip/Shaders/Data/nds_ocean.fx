
//------------------------------------------------------------------------------
//
//	Transformation Matrices
//
float4x4 kWorld					: WORLD;
float4x4 kView					: VIEW;
float4x4 kProj					: PROJECTION;
float4x4 kViewProj				: VIEWPROJECTION;
float4x4 kInvView				: INVVIEW;
float4x4 kWorldViewProj         : WORLDVIEWPROJECTION;


//------------------------------------------------------------------------------
//
//	Fog Paramters
//

float4 FogColor		: FOGCOLOR = { 0.42f, 0.45f, 0.6f, 1.f };
float4 FogNearFar	: FOGNEARFAR = { 0.0f, 0.0f, 0.f, 0.f };
float4 FogDensity	: FOGDENSITY = { 1.0f, 1.0f, 1.0f, 1.0f };


//------------------------------------------------------------------------------
//
//	Light Paramters
//

float4 LightAmbient : Ambient
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float4 LightDiffuse : Diffuse
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float3 LightDirection : Direction
<
    string Object = "DirectionalLight";
    int ObjectIndex = 0;
>;
float4 Multiplier : GLOBAL = 1.0f;


//------------------------------------------------------------------------------
//
//	Water Paramters
//

float	 kBumpScale				: GLOBAL = 0.14f;
float4	 kTexScale              : GLOBAL = float4( 0.7f, 1.2f, 0.0f, 0.0f);				// texture scale
float4   kBumpSpeed				: GLOBAL = float4( 0.006f, 0.003f, 0.0f, 0.0f);
float	 kFrequency				: GLOBAL = 0.038f;              // wave frequency
float	 kAmplitude				: GLOBAL = 0.3f;                // wave amplitude


float4	 kDeepColor				: GLOBAL = float4( 0.4f, 0.4f, 0.8f, 1.0f );   // deep water color
float4	 kShallowColor          : GLOBAL = float4( 0.4f, 0.6f, 1.0f, 1.0f );   // shallow water color
float4	 kReflectionColor       : GLOBAL = float4( 0.35f, 0.35f, 0.35f, 1.0f );  // reflection color

float	 kReflectionAmount		: GLOBAL = 1.0f;                // reflection amount
float    kReflectionBlur		: GLOBAL = 0.0f;
float	 kWaterAmount			: GLOBAL = 0.3f;                // water color amount

float	 kFresnelPower			: GLOBAL = 9.0f;
float	 kFresnelBias			: GLOBAL = 0.228f;
float    kHDRMultipiler			: GLOBAL = 0.271f;

float    kTime					: GLOBAL = 100.0f;				

float4	 c11					: GLOBAL = float4(0.0f, -0.25f, 0.0f, 0.0f);
float4	 c12					: GLOBAL = float4(-0.20f, -0.20f, 1.0f, 0.0f);
float4   c13					: GLOBAL = float4(0.10f, 0.10f, 1.0f, 0.0f);
float4   c14					: GLOBAL = float4(0.0f, 0.0f, 1.0f, 0.0f);
float4	 c15					: GLOBAL = float4(0.0f, 1.0f, 0.0f, 0.0f);




//------------------------------------------------------------------------------
//
//	SkyBox Map
//

texture SkyBoxTex
<
	string NTM = "Shader";
	int NTMIndex = 0;
>;
samplerCUBE SkyBoxSampler = sampler_state
{
	Texture = (SkyBoxTex);
	ADDRESSU = CLAMP;
	ADDRESSV = CLAMP;
	MAGFILTER = LINEAR;
	MINFILTER = LINEAR;
	MIPFILTER = LINEAR;
};


//------------------------------------------------------------------------------
//
//	Normal Texs
//
texture NormalTex
<
	string NTM = "Shader";
	int NTMIndex = 1;
>;
sampler2D NormalSampler = sampler_state
{
	Texture = (NormalTex);	
    MinFilter = Linear;
    MagFilter = Linear;
    MipFilter = Linear;
    AddressU = Wrap;
    AddressV = Wrap;
    	
};







//------------------------------------------------------------------------------
//
//	Calculation Functions
//

float4 CalculateLightAmbientDiffuse(in float3 iNormal)
{
	return LightAmbient + LightDiffuse * saturate( dot( -LightDirection, iNormal ) );
}

float CalculateFogValue(in float4 iPos)
{
	return saturate( ( iPos.z - FogNearFar.x ) / ( FogNearFar.y - FogNearFar.x ) );	
}


//------------------------------------------------------------------------------
struct VsInput
{
	float4 Position : POSITION;		 // in object space
	float2 TexCoord : TEXCOORD0;
};

struct VsOutput
{
	float4 Position  : POSITION;	 // in clip space
	float3 rotMatrix1 : TEXCOORD0;   // first row of the 3x3 transform from tangent to obj space
	float3 rotMatrix2 : TEXCOORD1;   // second row of the 3x3 transform from tangent to obj space
	float3 rotMatrix3 : TEXCOORD2;   // third row of the 3x3 transform from tangent to obj space

	float3 bumpCoord0 : TEXCOORD3;
	float2 bumpCoord1 : TEXCOORD4;
	float2 bumpCoord2 : TEXCOORD5;	

	float3 eyeVector  : TEXCOORD6;
	
	float4 reflectUV  : TEXCOORD7;	
};


//------------------------------------------------------------------------------
struct Wave
{
    float freq;     // 2*PI / wavelength
    float amp;      // amplitude
    float phase;    // speed * 2*PI / wavelength
    float2 dir;
};




//------------------------------------------------------------------------------
float evaluateWave(Wave w, float2 pos, float t)
{
  return w.amp * sin(dot(w.dir, pos) * w.freq + t * w.phase);
}

float evaluateWaveDeriv(Wave w, float2 pos, float t)
{
  return w.freq * w.amp * cos(dot(w.dir, pos) * w.freq + t * w.phase);
}

float evaluateWaveSharp(Wave w, float2 pos, float t, float k)
{
  return w.amp * pow(sin(dot(w.dir, pos) * w.freq + t * w.phase)* 0.5 + 0.5, k);
}

float evaluateWaveDerivSharp(Wave w, float2 pos, float t, float k)
{
  return k * w.freq * w.amp * pow(sin(dot(w.dir, pos) * w.freq + t * w.phase)* 0.5 + 0.5, k - 1) * cos(dot(w.dir, pos) * w.freq + t * w.phase);
}





//------------------------------------------------------------------------------
//
//	Shader
//


//-----------------------------------------------------------------------------              
VsOutput WaterVS(const VsInput vsIn)                                 
{
    VsOutput vsOut;

	#define NumWaves 2
	Wave wave[NumWaves] =
	{
		{ 1.0, 1.0, 0.5, float2(-0.3, 0.2) },
		{ 2.0, 0.5, 1.7, float2(-0.2, 0.7) }
	};

    wave[0].freq = kFrequency;
    wave[0].amp  = kAmplitude;
    wave[1].freq = kFrequency * 2.0;
    wave[1].amp  = kAmplitude * 0.5;

    float4 P = vsIn.Position;

	// sum waves
	float ddx = 0.0, ddy = 0.0;

	// wave synthesis using two sine waves at different frequencies and phase shift
	for(int i = 0; i< NumWaves; ++i)
	{		
		P.z += evaluateWave(wave[i], P.xy, kTime); 
        float deriv = evaluateWaveDeriv(wave[i], P.xy, kTime); 
		
		ddx += deriv * wave[i].dir.x;
		ddy += deriv * wave[i].dir.y;		
	}
	
	
	    
	// compute tangent basis 
	float3 B = float3(1, ddx, 0); 
	float3 T = float3(0, ddy, 1); 
	float3 N = float3(-ddx, 1, -ddy); 
	
    
    
	vsOut.Position = mul(P, kWorldViewProj);

	// calculate texture coordinates for normal map lookup
	vsOut.bumpCoord0.xy = vsIn.TexCoord*kTexScale + kTime * kBumpSpeed;
	vsOut.bumpCoord1.xy = vsIn.TexCoord*kTexScale * 2.0 + kTime * kBumpSpeed * 4.0;
	vsOut.bumpCoord2.xy = vsIn.TexCoord*kTexScale * 4.0 + kTime * kBumpSpeed * 8.0;
	
				
	float3x3 objToTangentSpace; 
	// first rows are the tangent and binormal scaled by the bump scale 
	objToTangentSpace[0] = kBumpScale * normalize(T); 
	objToTangentSpace[1] = kBumpScale * normalize(B); 
	objToTangentSpace[2] = normalize(N); 

	vsOut.rotMatrix1.xyz = mul(objToTangentSpace, kWorld[0].xyz); 
	vsOut.rotMatrix2.xyz = mul(objToTangentSpace, kWorld[1].xyz); 
	vsOut.rotMatrix3.xyz = mul(objToTangentSpace, kWorld[2].xyz); 
   
   				    
    float4 worldPos		 = mul(P, kWorld);     
    float4 viewPos		 = mul(worldPos, kView);
    vsOut.eyeVector = kInvView[3] - worldPos; // view inv. transpose contains     
	
	vsOut.reflectUV = worldPos;	
	
	
	vsOut.bumpCoord0.z = CalculateFogValue( viewPos );
	
    return vsOut;
}


//-----------------------------------------------------------------------------
float4 WaterPS(VsOutput psIn) : COLOR
{   	
    float4 t0 = tex2D(NormalSampler, psIn.bumpCoord0.xy) * 2.0 - 1.0;
    float4 t1 = tex2D(NormalSampler, psIn.bumpCoord1.xy) * 2.0 - 1.0;
    float4 t2 = tex2D(NormalSampler, psIn.bumpCoord2.xy) * 2.0 - 1.0;            
    float3 N = t0.xyz + t1.xyz + t2.xyz;

    float3x3 m; // tangent to world matrix
    m[0] = psIn.rotMatrix1;
    m[1] = psIn.rotMatrix2;
    m[2] = psIn.rotMatrix3;

    N = normalize( mul( m, N ) );
	
 
	// reflection        	
    float3 E = normalize(psIn.eyeVector);     
    E.xyz = E.xzy;
          
   
    float4 R;        
    R.xyz = -reflect(E, N);
    R.w = kReflectionBlur;
                
    float4 reflection = texCUBEbias(SkyBoxSampler, R.xyzw);    
    
    
    
    // cheap hdr effect         
    reflection.rgb *= (reflection.r + reflection.g + reflection.b) * kReflectionAmount;
			
	// fresnel
    float facing = 1.0f - max(dot(E, N), 0);                
    float fresnel = kFresnelBias + (1.0-kFresnelBias)*pow(abs(facing), kFresnelPower); 
    float4 waterColor = lerp(kShallowColor, kDeepColor, facing) * kWaterAmount;
	
    reflection = lerp(waterColor, reflection *  kReflectionColor, fresnel) * kReflectionAmount;
        
	float4 oColor = (waterColor + reflection);
	
	oColor.rgb = lerp( oColor.rgb, FogColor.rgb, psIn.bumpCoord0.z );
	
	return oColor;
}





//------------------------------------------------------------------------------
//
//	Techniques
//

technique nds_ocean
<
	bool UsesNiRenderState = true;
	bool UsesNILightState = true;
>
{	
    pass Waters
    {
        VertexShader = compile vs_2_0 WaterVS();
        PixelShader  = compile ps_2_0 WaterPS();
    }	
}