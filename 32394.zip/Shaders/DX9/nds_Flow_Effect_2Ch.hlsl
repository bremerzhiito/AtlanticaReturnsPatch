float4x4 view_proj_matrix;
float4x4	world_view;
float4x2	MatrixTexbase;
float4x2	MatrixTexdark;
float4x4 proj_matrix;
float4		MaterialEmissive	: register(c6);
float4 g_fogcolor;
float4 g_fognearfar;

sampler2D BaseSampler : register(s0);
sampler2D DarkSampler : register(s1);

struct VS_INPUT
{
	float4 Pos			: POSITION;
	float2 TexCoords0	: TEXCOORD0;
	float2 TexCoords1	: TEXCOORD1;
	
};

struct VS_OUTPUT
{
	float4 Pos				: POSITION;
	float2 TexCoords0   	: TEXCOORD0;
	float2 TexCoords1   	: TEXCOORD1;
	float3 FogDot			: TEXCOORD2;
};

VS_OUTPUT VS(VS_INPUT In)
{
	VS_OUTPUT Out = (VS_OUTPUT)0;

	Out.Pos = mul( In.Pos, view_proj_matrix );
	Out.TexCoords0 = mul( float4( In.TexCoords0, 1.0f, 1.0f ), MatrixTexbase );
	Out.TexCoords1 = mul( float4( In.TexCoords1, 1.0f, 1.0f ), MatrixTexdark );
		
	//cal fog
	Out.FogDot = float3(1.0f, 0.0f, 0.0f);
	float4 WorldViewPos = mul( In.Pos, world_view );
	Out.FogDot.x = saturate( ( WorldViewPos.z - g_fognearfar.x ) / ( g_fognearfar.y - g_fognearfar.x ) );
	
	return Out;	
}



float4 PS(VS_OUTPUT In) : COLOR
{
	float4 finalColor;
	float4 finalColor1;
	float4 BaseColor = tex2D( BaseSampler, In.TexCoords0 );
	float4 DarkColor = tex2D( DarkSampler, In.TexCoords1 );

	//float4 finalColor = BaseColor * DarkColor;
	finalColor = BaseColor * DarkColor * MaterialEmissive ;
	
	// fog color calculate
	if((finalColor.r + finalColor.g + finalColor.b) <= 0.1f)
	{    
		finalColor1 = finalColor;
	}
	else
	{ 
		finalColor1.rgb = lerp(finalColor.rgb, g_fogcolor.rgb, In.FogDot.x);
	}
	return finalColor1;

	
}

