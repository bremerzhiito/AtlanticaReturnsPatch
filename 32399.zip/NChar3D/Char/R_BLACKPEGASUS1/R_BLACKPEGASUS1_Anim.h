// This file was automatically generated. It contains definitions for all the
// animations stored in the associated KFM file. Include this file in your
// final application to easily refer to animation sequences.

#ifndef R_BLACKPEGASUS1_ANIM_H__
#define R_BLACKPEGASUS1_ANIM_H__

namespace R_BLACKPEGASUS1_Anim
{
    enum
    {
        RIDBACKSTEP1            = 4325,
        RIDLEFTBACK1            = 4334,
        RIDLEFTFRONT1           = 4359,
        RIDLEFTSTEP1            = 4323,
        RIDRIGHTBACK1           = 4335,
        RIDRIGHTFRONT1          = 4330,
        RIDRIGHTSTEP1           = 4324,
        RIDRUN1                 = 4306,
        RIDWAIT1                = 4301,
        RIDWALK1                = 4305
    };
}

#endif  // #ifndef R_BLACKPEGASUS1_ANIM_H__
